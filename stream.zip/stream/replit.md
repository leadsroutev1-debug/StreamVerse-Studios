# StreamVerse Studio

AI-powered streaming platform. The backend engine generates video episodes via a production pipeline (LLM scripting → image gen → video gen → Facebook publish). The frontend is a Next.js viewer that shows episodes to end users.

## How to run on Replit

Two workflows start automatically via the **"Project"** run button:

| Workflow | Command | Port | URL |
|---|---|---|---|
| **Start Backend** | `PORT=3001 node index.js` | 3001 | `…replit.dev:3001` |
| **Start application** | `cd frontend && npm run dev` | 5000 | Preview pane (main URL) |

- **Frontend** (viewer): preview pane / main Replit URL (port 5000)
- **Backend dashboard**: `…replit.dev:3001/dashboard`

The frontend proxies `/api/*` to the backend automatically in dev mode (no config needed). When `BACKEND_URL` is set as a Replit Secret, the frontend uses that instead.

## Exporting the frontend to another server

1. Edit `frontend/.env` (create it if it doesn't exist) and set:
   ```
   NEXT_PUBLIC_BACKEND_URL=https://your-backend.example.com
   ```
2. Build: `cd frontend && npm run build`
3. Deploy the `frontend/.next` output to any Next.js-compatible host (Vercel, Render, etc.)

`NEXT_PUBLIC_BACKEND_URL` is baked in at build time. The `next.config.js` also accepts the legacy name `BACKEND_URL`.

## Production deployment (both services together)

`start.sh` at the project root starts both services:
```bash
bash start.sh
```
Backend runs on port 3001, frontend builds then starts on port 5000.

## Stack

### Backend (root — `index.js`, `src/`)
- **Runtime**: Node.js (CommonJS)
- **Web framework**: Express (port 3001)
- **Scheduler**: node-cron (episodes at 05:00, 12:00, 17:00 UTC)
- **Database**: MySQL via `mysql2` — `DATABASE_URL`
- **Image generation**: Cloudflare Worker AI (`CF_WORKER_URL`/`CF_WORKER_KEYS`), fallback Google Gemini (`GOOGLE_KEYS`)
- **Video generation**: Magic Hour AI (`MAGIC_HOUR_KEYS`)
- **TTS**: Deepgram (`DEEPGRAK_KEYS`)
- **Media storage**: Cloudinary
- **Publishing**: Facebook Graph API
- **Notifications**: Telegram bot

### Frontend (`frontend/`)
- **Framework**: Next.js 15 (App Router)
- **Styling**: Tailwind CSS
- **Animation**: Framer Motion

## Source layout

```
index.js              — Express server + cron setup
src/
  config.js           — Env vars, key pools, rotation helpers
  db.js               — MySQL pool + schema init
  pipeline.js         — Core episode generation pipeline
  scriptWriter.js     — LLM episode script generation
  imageGen.js         — Image generation router
  cfImageGen.js       — Cloudflare Worker AI client
  googleImageGen.js   — Google Gemini image client
  videoGen.js         — Magic Hour video job + polling
  cloudinary.js       — Cloudinary upload, URL building
  compiler.js         — FFmpeg service: scene assembly
  ttsGen.js           — Deepgram TTS
  facebook.js         — Facebook Graph API
  telegram.js         — Telegram notifications
  state.js            — In-memory pipeline state + SSE
views/
  dashboard.html      — Control room UI (SSE live updates)
frontend/
  app/                — Next.js App Router pages
  components/         — UI components
  lib/api.js          — Backend API client
  next.config.js      — Next.js config (rewrite proxy, env)
logo/
  Logo.png            — Watermark overlay on every video
start.sh              — Production startup (both services)
```

## User preferences

- Keep existing file/module structure; do not restructure or migrate
- All secrets managed via Replit Secrets (never hardcoded)
- Frontend on port 5000 (webview), backend on port 3001 (console)
- Frontend connects to backend via rewrite proxy in dev; `BACKEND_URL` / `NEXT_PUBLIC_BACKEND_URL` for production
