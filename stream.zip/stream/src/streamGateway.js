'use strict';
/**
 * Decoupled Ad-as-Auth Streaming Gateway
 *
 * Serves video content THROUGH this backend so any external webapp only
 * needs to know the backend URL — no direct Cloudinary URLs are exposed.
 *
 * Flow (external web / webapp traffic):
 *   1. GET  /api/episodes/:id/stream
 *        → Returns Adsterra VAST XML tag URL + a short-lived ad-session token (15 min).
 *          The client video player loads the VAST ad, plays it, then calls step 2.
 *
 *   2. POST /api/episodes/:id/ad-complete  { token }
 *        → Verifies the ad-session token.
 *          Mints a video-access token (4-hour TTL, reusable across range requests).
 *          Returns a backend streaming URL:  GET /api/episodes/:id/video?t=<token>
 *
 *   3. GET  /api/episodes/:id/video?t=<token>
 *        → Validates the video-access token, then proxies the video from Cloudinary
 *          through this server. Fully supports HTTP Range requests so the browser
 *          player can seek without re-downloading from the start.
 *
 * Flow (internal pipeline bypass):
 *   Any request carrying  X-Internal-Pipeline: <HMAC>  skips the ad wall and
 *   receives the raw video URL directly. HMAC = SHA-256("internal:streamverse-pipeline" + SESSION_SECRET).
 *   Only this server knows SESSION_SECRET so it cannot be forged externally.
 *   Use  streamGateway.internalHeader()  to get the value for pipeline requests.
 *
 * CORS:
 *   All gateway routes return  Access-Control-Allow-Origin: *  so external webapps
 *   on any domain can call them from a browser. Actual video bytes are proxied through
 *   this server so the browser never needs direct Cloudinary access.
 *
 * Adsterra tracking:
 *   VAST tracking pings (impression, start, midpoint, complete, etc.) are fired
 *   client-side by the video player directly to Adsterra's servers — they are
 *   completely independent of which server the frontend is hosted on. Register
 *   THIS backend's public URL (or the external webapp URL once deployed) as the
 *   "website URL" in your Adsterra property settings. Tracking will work identically
 *   whether the frontend is on the same server or a separate domain.
 */

const crypto = require('crypto');
const axios  = require('axios');
const db     = require('./db');

// ─────────────────────────────────────────────────────────────────────────────
// Token stores (in-process Maps)
// ─────────────────────────────────────────────────────────────────────────────

// Ad-session tokens: one-time use, 15-minute TTL
// Maps adTokenHex → { episodeId, expiresAt }
const _adTokens = new Map();
const AD_TOKEN_TTL_MS = 15 * 60 * 1000;

// Video-access tokens: reusable (supports range requests), 4-hour TTL
// Maps videoTokenHex → { episodeId, videoUrl, expiresAt }
const _videoTokens = new Map();
const VIDEO_TOKEN_TTL_MS = 4 * 60 * 60 * 1000;

// Purge expired tokens every 10 minutes
setInterval(() => {
  const now = Date.now();
  for (const [t, m] of _adTokens)    { if (m.expiresAt < now) _adTokens.delete(t); }
  for (const [t, m] of _videoTokens) { if (m.expiresAt < now) _videoTokens.delete(t); }
}, 10 * 60 * 1000);

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function _mintAdToken(episodeId) {
  const token = crypto.randomBytes(32).toString('hex');
  _adTokens.set(token, { episodeId, expiresAt: Date.now() + AD_TOKEN_TTL_MS });
  return token;
}

function _mintVideoToken(episodeId, videoUrl) {
  const token = crypto.randomBytes(32).toString('hex');
  _videoTokens.set(token, { episodeId, videoUrl, expiresAt: Date.now() + VIDEO_TOKEN_TTL_MS });
  return token;
}

/**
 * Compute the expected X-Internal-Pipeline header value.
 * SHA-256("internal:streamverse-pipeline" + SESSION_SECRET)
 */
function _internalPipelineHmac() {
  const secret = process.env.SESSION_SECRET || '';
  return crypto
    .createHmac('sha256', secret)
    .update('internal:streamverse-pipeline')
    .digest('hex');
}

/** True when the request carries a valid internal-pipeline bypass header. */
function _isInternalRequest(req) {
  const provided = req.headers['x-internal-pipeline'];
  if (!provided) return false;
  try {
    const expected = _internalPipelineHmac();
    const a = Buffer.from(provided,  'utf8');
    const b = Buffer.from(expected,  'utf8');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { return false; }
}

/** Add CORS + no-cache headers appropriate for API responses. */
function _apiHeaders(res) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Internal-Pipeline');
  res.setHeader('Access-Control-Max-Age',       '86400');
}

/** Add CORS + video delivery headers for the streaming proxy. */
function _videoHeaders(res) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Range');
  res.setHeader('Access-Control-Expose-Headers','Content-Range, Content-Length, Accept-Ranges');
}

// ─────────────────────────────────────────────────────────────────────────────
// Route handlers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * OPTIONS preflight handler — respond to CORS preflight for all gateway routes.
 */
function handleOptions(req, res) {
  _apiHeaders(res);
  res.sendStatus(204);
}

/**
 * GET /api/episodes/:id/stream
 *
 * External callers  → Adsterra VAST tag URL + ad-session token.
 * Internal pipeline → raw Cloudinary video URL (bypass).
 */
async function handleStream(req, res) {
  _apiHeaders(res);
  try {
    const episodeId = parseInt(req.params.id, 10);
    if (!episodeId || isNaN(episodeId)) {
      return res.status(400).json({ ok: false, error: 'Invalid episode ID' });
    }

    const episode = await db.queryOne(
      `SELECT id, video_url, status FROM episodes WHERE id = ?`,
      [episodeId]
    );
    if (!episode) {
      return res.status(404).json({ ok: false, error: 'Episode not found' });
    }
    if (!episode.video_url) {
      return res.status(409).json({ ok: false, error: 'Episode video not yet available' });
    }

    // ── Internal bypass ────────────────────────────────────────────────────
    if (_isInternalRequest(req)) {
      return res.json({ ok: true, videoUrl: episode.video_url, bypass: true });
    }

    // ── External: ad-gated path ────────────────────────────────────────────
    const vastUrl = process.env.ADSTERRA_VAST_URL || null;
    if (!vastUrl) {
      return res.status(503).json({
        ok:    false,
        error: 'Streaming not yet configured — set ADSTERRA_VAST_URL to enable',
      });
    }

    const adToken = _mintAdToken(episodeId);
    return res.json({
      ok:               true,
      vastUrl,
      token:            adToken,
      tokenExpiresInMs: AD_TOKEN_TTL_MS,
      // Tell the client player: play the VAST ad, then POST the token here:
      completeUrl: `/api/episodes/${episodeId}/ad-complete`,
    });

  } catch (err) {
    console.error('[StreamGateway] /stream error:', err.message);
    res.status(500).json({ ok: false, error: 'Internal server error' });
  }
}

/**
 * POST /api/episodes/:id/ad-complete  { token }
 *
 * Verifies the ad-session token, returns a backend streaming URL
 * (pointing to /api/episodes/:id/video?t=...) so the player fetches
 * video content from THIS server, not directly from Cloudinary.
 */
async function handleAdComplete(req, res) {
  _apiHeaders(res);
  try {
    const episodeId = parseInt(req.params.id, 10);
    if (!episodeId || isNaN(episodeId)) {
      return res.status(400).json({ ok: false, error: 'Invalid episode ID' });
    }

    const episode = await db.queryOne(
      `SELECT id, video_url, status FROM episodes WHERE id = ?`,
      [episodeId]
    );
    if (!episode?.video_url) {
      return res.status(404).json({ ok: false, error: 'Episode not found or no video' });
    }

    // ── Internal bypass ────────────────────────────────────────────────────
    if (_isInternalRequest(req)) {
      // Internal pipeline gets the raw Cloudinary URL directly — no ad wall
      return res.json({ ok: true, videoUrl: episode.video_url, bypass: true });
    }

    // ── Ad-session token verification ──────────────────────────────────────
    const adToken = req.body?.token;
    if (!adToken || typeof adToken !== 'string') {
      return res.status(401).json({ ok: false, error: 'Ad-session token required' });
    }

    const session = _adTokens.get(adToken);
    if (!session) {
      return res.status(401).json({ ok: false, error: 'Invalid or expired ad-session token' });
    }
    if (session.expiresAt < Date.now()) {
      _adTokens.delete(adToken);
      return res.status(401).json({ ok: false, error: 'Ad-session token expired — request a new stream' });
    }
    if (session.episodeId !== episodeId) {
      return res.status(403).json({ ok: false, error: 'Token does not match episode' });
    }

    // Consume the ad-session token (one-time use)
    _adTokens.delete(adToken);

    // Mint a video-access token (reusable within 4 hours, supports range requests)
    const videoToken = _mintVideoToken(episodeId, episode.video_url);

    // Build the backend streaming URL — this is what the client player will use.
    // The URL points to THIS server, not Cloudinary, so external webapps only
    // need to know the backend's public URL.
    const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
    const host  = req.headers['x-forwarded-host']  || req.get('host') || '';
    const streamUrl = `${proto}://${host}/api/episodes/${episodeId}/video?t=${videoToken}`;

    return res.json({
      ok:         true,
      videoUrl:   streamUrl,
      expiresIn:  VIDEO_TOKEN_TTL_MS / 1000,   // seconds
      // Hint for the player: this URL supports HTTP Range requests (seeking works)
      supportsRange: true,
    });

  } catch (err) {
    console.error('[StreamGateway] /ad-complete error:', err.message);
    res.status(500).json({ ok: false, error: 'Internal server error' });
  }
}

/**
 * GET /api/episodes/:id/video?t=<videoToken>
 *
 * Proxies the video from Cloudinary through this server.
 * Fully supports HTTP Range requests so browser players can seek without
 * re-downloading from the start.
 *
 * The video-access token is reusable (range requests fire multiple GETs)
 * but expires after 4 hours.
 */
async function handleVideoStream(req, res) {
  _videoHeaders(res);

  // CORS preflight
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }

  try {
    const episodeId  = parseInt(req.params.id, 10);
    const videoToken = req.query.t;

    if (!episodeId || isNaN(episodeId)) {
      return res.status(400).json({ ok: false, error: 'Invalid episode ID' });
    }
    if (!videoToken) {
      return res.status(401).json({ ok: false, error: 'Video access token required (?t=...)' });
    }

    // Validate token
    const session = _videoTokens.get(videoToken);
    if (!session) {
      return res.status(401).json({ ok: false, error: 'Invalid or expired video token' });
    }
    if (session.expiresAt < Date.now()) {
      _videoTokens.delete(videoToken);
      return res.status(401).json({ ok: false, error: 'Video token expired — request a new stream session' });
    }
    if (session.episodeId !== episodeId) {
      return res.status(403).json({ ok: false, error: 'Token does not match episode' });
    }

    const cloudinaryVideoUrl = session.videoUrl;

    // ── Forward request to Cloudinary, pass Range header through ──────────
    const upstreamHeaders = {};
    if (req.headers.range) {
      upstreamHeaders['Range'] = req.headers.range;
    }

    const upstream = await axios.get(cloudinaryVideoUrl, {
      headers:      upstreamHeaders,
      responseType: 'stream',
      timeout:      60000,
      // Don't throw on 206 Partial Content — axios treats it as success
      validateStatus: (s) => s < 400,
    });

    // Pass through status + relevant headers from Cloudinary
    res.status(upstream.status);

    const passthroughHeaders = [
      'content-type',
      'content-length',
      'content-range',
      'accept-ranges',
      'cache-control',
      'last-modified',
      'etag',
    ];
    for (const h of passthroughHeaders) {
      if (upstream.headers[h]) res.setHeader(h, upstream.headers[h]);
    }

    // Ensure the player knows we support range requests (seeking)
    res.setHeader('Accept-Ranges', 'bytes');

    // Pipe Cloudinary's response stream directly to the client
    upstream.data.pipe(res);

    upstream.data.on('error', (err) => {
      console.error('[StreamGateway] Proxy stream error:', err.message);
      if (!res.headersSent) res.status(502).json({ ok: false, error: 'Upstream stream error' });
    });

  } catch (err) {
    console.error('[StreamGateway] /video error:', err.message);
    if (!res.headersSent) {
      res.status(500).json({ ok: false, error: 'Internal server error' });
    }
  }
}

/**
 * Returns the pre-computed internal bypass header value.
 * Use in pipeline/facebook requests to skip the ad wall:
 *
 *   axios.get(url, { headers: { 'X-Internal-Pipeline': streamGateway.internalHeader() } })
 */
function internalHeader() {
  return _internalPipelineHmac();
}

module.exports = { handleOptions, handleStream, handleAdComplete, handleVideoStream, internalHeader };
