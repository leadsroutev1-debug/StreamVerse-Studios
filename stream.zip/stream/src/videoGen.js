'use strict';
const axios = require('axios');
const config = require('./config');

/**
 * Submit an image-to-video job to Magic Hour.
 * imageBuffer: Buffer of the source image.
 * Returns { jobId, apiKey } on success, or throws.
 *
 * Rotates through magicHourKeys if submission fails.
 *
 * shotMeta fields:
 *   motionLevel  — 'low'|'medium'|'high'
 *   duration     — raw generation seconds (4 or 5)
 *   talkingPhoto — { audioUrl, durationSeconds } | null
 *   imagePrompt  — the shot's image_prompt, passed to MH for expressive animation
 */
async function submitVideoJob(imageBuffer, shotMeta) {
  const keyCount = config.magicHourKeys.length;
  if (keyCount === 0) throw new Error('[VideoGen] No Magic Hour keys configured');

  // Upload image to Cloudinary first (Magic Hour needs a URL, not a buffer)
  const cloudinary = require('./cloudinary');
  const tmpPublicId = `${config.shotsFolderRoot}/tmp/img_${Date.now()}`;
  // Detect actual MIME type from buffer magic bytes — CF Worker can return PNG, JPEG, or WebP
  function _detectMime(buf) {
    if (!buf || buf.length < 12) return 'image/png';
    if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47) return 'image/png';
    if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF)                      return 'image/jpeg';
    if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
        buf[8] === 0x57 && buf[9] === 0x45 && buf[10]=== 0x42 && buf[11]=== 0x50)  return 'image/webp';
    return 'image/png';
  }
  const mime = _detectMime(imageBuffer);
  const imageUrl = await cloudinary.uploadImageFromUrl(
    `data:${mime};base64,${imageBuffer.toString('base64')}`,
    tmpPublicId
  );

  let lastError;
  let hadCreditError = false; // tracks if any key returned 402 (credits depleted)

  for (let attempt = 0; attempt < keyCount; attempt++) {
    const key = config.getNextMagicHourKey(attempt);
    try {
      // Route to ai-talking-photo when TTS audio is available, else image-to-video
      const talkingPhoto = shotMeta.talkingPhoto; // { audioUrl, durationSeconds } | null
      let endpoint, body;
      if (talkingPhoto?.audioUrl) {
        // ── AI Talking Photo ──────────────────────────────────────────────────
        // Uses 'prompted' generation mode (the current name for what was formerly
        // called 'expressive'). The shot's image_prompt is passed so Magic Hour
        // can animate with the correct emotional and visual context.
        // aspect_ratio: "9:16" forces vertical portrait output for Facebook Reels.
        endpoint = 'https://api.magichour.ai/v1/ai-talking-photo';
        body = {
          start_seconds: 0,
          end_seconds:   talkingPhoto.durationSeconds,
          assets: {
            image_file_path: imageUrl,
            audio_file_path: talkingPhoto.audioUrl,
          },
          style: {
            aspect_ratio:   '9:16',                          // vertical Reels/Shorts format
            generationMode: 'prompted',                      // formerly 'expressive'
            ...(shotMeta.imagePrompt
              ? { prompt: shotMeta.imagePrompt.slice(0, 500) } // MH prompt cap
              : {}),
          },
        };
      } else {
        // ── Image-to-Video ────────────────────────────────────────────────────
        // aspect_ratio: "9:16" forces vertical portrait output for Facebook Reels.
        // audio: true enables Magic Hour's AI-generated ambient audio on every shot —
        // this is MH's built-in audio engine (no Deepgram needed for non-dialogue shots).
        // image_prompt guides MH's audio and motion generation context.
        endpoint = 'https://api.magichour.ai/v1/image-to-video';
        body = {
          end_seconds: shotMeta.duration || 5,
          audio:       true,              // MH AI-generated ambient audio (built-in, no Deepgram)
          assets: { image_file_path: imageUrl },
          style: {
            aspect_ratio: '9:16',         // vertical portrait — 1080×1920 for Reels/Shorts
            ...(shotMeta.imagePrompt
              ? { prompt: shotMeta.imagePrompt.slice(0, 500) } // guides MH audio + motion
              : {}),
          },
        };
      }

      const resp = await axios.post(endpoint, body, {
        headers: {
          'Authorization': `Bearer ${key}`,
          'Content-Type':  'application/json',
        },
        timeout: 30000,
      });
      if (resp.data?.id) {
        config.markKeyStatus('magicHour', key, 'active');
        return { jobId: resp.data.id, apiKey: key, imageTmpPublicId: tmpPublicId };
      }
      throw new Error(`Unexpected response: ${JSON.stringify(resp.data)}`);
    } catch (err) {
      lastError = err;
      const status = err.response?.status;
      if (status === 402) {
        hadCreditError = true;
        config.markKeyStatus('magicHour', key, 'exhausted');
        console.warn(`[VideoGen] Magic Hour key has no credits (402), rotating...`);
        continue;
      }
      if (status === 429) {
        config.markKeyStatus('magicHour', key, 'rate-limited');
        console.warn(`[VideoGen] Magic Hour key rate-limited (429), rotating...`);
        continue;
      }
      if (status === 401) {
        config.markKeyStatus('magicHour', key, 'exhausted');
        console.warn(`[VideoGen] Magic Hour key unauthorized (401), rotating...`);
        continue;
      }
      throw err;
    }
  }

  // If every key returned 402, flag this as a credit-exhaustion error so the
  // pipeline can pause gracefully and resume when credits are topped up.
  const finalErr = new Error(`[VideoGen] All Magic Hour keys exhausted. Last: ${lastError?.message}`);
  if (hadCreditError) finalErr.mhExhausted = true;
  throw finalErr;
}

/**
 * Poll a Magic Hour job until completion or exhaustion.
 * Returns the video download URL on success, throws on failure.
 */
async function pollVideoJob(jobId, apiKey) {
  const maxAttempts = config.magicHourMaxPollAttempts;
  const intervalMs  = config.magicHourPollIntervalMs;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    await sleep(intervalMs);
    try {
      const resp = await axios.get(
        `https://api.magichour.ai/v1/video-projects/${jobId}`,
        {
          headers: { 'Authorization': `Bearer ${apiKey}` },
          timeout: 20000,
        }
      );
      const proj = resp.data;
      if (proj.status === 'complete') {
        const videoUrl = proj?.downloads?.[0]?.url;
        if (!videoUrl) throw new Error('Magic Hour: complete but no video URL in response');
        config.markKeyStatus('magicHour', apiKey, 'active');
        return videoUrl;
      }
      if (['error', 'canceled'].includes(proj.status)) {
        throw new Error(`Magic Hour job ${jobId} failed: ${proj?.error?.message || proj.status}`);
      }
      // still pending - loop
      console.log(`[VideoGen] Job ${jobId} still pending (attempt ${attempt}/${maxAttempts})`);
    } catch (err) {
      if (err.response?.status === 429) {
        config.markKeyStatus('magicHour', apiKey, 'rate-limited');
        console.warn('[VideoGen] Rate-limited during poll, will retry...');
        continue;
      }
      throw err;
    }
  }
  throw new Error(`[VideoGen] Job ${jobId} did not complete after ${maxAttempts} attempts`);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { submitVideoJob, pollVideoJob };
