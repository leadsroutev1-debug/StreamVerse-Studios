'use strict';
/**
 * StreamVerse Image Generation Router
 *
 * All image generation — shots, character portraits, scene images — is routed
 * exclusively through the Cloudflare Worker AI endpoint.
 *
 * Google Gemini is kept as a fallback ONLY when CF_WORKER_URL / CF_WORKER_KEYS
 * are not configured at all (i.e. dev environments with no CF worker set up).
 *
 * CFSafetyRefusalError is re-thrown immediately so the caller (pipeline) can
 * rewrite the prompt instead of wasting the Google fallback on a flagged prompt.
 */
const config         = require('./config');
const googleImageGen = require('./googleImageGen');
const cfImageGen     = require('./cfImageGen');
const { CFSafetyRefusalError } = cfImageGen;

async function generateImage(prompt, referenceImageUrls = [], seed = null, negativePrompt = null) {
  // ── Cloudflare Worker AI (primary — all image generation goes here) ───────
  if (config.cfWorkerUrls.length > 0 && config.cfWorkerKeys.length > 0) {
    try {
      return await cfImageGen.generateImage(prompt, referenceImageUrls, seed, negativePrompt);
    } catch (err) {
      // Content-flagged prompts should NOT fall back — re-throw so the caller
      // can sanitise the prompt and retry with the CF worker.
      if (err instanceof CFSafetyRefusalError) throw err;
      console.warn('[ImageGen] CF Worker failed — falling back to Google Gemini:', err.message);
    }
  }

  // ── Google Gemini (fallback — only when CF worker is not configured) ──────
  if (config.googleKeys.length > 0) {
    return googleImageGen.generateImage(prompt, referenceImageUrls, seed, negativePrompt);
  }

  throw new Error('[ImageGen] No image generation backend configured (CF_WORKER_URL + CF_WORKER_KEYS or GOOGLE_KEYS required)');
}

module.exports = { generateImage, CFSafetyRefusalError };
