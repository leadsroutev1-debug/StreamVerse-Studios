'use strict';
const axios  = require('axios');
const config = require('./config');
const telegram = require('./telegram');

const GV   = config.facebookGraphVersion;
const BASE = `https://graph.facebook.com/${GV}`;

// ──────────────────────────────────────────────────────────────────────────────
// Token management — runtime-replaceable, self-refreshing
// ──────────────────────────────────────────────────────────────────────────────

// Facebook OAuth error codes that indicate token expiry / invalidity
const TOKEN_EXPIRY_CODES = new Set([190, 102, 463, 467]);

/**
 * Wrap an axios call and intercept Facebook token expiry errors.
 * On expiry: attempt long-lived token refresh once, then retry the original call.
 * On repeated failure: alert via Telegram and throw.
 */
async function fbRequest(fn) {
  try {
    return await fn(config.getFbToken());
  } catch (err) {
    const fbCode = err.response?.data?.error?.code;
    if (TOKEN_EXPIRY_CODES.has(fbCode)) {
      console.warn(`[Facebook] Token error (code ${fbCode}), attempting refresh...`);
      const refreshed = await refreshLongLivedToken();
      if (refreshed) {
        try {
          return await fn(config.getFbToken()); // retry with new token
        } catch (retryErr) {
          const msg = `❌ Facebook token refresh succeeded but request still failed: ${retryErr.message}`;
          await telegram.sendTelegram(msg);
          config.setFbTokenStatus('exhausted');
          throw retryErr;
        }
      } else {
        const msg = `❌ Facebook Page Access Token expired and auto-refresh failed.\nRenew <b>FACEBOOK_PAGE_ACCESS_TOKEN</b> in Replit Secrets.`;
        await telegram.sendTelegram(msg);
        config.setFbTokenStatus('exhausted');
        throw new Error('[Facebook] Token expired and refresh failed — renew FACEBOOK_PAGE_ACCESS_TOKEN');
      }
    }
    throw err;
  }
}

/**
 * Exchange the short-lived token for a long-lived one via the Graph API.
 * Requires FACEBOOK_APP_ID and FACEBOOK_APP_SECRET to be set.
 * Updates the in-memory token if successful.
 * Returns true on success, false on failure.
 */
async function refreshLongLivedToken() {
  if (!config.facebookAppId || !config.facebookAppSecret) {
    console.warn('[Facebook] Cannot refresh token: FACEBOOK_APP_ID / FACEBOOK_APP_SECRET not set');
    return false;
  }
  try {
    const resp = await axios.get(`${BASE}/oauth/access_token`, {
      params: {
        grant_type:        'fb_exchange_token',
        client_id:          config.facebookAppId,
        client_secret:      config.facebookAppSecret,
        fb_exchange_token:  config.getFbToken(),
      },
      timeout: 20000,
    });
    const newToken = resp.data?.access_token;
    if (!newToken) throw new Error('No access_token in refresh response');
    config.setFbToken(newToken);
    config.setFbTokenStatus('active');
    console.log('[Facebook] Token refreshed successfully');
    await telegram.sendTelegram('✅ Facebook Page Access Token auto-refreshed successfully.');
    return true;
  } catch (err) {
    console.error('[Facebook] Token refresh failed:', err.message);
    return false;
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Upload & publish
// ──────────────────────────────────────────────────────────────────────────────

async function uploadVideo(videoUrl, title, description) {
  return fbRequest(async (token) => {
    const dlResp = await axios.get(videoUrl, { responseType: 'arraybuffer', timeout: 180000 });
    const buffer = Buffer.from(dlResp.data);
    const fileSizeBytes = buffer.length;

    // Step 1: Start upload session
    const startResp = await axios.post(
      `https://graph-video.facebook.com/${GV}/${config.facebookPageId}/video_reels`,
      null,
      { params: { upload_phase: 'start', access_token: token }, timeout: 30000 }
    );
    _checkFbError(startResp.data);
    const uploadSessionId = startResp.data?.upload_session_id || startResp.data?.video_id;
    if (!uploadSessionId) {
      throw new Error(`[Facebook] Failed to start upload session: ${JSON.stringify(startResp.data)}`);
    }

    // Step 2: Transfer bytes
    await axios.post(
      `https://graph-video.facebook.com/${GV}/${config.facebookPageId}/video_reels`,
      buffer,
      {
        params: {
          upload_phase:      'transfer',
          upload_session_id:  uploadSessionId,
          access_token:       token,
          offset:             0,
          file_size:          fileSizeBytes,
        },
        headers: {
          'Content-Type': 'application/octet-stream',
          'offset':       '0',
          'file_size':    String(fileSizeBytes),
        },
        maxBodyLength: Infinity,
        timeout:       300000,
      }
    );

    // Step 3: Finish / publish
    const finishResp = await axios.post(
      `https://graph.facebook.com/${GV}/${config.facebookPageId}/video_reels`,
      null,
      {
        params: {
          upload_phase:      'finish',
          upload_session_id:  uploadSessionId,
          access_token:       token,
          title,
          description,
          content_category:  'ENTERTAINMENT',
          embeddable:        true,
          published:         true,
        },
        timeout: 60000,
      }
    );
    _checkFbError(finishResp.data);

    const videoId = finishResp.data?.video_id || uploadSessionId;
    if (!videoId) throw new Error(`[Facebook] Upload finish: ${JSON.stringify(finishResp.data)}`);
    config.setFbTokenStatus('active');
    return String(videoId);
  });
}

async function pollVideoStatus(videoId, maxAttempts = 30, intervalMs = 15000) {
  for (let i = 0; i < maxAttempts; i++) {
    await sleep(intervalMs);
    const resp = await fbRequest((token) =>
      axios.get(`${BASE}/${videoId}`, {
        params: { fields: 'status,permalink_url', access_token: token },
        timeout: 20000,
      })
    );
    const status = resp.data?.status?.video_status || resp.data?.status;
    if (status === 'ready') {
      const perm = resp.data.permalink_url;
      return perm ? `https://www.facebook.com${perm}` : `https://www.facebook.com/${videoId}`;
    }
    if (status === 'error') {
      throw new Error(`[Facebook] Video ${videoId} processing error: ${JSON.stringify(resp.data)}`);
    }
    console.log(`[Facebook] Video ${videoId} status=${status} (${i + 1}/${maxAttempts})`);
  }
  return `https://www.facebook.com/${videoId}`;
}

async function createPlaylist(title, description) {
  try {
    const resp = await fbRequest((token) =>
      axios.post(`${BASE}/${config.facebookPageId}/video_lists`, null, {
        params: { title, description, access_token: token },
        timeout: 20000,
      })
    );
    return resp.data?.id || null;
  } catch (err) {
    console.warn('[Facebook] createPlaylist failed:', err.message);
    return null;
  }
}

async function addToPlaylist(playlistId, videoId) {
  if (!playlistId) return;
  try {
    await fbRequest((token) =>
      axios.post(`${BASE}/${playlistId}/videos`, null, {
        params: { video_id: videoId, access_token: token },
        timeout: 20000,
      })
    );
  } catch (err) {
    console.warn('[Facebook] addToPlaylist failed:', err.message);
  }
}

async function postReel(videoUrl, caption) {
  try {
    return await uploadVideo(videoUrl, 'StreamVerse Clip', caption);
  } catch (err) {
    console.warn('[Facebook] postReel failed:', err.message);
    return null;
  }
}

/**
 * Post a plain text/photo announcement to the Facebook Page feed.
 * Used for Series Premiere and Series Finale announcements.
 * Returns the post ID or null on failure.
 */
async function postTextAnnouncement(message) {
  try {
    const resp = await fbRequest((token) =>
      axios.post(`${BASE}/${config.facebookPageId}/feed`, null, {
        params: { message, access_token: token },
        timeout: 20000,
      })
    );
    const postId = resp.data?.id;
    console.log(`[Facebook] Announcement posted: ${postId}`);
    return postId || null;
  } catch (err) {
    console.warn('[Facebook] postTextAnnouncement failed:', err.message);
    return null;
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Comment engagement — fetch + reply
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Fetch recent top-level comments on a video.
 * Returns an array of { id, message, from } objects.
 */
async function fetchVideoComments(videoId, limit = 25) {
  try {
    const resp = await fbRequest((token) =>
      axios.get(`${BASE}/${videoId}/comments`, {
        params: {
          fields:       'id,message,from',
          limit,
          access_token: token,
        },
        timeout: 20000,
      })
    );
    return resp.data?.data || [];
  } catch (err) {
    console.warn('[Facebook] fetchVideoComments failed:', err.message);
    return [];
  }
}

/**
 * Post a reply to a comment.
 * Returns the new comment ID or null.
 */
async function replyToComment(commentId, message) {
  try {
    const resp = await fbRequest((token) =>
      axios.post(`${BASE}/${commentId}/comments`, null, {
        params: { message, access_token: token },
        timeout: 20000,
      })
    );
    return resp.data?.id || null;
  } catch (err) {
    console.warn('[Facebook] replyToComment failed:', err.message);
    return null;
  }
}

/**
 * Post a like (reaction) on a comment to boost organic signals.
 */
async function likeComment(commentId) {
  try {
    await fbRequest((token) =>
      axios.post(`${BASE}/${commentId}/likes`, null, {
        params: { access_token: token },
        timeout: 10000,
      })
    );
  } catch (err) {
    console.warn('[Facebook] likeComment failed:', err.message);
  }
}

/**
 * Fetch the Page's own recent videos with their comment counts and permalink.
 * Used to find posts worth engaging on.
 */
async function fetchRecentVideos(limit = 5) {
  try {
    const resp = await fbRequest((token) =>
      axios.get(`${BASE}/${config.facebookPageId}/videos`, {
        params: {
          fields:       'id,title,permalink_url,comments.summary(true)',
          limit,
          access_token: token,
        },
        timeout: 20000,
      })
    );
    return resp.data?.data || [];
  } catch (err) {
    console.warn('[Facebook] fetchRecentVideos failed:', err.message);
    return [];
  }
}

/**
 * Post an image + caption to the Page feed.
 * imageUrl must be publicly accessible.
 */
async function postImageWithCaption(imageUrl, caption) {
  try {
    const resp = await fbRequest((token) =>
      axios.post(`${BASE}/${config.facebookPageId}/photos`, null, {
        params: {
          url:          imageUrl,
          caption,
          published:    true,
          access_token: token,
        },
        timeout: 30000,
      })
    );
    const postId = resp.data?.id || resp.data?.post_id || null;
    console.log(`[Facebook] Image post published: ${postId}`);
    return postId;
  } catch (err) {
    console.warn('[Facebook] postImageWithCaption failed:', err.message);
    return null;
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────────────

function _checkFbError(data) {
  if (data?.error) {
    const err = new Error(`Facebook API error: ${data.error.message}`);
    err.response = { data };
    throw err;
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

module.exports = {
  uploadVideo,
  pollVideoStatus,
  createPlaylist,
  addToPlaylist,
  postReel,
  postTextAnnouncement,
  fetchRecentVideos,
  fetchVideoComments,
  replyToComment,
  likeComment,
  postImageWithCaption,
  refreshLongLivedToken,
};
