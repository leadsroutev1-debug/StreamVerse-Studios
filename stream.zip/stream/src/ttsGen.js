'use strict';
/**
 * TTS helpers for StreamVerse shot audio.
 *
 * Uses Deepgram's TTS API to convert shot dialogue text into MP3 audio,
 * which is then uploaded to Cloudinary and passed to Magic Hour's
 * ai-talking-photo endpoint.
 *
 * Keys are rotated automatically on quota exhaustion (402/429/401).
 * Set DEEPGRAK_KEYS to a comma-separated list of Deepgram API keys.
 *
 * Only dialogue shots shown in close-up get talking-photo treatment.
 * All other shots get ambient AI audio via image-to-video's audio:true flag.
 *
 * Voice selection: male characters use male Deepgram Aura voices,
 * female characters use female voices. Gender is detected from the
 * character's description/visual_profile pronouns and keywords.
 */
const axios      = require('axios');
const cloudinary = require('./cloudinary');
const config     = require('./config');

// Shot pacing types that contain spoken dialogue
const DIALOGUE_PACING_TYPES = new Set(['dialogue_mid', 'dialogue_full']);

// Shot types where a face is large enough for lip-sync to look good
const CLOSE_UP_SHOT_TYPES = new Set(['ECU', 'CU', 'MCU', 'OTS']);

// ── Deepgram Aura voice pools by gender ───────────────────────────────────────
// Female voices — natural, expressive English
const FEMALE_VOICES = [
  'aura-asteria-en',   // warm, natural
  'aura-luna-en',      // soft, expressive
  'aura-stella-en',    // bright, clear
];
// Male voices — natural, expressive English
const MALE_VOICES = [
  'aura-zeus-en',      // deep, authoritative
  'aura-orion-en',     // warm, conversational
  'aura-arcas-en',     // natural, smooth
];
// Default fallback
const DEFAULT_VOICE = 'aura-asteria-en';

/**
 * Detect the gender of a character from their description and visual_profile.
 * Uses pronoun and keyword frequency — not perfect but reliable for
 * LLM-generated character bibles that always include "he/she" pronouns.
 *
 * Returns 'male', 'female', or 'unknown'.
 */
function detectCharacterGender(character) {
  if (!character) return 'unknown';

  // Check visual_profile for an explicit gender field first
  try {
    const vp = typeof character.visual_profile === 'string'
      ? JSON.parse(character.visual_profile || '{}')
      : (character.visual_profile || {});
    const explicit = (vp.gender || vp.sex || '').toLowerCase();
    if (explicit === 'male' || explicit === 'm') return 'male';
    if (explicit === 'female' || explicit === 'f') return 'female';
  } catch {}

  // Pronoun/keyword counting in description + visual_anchor
  const text = [
    character.description || '',
    character.visual_anchor || '',
    character.name || '',
  ].join(' ').toLowerCase();

  const maleMatches = (text.match(
    /\b(he|his|him|man|men|boy|male|masculine|gentleman|father|brother|son|uncle|husband|boyfriend)\b/g
  ) || []).length;

  const femaleMatches = (text.match(
    /\b(she|her|hers|woman|women|girl|female|feminine|lady|mother|sister|daughter|aunt|wife|girlfriend)\b/g
  ) || []).length;

  if (maleMatches > femaleMatches) return 'male';
  if (femaleMatches > maleMatches) return 'female';
  return 'unknown';
}

/**
 * Select the best Deepgram TTS voice for a character.
 * Picks the primary voice for the detected gender, falling back to default.
 */
function selectVoiceForCharacter(character) {
  const gender = detectCharacterGender(character);
  if (gender === 'male')   return MALE_VOICES[0];
  if (gender === 'female') return FEMALE_VOICES[0];
  return DEFAULT_VOICE;
}

/**
 * Return true when this shot should use ai-talking-photo instead of image-to-video.
 * Requires both a dialogue pacing type AND a close-up shot framing.
 */
function shouldUseTalkingPhoto(shot) {
  return DIALOGUE_PACING_TYPES.has(shot.shot_pacing_type) &&
         CLOSE_UP_SHOT_TYPES.has(shot.shot_type);
}

/**
 * Parse the speaker name prefix from dialogue_or_action when the script
 * writer emits the "NAME: text" format used for multi-character scenes.
 *
 * Examples:
 *   "ELENA: I never meant to hurt you."  → "ELENA"
 *   "DR. HAYES: We need to talk."        → "DR. HAYES"
 *   "She turns and walks away."          → null  (no speaker prefix)
 *
 * The match is case-insensitive but the returned name is normalised to
 * Title Case so it can be compared directly against character.name values
 * that the script writer always writes in Title Case.
 *
 * Returns the speaker name string, or null when no prefix is present.
 */
function extractSpeakerName(dialogueOrAction) {
  if (!dialogueOrAction || typeof dialogueOrAction !== 'string') return null;

  // Pattern: optional leading quote, then WORD / "DR. HAYES" style name (all-caps
  // or mixed-caps), followed by a colon and at least one space.
  // We only match when the prefix is 1–5 words (avoids matching stage-direction
  // sentences that happen to contain a colon, e.g. "She thought: what now?").
  const match = dialogueOrAction.trim().match(
    /^["'"']*([A-ZÁÉÍÓÚ][A-ZÁÉÍÓÚa-z'.]+(?:\s+[A-ZÁÉÍÓÚ][A-ZÁÉÍÓÚa-z'.]*){0,4})\s*:\s+/
  );
  if (!match) return null;

  // Normalise to Title Case (each word capitalised)
  const raw = match[1].trim();
  return raw
    .split(/\s+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}

/**
 * Extract the spoken words from dialogue_or_action, stripping the
 * parenthetical subtext that the script writer always appends.
 *
 * "I love you — always have. (but she knows it's goodbye)" → "I love you — always have."
 * "ELENA: I never meant to hurt you."                      → "I never meant to hurt you."
 *
 * Returns null when the text is empty or reads as a pure stage direction.
 */
function extractDialogueText(dialogueOrAction) {
  if (!dialogueOrAction || typeof dialogueOrAction !== 'string') return null;

  // Strip speaker prefix ("NAME: ") if present before further processing
  let text = dialogueOrAction.replace(
    /^["'"']*[A-ZÁÉÍÓÚ][A-ZÁÉÍÓÚa-z'.]+(?:\s+[A-ZÁÉÍÓÚ][A-ZÁÉÍÓÚa-z'.]*){0,4}\s*:\s+/,
    ''
  );

  // Strip all parenthetical subtext
  text = text.replace(/\([^)]*\)/g, '').trim();

  // Remove leading/trailing quote characters that may wrap the dialogue
  text = text.replace(/^["'""'']+|["'""'']+$/g, '').trim();

  if (!text || text.length < 3) return null;

  // Deepgram handles longer text well but cap at 500 chars gracefully
  if (text.length > 500) {
    text = text.slice(0, 500).replace(/\s\S*$/, '').trim();
  }

  return text || null;
}

/**
 * Generate TTS audio for `text` via Deepgram's TTS API,
 * upload the MP3 to Cloudinary, and return { audioUrl, durationSeconds }.
 *
 * Rotates through DEEPGRAK_KEYS on quota / rate-limit errors (402, 429, 401).
 * Selects a voice appropriate for the speaking character's gender.
 *
 * @param {string}      text       Dialogue text to synthesise
 * @param {string}      publicId   Cloudinary public_id for the audio asset
 * @param {object|null} character  Character object (for voice selection); null → default voice
 */
async function generateAndUploadTTS(text, publicId, character = null) {
  const keys = config.deepgramKeys;
  if (!keys.length) {
    throw new Error('[TTS] No Deepgram keys configured — set DEEPGRAK_KEYS env var');
  }

  const voice  = selectVoiceForCharacter(character);
  const gender = detectCharacterGender(character);
  console.log(
    `[TTS] Voice selected: ${voice} (${gender}) for ${character?.name || 'unknown character'}`
  );

  let lastError;
  for (let attempt = 0; attempt < keys.length; attempt++) {
    const key = config.getNextDeepgramKey();
    try {
      const resp = await axios.post(
        `https://api.deepgram.com/v1/speak?model=${voice}`,
        { text },
        {
          headers: {
            'Authorization': `Token ${key}`,
            'Content-Type':  'application/json',
          },
          responseType: 'arraybuffer',
          timeout:      25000,
        }
      );

      const buf = Buffer.from(resp.data);
      if (!buf || buf.length < 200) {
        throw new Error(`[TTS] Empty audio response (${buf?.length ?? 0} bytes)`);
      }

      // Upload as a Cloudinary video resource (Cloudinary stores audio under the video type)
      const audioUrl = await cloudinary.uploadVideoFromUrl(
        `data:audio/mpeg;base64,${buf.toString('base64')}`,
        publicId
      );

      // Estimate duration: ~16 bytes/ms for 128kbps MP3 → ÷16000 = seconds
      // Clamp to [2, 15] seconds (MH min/max for talking-photo)
      const durationSeconds = Math.min(15, Math.max(2, Math.ceil(buf.length / 16000)));

      config.markKeyStatus('deepgram', key, 'active');
      console.log(
        `[TTS] Deepgram (${voice}): "${text.slice(0, 60)}${text.length > 60 ? '…' : ''}" ` +
        `→ ${buf.length} bytes, ~${durationSeconds}s — ${audioUrl}`
      );
      return { audioUrl, durationSeconds };

    } catch (err) {
      lastError = err;
      const status = err.response?.status;

      if ((status === 402 || status === 429 || status === 401) && attempt < keys.length - 1) {
        config.markKeyStatus('deepgram', key, status === 429 ? 'rate-limited' : 'exhausted');
        console.warn(`[TTS] Deepgram key failed (HTTP ${status}), rotating to next key...`);
        continue; // try next key
      }

      // Non-quota error or last key — throw immediately
      const body = err.response?.data
        ? Buffer.from(err.response.data).toString('utf8').slice(0, 200)
        : err.message;
      throw new Error(`[TTS] Deepgram failed: ${body}`);
    }
  }

  throw new Error(`[TTS] All Deepgram keys exhausted. Last: ${lastError?.message}`);
}

module.exports = {
  shouldUseTalkingPhoto,
  extractDialogueText,
  extractSpeakerName,
  generateAndUploadTTS,
  detectCharacterGender,
  selectVoiceForCharacter,
};
