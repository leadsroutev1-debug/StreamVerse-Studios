'use strict';
const axios      = require('axios');
const fs         = require('fs');
const path       = require('path');
const crypto     = require('crypto');
const FormData   = require('form-data');
const config     = require('./config');

function _authHeader() {
  const creds = Buffer.from(`${config.cloudinaryApiKey}:${config.cloudinaryApiSecret}`).toString('base64');
  return `Basic ${creds}`;
}

// ── Logo watermark ─────────────────────────────────────────────────────────────
// The logo is uploaded to Cloudinary once at bootstrap under a fixed public_id.
// Cloudinary overlay transformations reference it by that id.
const LOGO_PUBLIC_ID = 'streamverse/logo/watermark_block';

// Cloudinary replaces "/" with ":" in overlay layer identifiers
const _logoLayerId = () => LOGO_PUBLIC_ID.replace(/\//g, ':');

/**
 * Upload logo/Logo.png to Cloudinary as a named image (idempotent — overwrites if present).
 * Uses a signed upload so it works regardless of upload-preset restrictions.
 * Must be called once at bootstrap before buildLogoOverlayUrl is used.
 */
async function uploadLogo() {
  const logoPath = path.join(__dirname, '..', 'logo', 'Logo.png');
  let logoData;
  try {
    logoData = fs.readFileSync(logoPath);
  } catch {
    console.warn('[Cloudinary] logo/Logo.png not found — video logo overlay disabled');
    return null;
  }

  // Build signed upload — avoids unsigned-preset restrictions on public_id / overwrite
  const timestamp = Math.floor(Date.now() / 1000);
  // Parameters must be sorted alphabetically for signature
  const paramsToSign = `overwrite=true&public_id=${LOGO_PUBLIC_ID}&timestamp=${timestamp}`;
  const signature = crypto
    .createHash('sha1')
    .update(paramsToSign + config.cloudinaryApiSecret)
    .digest('hex');

  const form = new FormData();
  form.append('file',       logoData, { filename: 'Logo.png', contentType: 'image/png' });
  form.append('public_id',  LOGO_PUBLIC_ID);
  form.append('overwrite',  'true');
  form.append('timestamp',  String(timestamp));
  form.append('api_key',    config.cloudinaryApiKey);
  form.append('signature',  signature);

  try {
    const resp = await axios.post(
      `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/image/upload`,
      form,
      { headers: form.getHeaders(), timeout: 60000 }
    );
    const url = resp.data?.secure_url;
    if (url) {
      console.log(`[Cloudinary] Logo uploaded for video overlay: ${url}`);
    } else {
      console.warn('[Cloudinary] Logo upload returned no URL:', JSON.stringify(resp.data).slice(0, 200));
    }
    return url;
  } catch (err) {
    const detail = err.response?.data ? JSON.stringify(err.response.data).slice(0, 200) : err.message;
    console.warn('[Cloudinary] Logo upload failed:', detail);
    return null;
  }
}

// ── Background music public_id ─────────────────────────────────────────────────
// Set by uploadBackgroundMusic() at bootstrap, or via CLOUDINARY_BACKGROUND_MUSIC_ID env var.
// When set, buildLogoOverlayUrl adds a looping background audio layer to every video URL.
let _bgMusicPublicId = process.env.CLOUDINARY_BACKGROUND_MUSIC_ID || null;

/**
 * Upload a background music MP3/audio file to Cloudinary (once at bootstrap).
 * Stored at streamverse/audio/ambient_bg as a video resource (Cloudinary stores audio as video).
 * Idempotent — if the asset already exists it is not re-uploaded.
 *
 * @param {string} sourceUrl  Public URL of a CC0/royalty-free audio file.
 */
async function uploadBackgroundMusic(sourceUrl) {
  if (!sourceUrl) return null;
  const publicId = 'streamverse/audio/ambient_bg';

  // Check if already uploaded to avoid redundant uploads
  try {
    const check = await axios.get(
      `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/resources/video/upload/${publicId}`,
      { headers: { Authorization: _authHeader() }, timeout: 10000 }
    );
    if (check.data?.secure_url) {
      console.log('[Cloudinary] Background music already uploaded:', check.data.secure_url);
      _bgMusicPublicId = publicId;
      return check.data.secure_url;
    }
  } catch { /* not yet uploaded — proceed */ }

  try {
    const params = new URLSearchParams({
      file:           sourceUrl,
      public_id:      publicId,
      resource_type:  'video',   // Cloudinary stores audio under video resource type
      upload_preset:  config.cloudinaryUploadPreset,
      // Note: 'overwrite' is not sent — unsigned presets don't allow it.
      // The existence check above prevents re-uploading an existing asset.
    });
    const resp = await axios.post(
      `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/video/upload`,
      params.toString(),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 60000 }
    );
    if (resp.data?.secure_url) {
      console.log('[Cloudinary] Background music uploaded:', resp.data.secure_url);
      _bgMusicPublicId = publicId;
      return resp.data.secure_url;
    }
  } catch (err) {
    const detail = err.response?.data ? JSON.stringify(err.response.data).slice(0, 200) : err.message;
    console.warn('[Cloudinary] Background music upload failed:', detail);
  }
  return null;
}

/**
 * Given a Cloudinary video secure_url, return a new URL that:
 *   1. Forces best-quality delivery (q_auto:best)
 *   2. Overlays the StreamVerse logo at the BOTTOM-RIGHT corner (south-east gravity)
 *      to cover the "Generated by Magic Hour" watermark, which pixel-analysis
 *      confirms sits at bottom-right (~436px wide on 1080px video, ~24px from edge).
 *      Logo is sized at w_460 to cover it with margin, matching measured dimensions.
 *   3. Adds a looping background music audio layer when a music asset is available
 *      (uploaded via uploadBackgroundMusic() at bootstrap or via CLOUDINARY_BACKGROUND_MUSIC_ID).
 *
 * Cloudinary applies all transformations at delivery time — no re-encoding needed.
 *
 * Example transformation chain:
 *   q_auto:best/l_streamverse:logo:watermark_block,g_south_east,x_10,y_20,w_460
 */
function buildLogoOverlayUrl(videoSecureUrl) {
  if (!videoSecureUrl) return videoSecureUrl;

  // ── 1. Quality ─────────────────────────────────────────────────────────────
  const quality = `q_auto:best`;

  // ── 2. Logo overlay — south-east (bottom-right), sized to cover MH watermark ─
  // Pixel analysis: MH watermark is ~436px wide at bottom-right, 24px from edge.
  // w_460 = 460px width gives ~24px margin on each side of the watermark text.
  const logoOverlay = `l_${_logoLayerId()},g_south_east,x_10,y_20,w_460`;

  let transforms = `${quality}/${logoOverlay}`;

  // ── 3. Background music (optional) ────────────────────────────────────────
  // Uses Cloudinary's video-layer audio overlay (audio files are stored as
  // video resources in Cloudinary). e_loop loops the track to match video duration.
  const bgId = _bgMusicPublicId;
  if (bgId) {
    const layerId = bgId.replace(/\//g, ':');
    transforms += `/l_video:${layerId},e_loop/fl_layer_apply`;
  }

  return videoSecureUrl.replace('/upload/', `/upload/${transforms}/`);
}

/**
 * Build a signed upload parameter set.
 * Cloudinary requires a SHA-1 signature over sorted params (excluding file,
 * api_key, resource_type, and cloud_name) appended with the api_secret.
 * This lets us set any public_id, overwrite, etc. regardless of preset restrictions.
 */
function _buildSignedParams(extraParams) {
  const timestamp = Math.floor(Date.now() / 1000);
  const signable  = { ...extraParams, timestamp };
  // Sort keys alphabetically and build the string to sign
  const toSign = Object.keys(signable)
    .sort()
    .map(k => `${k}=${signable[k]}`)
    .join('&');
  const signature = crypto
    .createHash('sha1')
    .update(toSign + config.cloudinaryApiSecret)
    .digest('hex');
  return { ...signable, api_key: config.cloudinaryApiKey, signature };
}

/**
 * Upload a video from a URL or base64 data URI to Cloudinary using a signed request.
 * Signed uploads work regardless of upload-preset restrictions on public_id / overwrite.
 * Returns the secure_url of the uploaded resource.
 */
async function uploadVideoFromUrl(sourceUrl, publicId) {
  const signed = _buildSignedParams({ public_id: publicId, overwrite: 'true' });
  const params = new URLSearchParams({ file: sourceUrl, resource_type: 'video', ...signed });
  const resp = await axios.post(
    `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/video/upload`,
    params.toString(),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 120000 }
  );
  if (!resp.data?.secure_url) {
    throw new Error(`Cloudinary video upload failed: ${JSON.stringify(resp.data).slice(0, 300)}`);
  }
  return resp.data.secure_url;
}

/**
 * Upload a video from a raw buffer to Cloudinary using the signed upload.
 */
async function uploadVideoBuffer(buffer, publicId) {
  const dataUri = `data:video/mp4;base64,${buffer.toString('base64')}`;
  return uploadVideoFromUrl(dataUri, publicId);
}

/**
 * Upload an image from URL or data URI using a signed request.
 * Signed uploads work regardless of upload-preset restrictions on public_id / overwrite.
 */
async function uploadImageFromUrl(sourceUrl, publicId) {
  const signed = _buildSignedParams({ public_id: publicId, overwrite: 'true' });
  const params = new URLSearchParams({ file: sourceUrl, resource_type: 'image', ...signed });
  const resp = await axios.post(
    `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/image/upload`,
    params.toString(),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 60000 }
  );
  if (!resp.data?.secure_url) {
    throw new Error(`Cloudinary image upload failed: ${JSON.stringify(resp.data).slice(0, 300)}`);
  }
  return resp.data.secure_url;
}

/**
 * List all video resources under a folder prefix.
 * Returns sorted array of { public_id, secure_url }.
 */
async function listFolder(folderPrefix) {
  const resp = await axios.get(
    `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/resources/video/upload`,
    {
      params:  { prefix: folderPrefix, type: 'upload', max_results: 500 },
      headers: { Authorization: _authHeader() },
      timeout: 30000,
    }
  );
  if (resp.status < 200 || resp.status >= 300) {
    throw new Error(`Cloudinary folder list failed: ${JSON.stringify(resp.data)}`);
  }
  return (resp.data.resources || [])
    .sort((a, b) => a.public_id.localeCompare(b.public_id));
}

/**
 * Delete a resource by public_id.
 */
async function deleteResource(publicId, resourceType = 'video') {
  try {
    await axios.delete(
      `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/resources/${resourceType}/upload`,
      {
        params:  { public_ids: [publicId] },
        headers: { Authorization: _authHeader() },
        timeout: 30000,
      }
    );
  } catch (err) {
    console.warn(`[Cloudinary] Failed to delete ${publicId}:`, err.message);
  }
}

/**
 * Build the public_id for the persistent scene background reference image.
 * Stored outside the tmp/ folder so it is NOT deleted by the episode cleanup loop.
 * Pattern: {shotsFolderRoot}/{storylineId}/ep{NNNN}/scene_{NN}/bg_ref
 *
 * storylineId is included so assets from different storylines with the same
 * episode number never share a path (globalEpisodeNumber is per-storyline, so
 * two active storylines can legitimately both be on episode 1).
 */
function sceneBgPublicId(storylineId, episodeNumber, sceneNumber) {
  return [
    config.shotsFolderRoot,
    storylineId,
    `ep${String(episodeNumber).padStart(4, '0')}`,
    `scene_${String(sceneNumber).padStart(2, '0')}`,
    'bg_ref',
  ].join('/');
}

/**
 * Build the public_id for a shot clip.
 * Pattern: {shotsFolderRoot}/ep{NNNN}/scene_{NN}/shot_{NN}
 * Human-readable: e.g. streamverse/shots/ep0003/scene_02/shot_04
 */
function shotPublicId(storylineId, episodeNumber, sceneNumber, shotIndex) {
  return [
    config.shotsFolderRoot,
    `ep${String(episodeNumber).padStart(4, '0')}`,
    `scene_${String(sceneNumber).padStart(2, '0')}`,
    `shot_${String(shotIndex).padStart(2, '0')}`,
  ].join('/');
}

/**
 * Build the public_id for a final episode video.
 * Pattern: {episodeFolderRoot}/ep{NNNN}
 */
function episodePublicId(storylineId, episodeNumber) {
  return `${config.episodeFolderRoot}/ep${String(episodeNumber).padStart(4, '0')}`;
}

/**
 * Build a deliverable Cloudinary image URL from a public_id.
 * Used to turn a stored imageTmpPublicId back into a URL that can be
 * passed as a reference image to the CF Worker for scene-BG consistency.
 */
function imageDeliveryUrl(publicId) {
  if (!publicId) return null;
  return `https://res.cloudinary.com/${config.cloudinaryCloudName}/image/upload/${publicId}`;
}

module.exports = {
  uploadLogo,
  uploadBackgroundMusic,
  buildLogoOverlayUrl,
  uploadVideoFromUrl,
  uploadVideoBuffer,
  uploadImageFromUrl,
  listFolder,
  deleteResource,
  sceneBgPublicId,
  shotPublicId,
  episodePublicId,
  imageDeliveryUrl,
};
