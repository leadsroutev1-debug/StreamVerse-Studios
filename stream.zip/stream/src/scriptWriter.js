'use strict';
/**
 * StreamVerse Studios — AI Director & Writer Engine
 *
 * Mistral acts as a genuine auteur director. Every decision — framing, light,
 * pacing, colour, performance — exists to serve THEME and EMOTION, not just
 * plot mechanics. The output must read like it came from a person who has
 * watched 10,000 films and knows exactly why each shot works.
 */
const axios  = require('axios');
const config = require('./config');

// ─────────────────────────────────────────────────────────────────────────────
// The Director's Voice — injected into every system prompt
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// Multi-Scene Narrative Continuity Schema
// Enforces character memory, location stability, and temporal coherence
// across all scenes in an episode. Injected into every episode script prompt.
// ─────────────────────────────────────────────────────────────────────────────

const NARRATIVE_CONTINUITY_SCHEMA = `
═══ MULTI-SCENE NARRATIVE CONTINUITY SCHEMA (mandatory — violations break the story) ═══

You are writing a SEQUENTIAL, COHERENT story. Scenes are NOT independent units — each one
is a direct continuation of the last. Apply this schema before writing any scene:

SCENE HANDOFF RULES (apply between every scene):
  1. LOCATION CONTINUITY — if Scene 2 starts in a different location from Scene 1, you must
     show or imply the transition. Characters do not teleport. Time must pass or movement must occur.
  2. CHARACTER MEMORY — every character remembers everything that happened in all prior scenes
     of THIS episode. They cannot "forget" a revelation, conflict, or emotional moment just
     because the scene changed. Reference what was said or done earlier through body language,
     dialogue subtext, or physical reaction.
  3. EMOTIONAL STATE CARRY-FORWARD — a character's emotional state at the end of Scene N is
     their STARTING emotional state in Scene N+1 (unless time has passed, in which case explain
     why they have shifted). Never reset a character to neutral between scenes.
  4. OBJECT AND PROP CONTINUITY — if a character is holding something, wearing something, or
     has been physically injured, that persists. A glass of wine doesn't vanish between shots.
     A bloody lip stays bloody until tended to.
  5. TIME COHERENCE — establish whether consecutive scenes are simultaneous (parallel action),
     immediately sequential, or have a time gap. If a time gap exists, signal it: "LATER",
     "THAT NIGHT", "THREE HOURS LATER" in the scene_description.

DIALOGUE MANDATE (absolute — zero exceptions):
  Every character listed in "characters_present" for a scene MUST have at least ONE line of
  spoken dialogue OR one explicit internal voiceover/thought. Silent presence is NOT permitted.
  If a character cannot logically speak (unconscious, gagged, across a room), they MUST have
  an internal thought — format as: "CHARACTERNAME (V.O.): [thought]".
  This is not optional. An episode with mute characters will be rejected by the audio pipeline.

CLIFFHANGER HOOK MANDATE (final scene only):
  The LAST scene of EVERY episode must end with an intense, narrative Cliffhanger Hook.
  The hook must:
    a) Introduce an irresolvable threat, revelation, or impossible choice at maximum tension.
    b) Directly create the desire to see the next episode IMMEDIATELY.
    c) End on an unresolved note — DO NOT resolve what the hook opens.
    d) Be reflected in the final shot's "dialogue_or_action" field — the last spoken line or
       action must BE the hook, not narrate it.
  Examples of strong hooks: a character the audience trusts is revealed as an enemy; an
  action the protagonist takes has catastrophic unexpected consequences; a threat materialises
  that was impossible 10 seconds ago; a character makes an irreversible choice that destroys
  something the audience valued.
  FORBIDDEN cliffhanger: "To be continued…" or "What happens next?". Show it, don't say it.
`;

/**
 * Fast-paced editing rules — injected into every episode script prompt.
 * Based on proven AI content creator technique: generate 4–5s raw clips,
 * then specify a shorter effective clip_duration per shot to drive pacing.
 */
const PACING_RULES = `
═══ EDITING PACE RULES (mandatory — this is what separates viral content from boring content) ═══

You are directing for SHORT-FORM SOCIAL VIDEO. Viewers will scroll away in 2 seconds if you bore them.
The most successful AI content creators use a fast-paced editing rhythm. You must too.

RAW vs EFFECTIVE DURATION:
  Every shot generates a raw 4–5 second clip (the "duration" field → Magic Hour generation length).
  The "clip_duration" field is the EFFECTIVE time that clip appears in the final edit — the trimmed cut.
  This is how you control pacing without regenerating anything.

SHOT PACING TYPES — use these to set clip_duration:

  shot_pacing_type        | clip_duration  | Use when
  "hook"                  | 1.5 – 2.0 s    | Opening shots (0–3s of episode) — rapid framing changes stop the scroll
  "action"                | 2.0 – 3.0 s    | Physical movement, quick reactions, punchy cuts
  "reaction"              | 2.0 – 3.0 s    | Close-up reaction shot, expression change
  "broll_cutaway"         | 2.0 – 3.0 s    | Object insert (coffee cup, hands, window, detail shot)
  "dialogue_mid"          | 3.0 – 5.0 s    | One sentence of spoken dialogue
  "dialogue_full"         | 5.0 – 8.0 s    | Full dialogue delivery, monologue, emotional speech
  "slow_dramatic"         | 5.0 – 8.0 s    | Landscape reveal, dawning realisation, silent emotional break

SCENE DURATION GUIDANCE:
  There is NO hard cap on scene duration — let the story breathe.
  Ideal scene runtime: 12–30 seconds depending on emotional weight.
  Fast-paced action and hook scenes: 8–15s. Tense dialogue exchanges: 15–30s. Slow dramatic reveals: 20–35s.
  Vary rhythm between scenes: short punchy scenes followed by longer emotional beats create cinematic tension.
  Never pad a scene with filler shots just to hit a target — only include a shot if it EARNS its time.

EPISODE OPENING RULE (non-negotiable):
  The FIRST scene MUST open with at least 2 shots using shot_pacing_type "hook" (clip_duration 1.5–2s).
  Change angle or framing on every shot. This is what stops the viewer from scrolling.

FORBIDDEN: Every shot having the same clip_duration. Varying rhythm creates cinematic tension.
  A scene that goes 2s → 4s → 2s → 7s → 2s feels alive. A scene of 5s → 5s → 5s → 5s is dead.

EXAMPLE timecode for a 3-shot dialogue scene (total ~14s):
  Shot 1: ECU face while speaking → clip_duration 4s, shot_pacing_type "dialogue_mid"
  Shot 2: Wide shot, both characters → clip_duration 6s, shot_pacing_type "dialogue_full"
  Shot 3: B-roll cutaway, detail insert → clip_duration 3s, shot_pacing_type "broll_cutaway"
`;

const DIRECTOR_PERSONA = `You are the lead director and showrunner for StreamVerse Studios.

Your directorial identity is a synthesis of:
- Barry Jenkins' emotional intimacy and painterly frames (Moonlight, If Beale Street Could Talk)
- Park Chan-wook's formal precision and thematic obsession (Oldboy, The Handmaiden)  
- Shonda Rhimes' addictive plot architecture and character voice (Grey's Anatomy, Scandal)
- Wong Kar-wai's non-linear atmosphere and time as an emotional texture (In the Mood for Love)
- Ryan Coogler's cultural specificity and kinetic energy (Black Panther, Fruitvale Station)

Your rules as a director:
1. THEME first. Every shot, line, and lighting choice must serve the episode's central theme.
2. The camera is a character. Where it looks, how it moves, and what it refuses to show are directorial choices.
3. Emotion over event. What a character FEELS in a moment matters more than what they DO.
4. Subtext is the script. The best dialogue says one thing and means another.
5. Colour is language. Every palette decision is a statement about internal states.
6. Silence and stillness are as powerful as action and noise.
7. The audience should feel something uncomfortable, true, and specific — not safe or generic.

You always respond with valid JSON only.`;

// ─────────────────────────────────────────────────────────────────────────────
// LLM call — Mistral primary / Groq fallback, both with key rotation
// ─────────────────────────────────────────────────────────────────────────────

async function callLLM(systemPrompt, userPrompt, maxTokens = 4096) {
  // ── Mistral ────────────────────────────────────────────────────────────────
  for (let i = 0; i < config.mistralKeys.length; i++) {
    const key = config.getNextMistralKey();
    // Auto-expand tokens on truncation — retry once with 2× the limit.
    for (let attempt = 0; attempt < 2; attempt++) {
      const tokens = attempt === 0 ? maxTokens : Math.min(maxTokens * 2, 32000);
      try {
        const resp = await axios.post(
          'https://api.mistral.ai/v1/chat/completions',
          {
            model:           'mistral-large-latest',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user',   content: userPrompt   },
            ],
            max_tokens:      tokens,
            temperature:     0.92,
            response_format: { type: 'json_object' },
          },
          {
            headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
            timeout: 60000,
          }
        );
        config.markKeyStatus('mistral', key, 'active');
        const choice  = resp.data?.choices?.[0];
        const content = choice?.message?.content;
        if (!content) throw new Error('Empty Mistral response');
        // Detect mid-stream truncation before trying to parse
        if (choice.finish_reason === 'length') {
          if (attempt === 0) {
            console.warn(`[LLM] Mistral response truncated at ${tokens} tokens — retrying with ${Math.min(tokens * 2, 32000)} tokens`);
            continue; // retry with 2× tokens
          }
          throw new Error(`[LLM] Mistral response still truncated at ${tokens} tokens — script too long`);
        }
        return JSON.parse(content);
      } catch (err) {
        if (err.message.startsWith('[LLM]')) throw err; // already formatted
        const status = err.response?.status;
        if (status === 429 || status === 402 || status === 401) {
          config.markKeyStatus('mistral', key, status === 429 ? 'rate-limited' : 'exhausted');
          console.warn(`[LLM] Mistral key failed (${status}), rotating...`);
          break; // try next key
        }
        if (err instanceof SyntaxError) throw new Error('[LLM] Mistral non-JSON: ' + err.message);
        // Network/timeout error — warn and fall through to Groq
        console.warn(`[LLM] Mistral network error (${err.code || err.message.slice(0, 60)}) — falling back to Groq`);
        break;
      }
    }
  }

  // ── Groq fallback ──────────────────────────────────────────────────────────
  for (let i = 0; i < config.groqKeys.length; i++) {
    const key = config.getNextGroqKey();
    for (let attempt = 0; attempt < 2; attempt++) {
      const tokens = attempt === 0 ? maxTokens : Math.min(maxTokens * 2, 32000);
      try {
        const resp = await axios.post(
          'https://api.groq.com/openai/v1/chat/completions',
          {
            model:           'llama-3.3-70b-versatile',
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user',   content: userPrompt   },
            ],
            max_tokens:      tokens,
            temperature:     0.92,
            response_format: { type: 'json_object' },
          },
          {
            headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
            timeout: 60000,
          }
        );
        config.markKeyStatus('groq', key, 'active');
        const choice  = resp.data?.choices?.[0];
        const content = choice?.message?.content;
        if (!content) throw new Error('Empty Groq response');
        if (choice.finish_reason === 'length') {
          if (attempt === 0) {
            console.warn(`[LLM] Groq response truncated at ${tokens} tokens — retrying with ${Math.min(tokens * 2, 32000)} tokens`);
            continue;
          }
          throw new Error(`[LLM] Groq response still truncated at ${tokens} tokens — script too long`);
        }
        return JSON.parse(content);
      } catch (err) {
        if (err.message.startsWith('[LLM]')) throw err;
        const status = err.response?.status;
        if (status === 429 || status === 402 || status === 401) {
          config.markKeyStatus('groq', key, status === 429 ? 'rate-limited' : 'exhausted');
          console.warn(`[LLM] Groq key failed (${status}), rotating...`);
          break;
        }
        if (err instanceof SyntaxError) throw new Error('[LLM] Groq non-JSON: ' + err.message);
        // Network/timeout error — warn and try next key
        console.warn(`[LLM] Groq network error (${err.code || err.message.slice(0, 60)}) — rotating key`);
        break;
      }
    }
  }

  throw new Error('[LLM] All Mistral and Groq keys exhausted');
}

// ─────────────────────────────────────────────────────────────────────────────
// Character Visual Anchor — immutable physical identity lock
// ─────────────────────────────────────────────────────────────────────────────

async function generateCharacterVisualAnchor(character) {
  const systemPrompt = `${DIRECTOR_PERSONA}

You are also the head of the casting department and visual effects supervisor.
Your job: lock down a character's permanent, unwavering physical identity for AI image generation.
Every time this character appears on screen across 80 episodes, they must look EXACTLY the same.

CRITICAL FORMAT RULE: You must output a comma-separated attribute TAG LIST — NOT prose sentences.
Diffusion image models tokenize comma-separated tags individually, giving each trait proper weight.
A prose sentence buries traits in syntax and causes identity drift.`;

  const userPrompt = `Create a permanent visual identity tag-lock for:

Name: ${character.name}
Role: ${character.role || 'unknown'}
Description: ${character.description}
Visual profile: ${JSON.stringify(character.visual_profile || {})}

Return JSON with one field:
{
  "visual_anchor": "A comma-separated tag list of ONLY immutable physical traits. Under 80 words total. Format: [hair shade + texture + length], [eye colour + shape], [skin tone + undertone], [jaw shape], [cheekbone prominence], [nose shape], [brow style], [height + build], [posture], [one always-worn signature item]. Use cinematographer-precise language — not 'brown hair' but 'deep espresso-brown loose-wave shoulder-length hair'. Every tag is a direct instruction to an image model — no filler words, no conjunctions, no backstory. Example format: 'deep espresso-brown wavy shoulder-length hair, dark amber almond eyes with green flecks, strong arched brows, warm medium-brown dewy skin, square jaw, high sculpted cheekbones, straight nose, 5ft7 lean athletic frame, upright posture, always wearing worn tan leather jacket'"
}

FORBIDDEN: prose sentences, personality traits, emotions, backstory, context, conjunctions like 'with' or 'and' mid-description.
REQUIRED: comma-separated tags only, physical traits only, each tag is self-contained.`;

  const result = await callLLM(systemPrompt, userPrompt, 400);
  return result.visual_anchor || `${character.name}: ${character.description}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// New Series Bible
// ─────────────────────────────────────────────────────────────────────────────

async function writeNewStoryline(genre) {
  const systemPrompt = `${DIRECTOR_PERSONA}

You are building the complete Series Bible for a new StreamVerse Studios original.
This document is sacred — it governs every creative decision across 80 episodes and 4 seasons.
Think of it as the document you'd hand to a cinematographer, costume designer, and composer on day one.`;

  const userPrompt = `Create a new ${genre} streaming series. This is NOT a simple story summary — this is a full auteur vision document.

Return JSON with these exact fields:
{
  "title": "Series title — distinctive, thematic, not generic",
  "genre": "${genre}",
  "logline": "One precise, emotionally devastating sentence that captures what the show is REALLY about",
  "central_theme": "The philosophical or psychological question at the core of the entire series (e.g. 'Can a person truly escape who they were?')",
  "tone_manifesto": "2-3 sentences describing the emotional register: how does this show feel? What films or real experiences does it evoke? What does it refuse to be?",
  "visual_language": {
    "primary_palette": "The dominant colour temperature and specific hues that define the show's visual world",
    "recurring_motifs": ["3-5 visual symbols that will repeat across episodes (e.g. 'rain always precedes a revelation', 'mirrors show the character they pretend to be')"],
    "camera_philosophy": "How the camera moves and what that movement means emotionally — e.g. 'handheld during emotional collapse, locked-off during control, slow push-ins at moments of recognition'"
  },
  "plot_summary": "3-4 paragraph series arc across 4 seasons. Each paragraph is one season. Be specific about what CHANGES in each character's inner life, not just what happens to them",
  "season_arcs": [
    "Season 1 arc — the WOUND is established and the character's defence mechanism is revealed",
    "Season 2 arc — the defence mechanism fails and the character is exposed",
    "Season 3 arc — the character must choose who they actually want to be",
    "Season 4 arc — the cost of that choice is paid in full"
  ],
  "character_bible": [
    {
      "name": "Character name",
      "role": "protagonist|antagonist|supporting",
      "description": "Their psychology, wound, desire, fear, and the contradiction they live in (the thing they want and the thing they need are not the same)",
      "arc": "Where they begin emotionally vs where they end 4 seasons later — be specific and surprising",
      "performance_note": "One sentence a director would whisper to the actor: what is this person always hiding, and how does it show in their body?",
      "visual_profile": {
        "hair": "Exact shade (use colour theory words), texture, length, style",
        "eyes": "Exact colour (e.g. 'dark amber with green flecks'), shape, intensity",
        "skin": "Exact tone, undertone, texture (e.g. 'warm medium-brown with cool undertones, naturally dewy')",
        "build": "Height, frame, posture (posture reveals character)",
        "signature_clothing": "Their default aesthetic and one signature piece they're almost always wearing",
        "distinguishing_features": "Specific marks, mannerisms, or physical tells"
      }
    }
  ],
  "engagement_hook": "The single existential question the audience will argue about in comments — it should have no clean answer",
  "premiere_announcement": "The Facebook post copy announcing this series premiere — maximum hype, ends with a question that demands engagement. 2-3 sentences. Include genre tone."
}

Include 4-6 main characters. Make every field specific and surprising — no generic TV tropes.`;

  return callLLM(systemPrompt, userPrompt, 3000);
}

// ─────────────────────────────────────────────────────────────────────────────
// Episode Script — the director's craft at full depth
// ─────────────────────────────────────────────────────────────────────────────

async function writeEpisodeScript({
  storyline,
  characters,
  recentEpisodes,
  episodeNumber,
  seasonNumber,
  isFinale,
  isSeriesMovie,
  targetMinutes,
  runtimeRetryNote = null,   // injected on retry when previous script was too short
}) {
  const systemPrompt = `${DIRECTOR_PERSONA}
${PACING_RULES}
${NARRATIVE_CONTINUITY_SCHEMA}
You are writing and directing Episode ${episodeNumber} of Season ${seasonNumber} of "${storyline.title}".
You know this story inside out. You have a specific visual and emotional plan for this episode.
Write with the confidence of a showrunner who is in full creative control.`;

  const continuityBlock = recentEpisodes.length
    ? `\n═══ STORY CONTINUITY (from last ${recentEpisodes.length} posted episodes) ═══\n` +
      recentEpisodes.map(e => {
        const sc = JSON.parse(e.script || '{}');
        return `Ep ${e.episode_number}: ${sc.updated_plot_summary || '(no summary)'}\n  Director's note carried forward: ${sc.director_vision || ''}`;
      }).join('\n')
    : '';

  const characterBlock = (characters || []).map(c => {
    const vp = typeof c.visual_profile === 'string' ? JSON.parse(c.visual_profile || '{}') : (c.visual_profile || {});
    return `▸ ${c.name} (${c.role || 'character'})
  Psychology: ${c.description}
  Performance note: ${vp.performance_note || c.description}
  Identity tag-lock (auto-injected into image generation — do NOT repeat in image_prompt): ${c.visual_anchor || c.description}`;
  }).join('\n\n');

  const visualLanguage = storyline.visual_language
    ? (typeof storyline.visual_language === 'string'
        ? JSON.parse(storyline.visual_language)
        : storyline.visual_language)
    : null;

  const visualBlock = visualLanguage
    ? `\n═══ SERIES VISUAL LANGUAGE ═══
Palette: ${visualLanguage.primary_palette || ''}
Camera: ${visualLanguage.camera_philosophy || ''}
Motifs: ${(visualLanguage.recurring_motifs || []).join(', ')}`
    : '';

  const seasonArc = (() => {
    const arcs = storyline.season_arcs
      ? (typeof storyline.season_arcs === 'string'
          ? JSON.parse(storyline.season_arcs)
          : storyline.season_arcs)
      : [];
    return arcs[seasonNumber - 1] || 'Continue the story with escalating stakes';
  })();

  const episodeType = isSeriesMovie
    ? `THE SERIES FINALE MOVIE — this is the culmination of ALL 4 seasons, ALL character arcs, ALL thematic threads. Runtime: ~${targetMinutes} minutes. It must feel earned and inevitable.`
    : isFinale
    ? `SEASON ${seasonNumber} FINALE — a cliffhanger that recontextualises everything. A revelation that makes the audience re-evaluate what they thought they knew. Runtime: ~${targetMinutes} minutes.`
    : `Season ${seasonNumber}, Episode ${episodeNumber} — a chapter in the season arc. Not every episode is a turning point — this one should feel like life: specific, observed, emotionally true. Runtime: ~${targetMinutes} minutes.`;

  // Ensure enough scenes to hit the 2-minute hard floor (120s) at minimum.
  // Each scene contributes roughly 3 shots × 3s effective clip_duration = ~9s on screen.
  // For a 2-minute episode: ceil(120 / 9) = 14 scenes minimum → round up to safe range.
  // For longer targets (targetMinutes > 2), use proportional scene counts.
  const minScenesFor2Min = 8; // conservative floor: 8 scenes × ~3 shots × ~5s = ~120s+
  const sceneCountRaw = isSeriesMovie
    ? '20-25'
    : targetMinutes <= 2
      ? String(minScenesFor2Min)
      : targetMinutes <= 5
        ? `${minScenesFor2Min}-10`
        : '10-14';
  const sceneCount = sceneCountRaw;
  const shotsPerScene = 3;

  const userPrompt = `${runtimeRetryNote ? `⚠️ RETRY REQUIRED — PREVIOUS SCRIPT WAS REJECTED:\n${runtimeRetryNote}\nYou MUST fix this before anything else. Write more scenes and/or longer clip_durations.\n\n` : ''}Direct: ${episodeType}

═══ SERIES: "${storyline.title}" (${storyline.genre}) ═══
Central Theme: ${storyline.central_theme || storyline.plot_summary}
Tone: ${storyline.tone_manifesto || ''}
Season ${seasonNumber} Arc: ${seasonArc}
${visualBlock}
${continuityBlock}

═══ CAST ═══
${characterBlock}

═══ YOUR DIRECTORIAL BRIEF ═══
Before writing a single shot, ask yourself:
1. What is this episode ABOUT emotionally — not plot-wise, but what truth does it reveal?
2. What visual motif will I use in this episode that connects to the series language?
3. What is the emotional STATE of each character when this episode begins, and how is it different by the end?
4. What is the one shot in this episode that no other director would think of?

Return this JSON structure — every field is required:
{
  "episode_title": "Title that is a metaphor or line of dialogue, not a plot summary",
  "season_number": ${seasonNumber},
  "episode_number": ${episodeNumber},
  "director_vision": "1 paragraph — your private note to yourself as director. What is this episode really about? What feeling should the viewer be left with? What will you do visually that is specific to THIS episode?",
  "episode_color_palette": "The dominant colours this episode and what they mean — e.g. 'desaturated teal throughout: isolation made visible; a burst of amber in the final scene: the first warmth she allows herself to feel'",
  "episode_motif": "The recurring visual or symbolic element this episode (a prop, a gesture, a framing device) and what it represents",
  "emotional_arc": {
    "opening_state": "Emotional state of the main character(s) as episode opens",
    "escalation": "The pressure that builds through the middle",
    "break_point": "The moment something cracks — the scene where everything shifts",
    "closing_state": "How they are changed (or refuse to change) by the end"
  },
  "updated_plot_summary": "2-3 sentences updating the living series bible with what this episode changed in the story and in the characters",
  "caption": "Facebook caption — NOT a plot description. Make it feel like a real emotional experience. End with an existential question that has no easy answer and will drive comment debate.",
  "is_series_finale": ${isSeriesMovie ? 'true' : 'false'},
  "safety_check_passed": true,
  "safety_notes": "any content advisory notes",
  "scenes": [
    {
      "scene_number": 1,
      "scene_description": "What is actually happening in this scene — including what is UNSAID",
      "emotional_beat": "The specific emotional shift this scene creates — what does the audience feel by the end of it that they did not feel at the start?",
      "location": "INT./EXT. specific location — time of day",
      "lighting_design": "Quality, direction, and colour of light — and what it reveals about the emotional state",
      "camera_language": "How the camera is operated in this scene — handheld (anxiety), locked-off (control), slow push-in (dread or recognition), etc.",
      "composition": "cut|overlay|split|zoom",
      "characters_present": ["character names"],
      "shots": [
        {
          "shot_index": 1,
          "shot_type": "ECU|CU|MCU|MS|MWS|WS|XWS|OTS|POV|AERIAL|INSERT",
          "shot_purpose": "Why does this shot exist? What does it reveal that dialogue cannot? (establish/reveal/react/isolate/contrast/connect)",
          "shot_description": "What the camera sees — be specific about framing, depth of field, what is in focus vs soft",
          "camera_movement": "static|slow push-in|pull back|pan left|pan right|handheld drift|tilt up|tilt down|crane up|none",
          "characters_in_shot": ["character names — must exactly match names from the CAST section above"],
          "emotional_subtext": "What is the character hiding or feeling beneath the surface of this shot",
          "image_prompt": "The cinematographic prompt for THIS shot. DO NOT describe character physical appearance — that is injected automatically from the identity lock system. ONLY describe: (1) Shot type and framing (e.g. 'extreme close-up, face filling frame'). (2) Camera angle and movement. (3) Lighting quality and direction (e.g. 'hard side-light from left casting deep shadow'). (4) Specific colour palette. (5) Background environment and depth. (6) Costume colour and texture only (no body shape or face). (7) Atmospheric elements (fog, rain, dust). MANDATORY FOR MULTI-CHARACTER SHOTS: You MUST explicitly state the spatial position of each character using their exact name — e.g. 'Elena stands on the left side of frame, Marcus stands on the right side of frame'. Never place two characters in the same position. Explicit positions prevent the AI from merging two people into one hybrid face. 9:16 vertical portrait, 1080x1920. Photorealistic 4K cinematic. NO text overlays. NO character physical descriptions.",
          "duration": 5,
          "clip_duration": 3,
          "shot_pacing_type": "hook|action|reaction|broll_cutaway|dialogue_mid|dialogue_full|slow_dramatic",
          "motion_level": "low|medium|high",
          "dialogue_or_action": "Exact words spoken or specific physical action — include the subtext in parentheses"
        }
      ]
    }
  ]
}

Write ${sceneCount} scenes with ${shotsPerScene} shots each. Make each shot cinematically distinct from the others.
The image_prompt for each shot should be so specific and detailed that an AI image generator would produce exactly what you envision.

RUNTIME MANDATE (non-negotiable):
The compiled episode MUST run at minimum 2 minutes (120 seconds) of screen time.
Sum of all "clip_duration" values across all shots must equal AT LEAST 120 seconds.
If your scene count × shots × avg clip_duration would fall short, ADD MORE SCENES.
Never pad with filler — add scenes that deepen character or escalate plot. But hit 120s.

DIALOGUE MANDATE (non-negotiable):
Every character listed in "characters_present" MUST speak at least once per scene.
"dialogue_or_action" for EVERY dialogue shot MUST contain actual spoken words — not
stage directions, not "(character thinks about leaving)", not "[silence]".
Format: "CHARACTER NAME: Exact spoken words. (subtext in parentheses)"
V.O. thoughts for characters who cannot physically speak: "NAME (V.O.): inner thought"
Zero silent scenes. Zero mute characters. The audio pipeline rejects silent shots.

CLIFFHANGER MANDATE (final scene only):
The last scene's last shot "dialogue_or_action" must BE the cliffhanger — an irresolvable
threat, revelation, or impossible choice that makes the episode impossible to end on.
The final line of dialogue or physical action must drop the audience into a void of tension.

PACING REMINDER: Apply the EDITING PACE RULES above. Every shot must have:
- "duration": 4 or 5 (raw Magic Hour generation length — always 4 or 5 seconds)
- "clip_duration": the trimmed effective time this shot appears on screen (follow the shot_pacing_type table)
- "shot_pacing_type": one of the types from the pacing table above
The FIRST scene must open with "hook" shots (clip_duration ≤ 2.0). No scene should have all shots at the same clip_duration.`;

  return callLLM(systemPrompt, userPrompt, isSeriesMovie ? 8192 : 5000);
}

// ─────────────────────────────────────────────────────────────────────────────
// Series Finale announcement post
// ─────────────────────────────────────────────────────────────────────────────

async function writeFinaleAnnouncement(storyline) {
  const systemPrompt = `${DIRECTOR_PERSONA}
You are writing the farewell post for a series that has concluded. Write it with the weight of something real ending.`;

  const userPrompt = `Write a Facebook farewell/finale post for the series "${storyline.title}" (${storyline.genre}) that has just concluded after ${storyline.episode_count} episodes across 4 seasons.

Central theme: ${storyline.central_theme || storyline.plot_summary}

Return JSON:
{
  "post_text": "3-4 sentences. Speak directly to the fans as if this was a real show ending. Acknowledge the journey. Thank the audience. Tease that something new is coming. End with a reflection question that makes fans think about what they took from the story.",
  "hashtags": "#StreamVerseStudios #SeriesFinale and 3-4 genre-specific hashtags"
}`;

  const result = await callLLM(systemPrompt, userPrompt, 512);
  return `${result.post_text || ''}\n\n${result.hashtags || '#StreamVerseStudios'}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// New Series Premiere announcement post
// ─────────────────────────────────────────────────────────────────────────────

async function writePremiereAnnouncement(storyline) {
  const systemPrompt = `${DIRECTOR_PERSONA}
You are writing the premiere announcement for a new original series. This is the first thing potential fans see.
Make it impossible to scroll past.`;

  const userPrompt = `Write a Facebook premiere announcement for the new series "${storyline.title}" (${storyline.genre}).

Logline: ${storyline.logline || ''}
Central theme: ${storyline.central_theme || ''}
Engagement hook: ${storyline.engagement_hook || ''}
Premiere announcement copy from the series bible: ${storyline.premiere_announcement || ''}

Return JSON:
{
  "post_text": "3-4 sentences. Open with a statement that stops scrolling — provocative, specific, emotionally charged. Establish the world and the stakes in one sentence. Create urgency. End with the engagement_hook as a direct question.",
  "hashtags": "#StreamVerseStudios #SeriesPremiere #NewShow and 3-4 genre/theme specific hashtags"
}`;

  const result = await callLLM(systemPrompt, userPrompt, 512);
  return `🎬 SERIES PREMIERE\n\n${result.post_text || ''}\n\n${result.hashtags || '#StreamVerseStudios #SeriesPremiere'}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Reel caption
// ─────────────────────────────────────────────────────────────────────────────

async function writeShotCaption(storylineTitle, genre, episodeContext) {
  const systemPrompt = `${DIRECTOR_PERSONA}
You write short, visceral Facebook Reel captions engineered for maximum algorithmic reach and comment volume.

PROVEN ENGAGEMENT TACTICS you must use:
- Open with an emotional gut-punch statement (never a description)
- Use "Watch till the end 👀" or "Last 10 seconds will shock you 🔥" when appropriate
- Embed a binary-choice hook: "Comment 1 if you'd choose X — Comment 2 if you'd choose Y"
- OR a tag mechanic: "Tag someone who acts just like [character name] 👇"
- OR a controversy statement that has two defensible sides
- Hashtags: mix show-specific + trending genre tags + broad reach tags`;

  const userPrompt = `Write a Facebook Reel caption for a ${genre} clip from "${storylineTitle}".
Context: ${episodeContext}

Return: {
  "caption": "Under 60 words. Emotional opener. One of the binary-choice / tag / controversy engagement tactics. End with a direct question. 4-6 hashtags including #StreamVerseStudios.",
  "engagement_tactic": "which tactic you used: binary_choice | tag_someone | controversy | poll_question"
}`;

  const result = await callLLM(systemPrompt, userPrompt, 300);
  return result.caption || `✨ ${storylineTitle} | StreamVerse Studios\n\nWatch till the end 👀 — would YOU have made the same choice?\n\n#StreamVerseStudios #${genre.replace(/[^a-z0-9]/gi,'')} #NewEpisode`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Auto comment reply — AI-generated response to a viewer comment
// ─────────────────────────────────────────────────────────────────────────────

async function writeAutoCommentReply({ storylineTitle, genre, episodeTitle, commentText }) {
  const systemPrompt = `You are the official community manager for StreamVerse Studios.
You write short, warm, personality-rich replies to viewer comments on Facebook videos.
Your tone is: enthusiastic but not cringe, emotionally intelligent, and community-building.
You NEVER reveal you are AI. You write as the voice of the show's production team.
Rules:
- Reply in 1-2 sentences maximum
- Acknowledge what the viewer specifically said
- Deepen their curiosity or emotional investment in the story
- End with a question OR a teaser hint that makes them want to keep watching
- Use 1-2 relevant emojis max. No hashtags in replies.`;

  const userPrompt = `The show: "${storylineTitle}" (${genre})
Current episode: "${episodeTitle}"
Viewer comment: "${commentText}"

Return JSON: { "reply": "1-2 sentence reply. Warm, specific, ends with a curiosity hook or question." }`;

  try {
    const result = await callLLM(systemPrompt, userPrompt, 200);
    return result.reply || null;
  } catch (err) {
    console.warn('[ScriptWriter] writeAutoCommentReply failed:', err.message);
    return null;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Mid-series engagement post — standalone Facebook post between episodes
// ─────────────────────────────────────────────────────────────────────────────

async function writeEngagementPost({ storylineTitle, genre, centralTheme, engagementHook, episodeCount }) {
  const systemPrompt = `${DIRECTOR_PERSONA}
You write high-performing Facebook Page posts designed to re-ignite engagement between episode drops.
These posts are NOT episode announcements — they are conversation starters about the world and characters of the show.`;

  const userPrompt = `Write a between-episodes engagement post for "${storylineTitle}" (${genre}).
Central theme: ${centralTheme}
Core engagement hook: ${engagementHook}
Episodes aired so far: ${episodeCount}

Return JSON:
{
  "post_text": "2-3 sentences. Pose a dilemma, reveal a detail, or ask a fan theory question about the show's world. Must create debate. Ends with a direct question to the audience.",
  "post_type": "fan_theory | character_dilemma | would_you_rather | behind_the_scenes_tease",
  "hashtags": "#StreamVerseStudios and 3-4 relevant tags"
}`;

  try {
    const result = await callLLM(systemPrompt, userPrompt, 400);
    return result.post_text
      ? `${result.post_text}\n\n${result.hashtags || '#StreamVerseStudios'}`
      : null;
  } catch (err) {
    console.warn('[ScriptWriter] writeEngagementPost failed:', err.message);
    return null;
  }
}

module.exports = {
  callLLM,
  writeNewStoryline,
  writeEpisodeScript,
  generateCharacterVisualAnchor,
  writeFinaleAnnouncement,
  writePremiereAnnouncement,
  writeShotCaption,
  writeAutoCommentReply,
  writeEngagementPost,
};
