'use strict';
const mysql = require('mysql2/promise');
const config = require('./config');

let pool = null;

function getPool() {
  if (!pool) {
    pool = mysql.createPool(config.db);
    pool.on('connection', () => console.log('[DB] New MySQL connection established'));
  }
  return pool;
}

/**
 * mysql2 prepared statements throw "Incorrect arguments to mysqld_stmt_execute"
 * when any parameter value is `undefined`. Coerce every undefined to null so
 * the driver always receives a serialisable value.
 */
function sanitizeParams(params) {
  return params.map(p => (p === undefined ? null : p));
}

async function query(sql, params = []) {
  const [rows] = await getPool().execute(sql, sanitizeParams(params));
  return rows;
}

async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

async function execute(sql, params = []) {
  const [result] = await getPool().execute(sql, sanitizeParams(params));
  return result;
}

async function transaction(fn) {
  const conn = await getPool().getConnection();
  await conn.beginTransaction();
  try {
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

async function initSchema() {
  console.log('[DB] Initialising schema...');

  await execute(`
    CREATE TABLE IF NOT EXISTS storylines (
      id                    VARCHAR(36)  NOT NULL PRIMARY KEY,
      title                 VARCHAR(255) NOT NULL,
      genre                 VARCHAR(100) NOT NULL,
      character_bible       JSON         NULL,
      plot_summary          TEXT         NULL,
      central_theme         TEXT         NULL,
      tone_manifesto        TEXT         NULL,
      visual_language       JSON         NULL,
      season_arcs           JSON         NULL,
      engagement_hook       TEXT         NULL,
      premiere_announcement TEXT         NULL,
      logline               TEXT         NULL,
      status                ENUM('active','completed') NOT NULL DEFAULT 'active',
      episode_count         INT          NOT NULL DEFAULT 0,
      current_season        INT          NOT NULL DEFAULT 1,
      current_episode       INT          NOT NULL DEFAULT 0,
      facebook_playlist_id  VARCHAR(100) NULL,
      next_episode_due_date DATETIME     NULL,
      created_at            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await execute(`
    CREATE TABLE IF NOT EXISTS episodes (
      id                  VARCHAR(36)   NOT NULL PRIMARY KEY,
      storyline_id        VARCHAR(36)   NOT NULL,
      episode_number      INT           NOT NULL,
      season_number       INT           NOT NULL DEFAULT 1,
      script              LONGTEXT      NULL,
      scene_count         INT           NOT NULL DEFAULT 0,
      shot_count          INT           NOT NULL DEFAULT 0,
      video_url           VARCHAR(1024) NULL,
      facebook_video_id   VARCHAR(100)  NULL,
      facebook_video_link VARCHAR(1024) NULL,
      status              VARCHAR(50)   NOT NULL DEFAULT 'pending',
      safety_check_passed TINYINT(1)    NOT NULL DEFAULT 1,
      safety_notes        TEXT          NULL,
      shot_state          JSON          NULL COMMENT 'scene_shot → Cloudinary clip URL; saved after every successful shot for resume support',
      scene_state         JSON          NULL COMMENT 'scene number → compiled scene URL; saved after each scene compile',
      paused_reason       VARCHAR(512)  NULL COMMENT 'Why this draft episode is paused (e.g. MH credits exhausted)',
      posted_at           DATETIME      NULL,
      created_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_storyline (storyline_id),
      INDEX idx_status    (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await execute(`
    CREATE TABLE IF NOT EXISTS shots (
      id             VARCHAR(36)    NOT NULL PRIMARY KEY,
      episode_id     VARCHAR(36)    NOT NULL,
      scene_number   INT            NOT NULL,
      shot_index     INT            NOT NULL,
      status         VARCHAR(30)    NOT NULL DEFAULT 'pending'
                                    COMMENT 'pending|mh_submitted|done|failed',
      image_url      VARCHAR(1024)  NULL     COMMENT 'Temp Cloudinary public ID of generated still',
      mh_job_id      VARCHAR(100)   NULL     COMMENT 'Magic Hour job ID — set before polling begins',
      mh_api_key     VARCHAR(256)   NULL     COMMENT 'MH API key used for this job',
      clip_url       VARCHAR(1024)  NULL     COMMENT 'Final Cloudinary clip URL',
      clip_duration  FLOAT          NULL     COMMENT 'Effective clip duration in seconds for FFmpeg',
      error_count    INT            NOT NULL DEFAULT 0,
      last_error     TEXT           NULL,
      created_at     DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at     DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_episode_shot (episode_id, scene_number, shot_index),
      INDEX idx_episode_status (episode_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await execute(`
    CREATE TABLE IF NOT EXISTS characters (
      id                   VARCHAR(36)   NOT NULL PRIMARY KEY,
      storyline_id         VARCHAR(36)   NOT NULL,
      name                 VARCHAR(255)  NOT NULL,
      description          TEXT          NULL,
      visual_profile       JSON          NULL,
      visual_anchor        TEXT          NULL COMMENT 'Comma-separated tag-lock injected into every shot prompt',
      reference_image_url  VARCHAR(1024) NULL COMMENT 'Cloudinary URL of primary (front) portrait',
      reference_image_urls JSON          NULL COMMENT 'JSON array of all portrait angle URLs for reference conditioning',
      created_at           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_storyline (storyline_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // Safe column additions for existing installs
  const alterColumns = [
    // episodes table
    [`episodes`,    `season_number`,       `ALTER TABLE episodes ADD COLUMN season_number INT NOT NULL DEFAULT 1 AFTER episode_number`],
    [`episodes`,    `safety_check_passed`, `ALTER TABLE episodes ADD COLUMN safety_check_passed TINYINT(1) NOT NULL DEFAULT 1 AFTER status`],
    [`episodes`,    `safety_notes`,        `ALTER TABLE episodes ADD COLUMN safety_notes TEXT NULL AFTER safety_check_passed`],
    [`episodes`,    `shot_state`,          `ALTER TABLE episodes ADD COLUMN shot_state JSON NULL COMMENT 'scene_shot → clip URL; persisted after each successful shot'`],
    [`episodes`,    `scene_state`,         `ALTER TABLE episodes ADD COLUMN scene_state JSON NULL COMMENT 'scene number → compiled URL; persisted after each compose'`],
    [`episodes`,    `paused_reason`,       `ALTER TABLE episodes ADD COLUMN paused_reason VARCHAR(512) NULL COMMENT 'Why this draft is paused'`],
    // characters table — add visual_profile first so subsequent AFTER clauses work
    [`characters`,  `visual_profile`,       `ALTER TABLE characters ADD COLUMN visual_profile JSON NULL`],
    [`characters`,  `visual_anchor`,        `ALTER TABLE characters ADD COLUMN visual_anchor TEXT NULL COMMENT 'Immutable prompt anchor'`],
    [`characters`,  `reference_image_url`,  `ALTER TABLE characters ADD COLUMN reference_image_url VARCHAR(1024) NULL COMMENT 'Cloudinary canonical portrait URL (primary / front angle)'`],
    [`characters`,  `reference_image_urls`, `ALTER TABLE characters ADD COLUMN reference_image_urls JSON NULL COMMENT 'JSON array of all portrait angle URLs for multi-angle reference conditioning'`],
    // storylines table
    [`storylines`,  `current_season`,      `ALTER TABLE storylines ADD COLUMN current_season INT NOT NULL DEFAULT 1`],
    [`storylines`,  `current_episode`,     `ALTER TABLE storylines ADD COLUMN current_episode INT NOT NULL DEFAULT 0`],
    [`storylines`,  `central_theme`,       `ALTER TABLE storylines ADD COLUMN central_theme TEXT NULL AFTER plot_summary`],
    [`storylines`,  `tone_manifesto`,      `ALTER TABLE storylines ADD COLUMN tone_manifesto TEXT NULL AFTER central_theme`],
    [`storylines`,  `visual_language`,     `ALTER TABLE storylines ADD COLUMN visual_language JSON NULL AFTER tone_manifesto`],
    [`storylines`,  `season_arcs`,         `ALTER TABLE storylines ADD COLUMN season_arcs JSON NULL AFTER visual_language`],
    [`storylines`,  `engagement_hook`,     `ALTER TABLE storylines ADD COLUMN engagement_hook TEXT NULL AFTER season_arcs`],
    [`storylines`,  `premiere_announcement`, `ALTER TABLE storylines ADD COLUMN premiere_announcement TEXT NULL AFTER engagement_hook`],
    [`storylines`,  `logline`,             `ALTER TABLE storylines ADD COLUMN logline TEXT NULL AFTER premiere_announcement`],
    [`storylines`,  `facebook_playlist_id`, `ALTER TABLE storylines ADD COLUMN facebook_playlist_id VARCHAR(100) NULL AFTER logline`],
  ];
  for (const [table, col, ddl] of alterColumns) {
    const exists = await queryOne(
      `SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
      [table, col]
    );
    if (!exists) {
      try { await execute(ddl); console.log(`[DB] Added column ${table}.${col}`); }
      catch (e) { console.warn(`[DB] Could not add ${table}.${col}:`, e.message); }
    }
  }

  console.log('[DB] Schema ready.');
}

module.exports = { query, queryOne, execute, transaction, initSchema, getPool };
