'use strict';
const { v4: uuidv4 } = require('uuid');
const config         = require('./config');
const db             = require('./db');
const state          = require('./state');
const telegram       = require('./telegram');
const cloudinary     = require('./cloudinary');
const imageGen                       = require('./imageGen');
const { SafetyRefusalError }         = require('./googleImageGen');
const { CFSafetyRefusalError }       = require('./cfImageGen');
const ttsGen                         = require('./ttsGen');
const videoGen       = require('./videoGen');
const compiler       = require('./compiler');
const facebook       = require('./facebook');
const scriptWriter   = require('./scriptWriter');
const os             = require('os');
const fs             = require('fs');

// ──────────────────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────────────────

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/**
 * Detect MIME type from buffer magic bytes.
 * CF Worker AI can return PNG, JPEG, or WebP depending on model version.
 * Hardcoding "image/png" causes Cloudinary to reject or misclassify other formats.
 */
function _detectMime(buf) {
  if (!buf || buf.length < 12) return 'image/png';
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF)                      return 'image/jpeg';
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
      buf[8] === 0x57 && buf[9] === 0x45 && buf[10]=== 0x42 && buf[11]=== 0x50)  return 'image/webp';
  // Unknown format: throw so the caller can handle it explicitly rather than uploading garbage
  throw new Error(`[_detectMime] Unrecognised image format — magic bytes: ${buf.slice(0,4).toString('hex')}`);
}

function diskUsageMB() {
  try {
    const stats = fs.statfsSync ? fs.statfsSync('/') : null;
    if (stats) return Math.round((stats.blocks - stats.bfree) * stats.bsize / 1024 / 1024);
    return Math.round((os.totalmem() - os.freemem()) / 1024 / 1024);
  } catch { return 0; }
}

// ──────────────────────────────────────────────────────────────────────────────
// DB helpers (all ? placeholders — never string interpolation)
// ──────────────────────────────────────────────────────────────────────────────

async function getActiveStoryline() {
  return db.queryOne(`SELECT * FROM storylines WHERE status = 'active' ORDER BY updated_at DESC LIMIT 1`);
}

async function getRecentEpisodes(storylineId, limit = 5) {
  const safeLimit = parseInt(limit, 10) || 5;
  return db.query(
    `SELECT episode_number, script FROM episodes WHERE storyline_id = ? AND status = 'posted'
     ORDER BY episode_number DESC LIMIT ${safeLimit}`,
    [storylineId]
  );
}

async function getCharacters(storylineId) {
  return db.query(`SELECT * FROM characters WHERE storyline_id = ?`, [storylineId]);
}

async function insertStoryline(data) {
  const id = uuidv4();
  await db.execute(
    `INSERT INTO storylines
       (id, title, genre, character_bible, plot_summary, central_theme, tone_manifesto,
        visual_language, season_arcs, engagement_hook, premiere_announcement, logline,
        status, episode_count, current_season, current_episode, facebook_playlist_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 0, 1, 0, ?)`,
    [
      id,
      data.title,
      data.genre,
      JSON.stringify(data.character_bible || []),
      data.plot_summary   || null,
      data.central_theme  || null,
      data.tone_manifesto || null,
      JSON.stringify(data.visual_language  || null),
      JSON.stringify(data.season_arcs      || []),
      data.engagement_hook          || null,
      data.premiere_announcement    || null,
      data.logline                  || null,
      data.facebook_playlist_id     || null,
    ]
  );
  return id;
}

/**
 * Insert characters and generate/store their visual anchors + reference portrait images.
 * This is the backbone of character consistency — runs once per new series.
 */
async function insertCharactersWithConsistency(storylineId, characterBible) {
  const results = [];
  for (const char of (characterBible || [])) {
    const existing = await db.queryOne(
      `SELECT id, visual_anchor, reference_image_url FROM characters WHERE storyline_id = ? AND name = ?`,
      [storylineId, char.name]
    );
    if (existing) {
      results.push({ ...char, ...existing });
      continue;
    }

    // 1. Generate immutable visual anchor string via LLM
    console.log(`[Consistency] Generating visual anchor for ${char.name}...`);
    let visualAnchor = null;
    try {
      visualAnchor = await scriptWriter.generateCharacterVisualAnchor(char);
    } catch (err) {
      console.warn(`[Consistency] Visual anchor generation failed for ${char.name}:`, err.message);
      visualAnchor = `${char.name}: ${char.description}`;
    }

    // 2. Generate canonical reference portrait images via CF Worker AI.
    // Multiple angles improve reference signal; the primary (front) portrait goes in
    // reference_image_url for backwards compat; all angles go in reference_image_urls JSON array.
    const charId = uuidv4();
    console.log(`[Consistency] Generating reference portrait(s) for ${char.name}...`);

    const angleCount  = Math.min(Math.max(config.charRefImageCount || 1, 1), 4);
    const angles      = ['front', 'three_quarter', 'profile', 'full_body'].slice(0, angleCount);
    const allPortraitUrls = [];
    // Negative prompt for portrait generation
    const portraitNeg = 'motion blur, text, watermark, logo, background elements, props, other people, bad anatomy, distorted face, extra limbs';

    for (const angle of angles) {
      try {
        const portraitPrompt = _buildCharacterPortraitPrompt(char, visualAnchor, angle);
        const imageBuffer    = await imageGen.generateImage(portraitPrompt, [], _charSeed(charId), portraitNeg);
        const nameSlug       = char.name.replace(/\s+/g, '_').toLowerCase();
        const pubId          = `${config.charRefFolderRoot}/${storylineId}/${nameSlug}_${angle}`;
        const mime           = _detectMime(imageBuffer);
        const url = await cloudinary.uploadImageFromUrl(
          `data:${mime};base64,${imageBuffer.toString('base64')}`,
          pubId
        );
        allPortraitUrls.push(url);
        console.log(`[Consistency] Portrait (${angle}) for ${char.name} [${mime}] → ${url}`);
      } catch (err) {
        console.warn(`[Consistency] Portrait (${angle}) failed for ${char.name}:`, err.message);
      }
    }

    const referenceImageUrl  = allPortraitUrls[0] || null;
    const referenceImageUrls = JSON.stringify(allPortraitUrls);

    await db.execute(
      `INSERT INTO characters (id, storyline_id, name, description, visual_profile, visual_anchor, reference_image_url, reference_image_urls)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        charId,
        storylineId,
        char.name,
        char.description || '',
        JSON.stringify(char.visual_profile || {}),
        visualAnchor,
        referenceImageUrl,
        referenceImageUrls,
      ]
    );
    results.push({ id: charId, ...char, visual_anchor: visualAnchor, reference_image_url: referenceImageUrl, reference_image_urls: referenceImageUrls });
  }
  return results;
}

/**
 * Ensure every existing character has a visual anchor and reference image.
 * Called when resuming an existing series that may have been created before this feature.
 */
async function ensureCharacterConsistency(storylineId) {
  const chars = await getCharacters(storylineId);
  for (const char of chars) {
    const needsAnchor = !char.visual_anchor;
    const needsPortrait = !char.reference_image_url;
    if (!needsAnchor && !needsPortrait) continue;

    console.log(`[Consistency] Back-filling consistency data for ${char.name}...`);
    const updates = {};

    if (needsAnchor) {
      try {
        updates.visual_anchor = await scriptWriter.generateCharacterVisualAnchor({
          name:          char.name,
          description:   char.description,
          visual_profile: JSON.parse(char.visual_profile || '{}'),
        });
      } catch (e) {
        console.warn(`[Consistency] Anchor back-fill failed for ${char.name}:`, e.message);
      }
    }

    if (needsPortrait) {
      const anchor    = updates.visual_anchor || char.visual_anchor || char.description;
      const nameSlug  = char.name.replace(/\s+/g, '_').toLowerCase();
      const angleCount = Math.min(Math.max(config.charRefImageCount || 1, 1), 4);
      const angles     = ['front', 'three_quarter', 'profile', 'full_body'].slice(0, angleCount);
      const portraitNeg = 'motion blur, text, watermark, logo, background elements, props, other people, bad anatomy, distorted face, extra limbs';
      const backfillUrls = [];

      for (const angle of angles) {
        try {
          const prompt    = _buildCharacterPortraitPrompt(char, anchor, angle);
          const imgBuffer = await imageGen.generateImage(prompt, [], _charSeed(char.id), portraitNeg);
          const pubId     = `${config.charRefFolderRoot}/${storylineId}/${nameSlug}_${angle}`;
          const mime      = _detectMime(imgBuffer);
          const url = await cloudinary.uploadImageFromUrl(
            `data:${mime};base64,${imgBuffer.toString('base64')}`,
            pubId
          );
          backfillUrls.push(url);
        } catch (e) {
          console.warn(`[Consistency] Portrait (${angle}) back-fill failed for ${char.name}:`, e.message);
        }
      }

      if (backfillUrls.length) {
        updates.reference_image_url  = backfillUrls[0];
        updates.reference_image_urls = JSON.stringify(backfillUrls);
      }
    }

    if (Object.keys(updates).length) {
      const sets  = Object.keys(updates).map(k => `${k} = ?`).join(', ');
      const vals  = [...Object.values(updates).map(v => v ?? null), char.id];
      await db.execute(`UPDATE characters SET ${sets} WHERE id = ?`, vals);
    }
  }
  // Return refreshed characters
  return getCharacters(storylineId);
}

async function updateStorylineAfterEpisode(storylineId, { plotSummary, episodeCount, currentSeason, currentEpisode, isCompleted }) {
  await db.execute(
    `UPDATE storylines SET plot_summary = ?, episode_count = ?, current_season = ?,
       current_episode = ?, status = ?,
       next_episode_due_date = DATE_ADD(NOW(), INTERVAL 1 DAY), updated_at = NOW()
     WHERE id = ?`,
    [plotSummary, episodeCount, currentSeason, currentEpisode,
     isCompleted ? 'completed' : 'active', storylineId]
  );
}

async function insertEpisode(data) {
  await db.execute(
    `INSERT INTO episodes
       (id, storyline_id, episode_number, season_number, script, scene_count, shot_count,
        video_url, facebook_video_id, facebook_video_link, status, safety_check_passed, safety_notes, posted_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'posted', ?, ?, NOW())`,
    [
      uuidv4(), data.storyline_id, data.episode_number, data.season_number,
      JSON.stringify(data.script), data.scene_count, data.shot_count,
      data.video_url || null, data.facebook_video_id || null, data.facebook_video_link || null,
      data.safety_check_passed ? 1 : 0, data.safety_notes || null,
    ]
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Draft episode persistence — enables resume after Magic Hour credit exhaustion
// ──────────────────────────────────────────────────────────────────────────────

/** Return the most recent draft episode for a storyline (if any). */
async function getDraftEpisode(storylineId) {
  return db.queryOne(
    `SELECT * FROM episodes WHERE storyline_id = ? AND status = 'draft' ORDER BY created_at DESC LIMIT 1`,
    [storylineId]
  );
}

/**
 * Return the most recent draft episode across ALL active storylines, plus its parent storyline.
 * Used at the top of _runPipeline to ensure a paused episode is always resumed before
 * starting new work — even if getActiveStoryline() would return a different series.
 */
async function getDraftEpisodeAny() {
  const draft = await db.queryOne(
    `SELECT e.* FROM episodes e
     JOIN storylines s ON e.storyline_id = s.id
     WHERE e.status = 'draft' AND s.status = 'active'
     ORDER BY e.created_at DESC LIMIT 1`
  );
  if (!draft) return null;
  const storyline = await db.queryOne(`SELECT * FROM storylines WHERE id = ?`, [draft.storyline_id]);
  return storyline ? { draft, storyline } : null;
}

/** Insert a new draft episode row and return its UUID. */
async function createDraftEpisode(data) {
  const id = uuidv4();
  await db.execute(
    `INSERT INTO episodes
       (id, storyline_id, episode_number, season_number, script, scene_count, shot_count,
        status, safety_check_passed, safety_notes, shot_state, scene_state)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?, '{}', '{}')`,
    [
      id, data.storyline_id, data.episode_number, data.season_number,
      JSON.stringify(data.script), data.scene_count, data.shot_count,
      data.safety_check_passed ? 1 : 0, data.safety_notes || null,
    ]
  );
  return id;
}

/**
 * Persist scene compilation state and optional paused reason for a draft episode.
 * Shot state is now stored in the dedicated `shots` table (one row per shot) —
 * this function only handles scene_state and paused_reason.
 * Pass pausedReason to record why it stopped; pass null to clear it.
 */
async function saveDraftProgress(episodeId, sceneState, pausedReason) {
  await db.execute(
    `UPDATE episodes SET scene_state = ?, paused_reason = ? WHERE id = ?`,
    [JSON.stringify(sceneState), pausedReason ?? null, episodeId]
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Shot-table helpers — replace the old shot_state JSON blob
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Insert a pending row for every shot in allShots.
 * Uses INSERT IGNORE so it is safe to call on both fresh episodes and resumes.
 */
async function upsertShotRows(episodeId, allShots) {
  for (const shot of allShots) {
    const id = uuidv4();
    await db.execute(
      `INSERT IGNORE INTO shots (id, episode_id, scene_number, shot_index, status)
       VALUES (?, ?, ?, ?, 'pending')`,
      [id, episodeId, shot.scene_number, shot.shot_index]
    );
  }
}

/**
 * Update specific columns on a shot row.
 * Accepts a plain object of { column: value } pairs.
 */
async function updateShotRow(episodeId, sceneNumber, shotIndex, updates) {
  const keys = Object.keys(updates);
  if (!keys.length) return;
  const sets = keys.map(k => `${k} = ?`).join(', ');
  const vals = [...keys.map(k => updates[k] ?? null), episodeId, sceneNumber, shotIndex];
  await db.execute(
    `UPDATE shots SET ${sets} WHERE episode_id = ? AND scene_number = ? AND shot_index = ?`,
    vals
  );
}

/**
 * Fetch all shot rows for an episode, ordered by scene then shot index.
 * Returns a Map keyed by `"${scene_number}_${shot_index}"` for O(1) lookup.
 */
async function getShotRowMap(episodeId) {
  const rows = await db.query(
    `SELECT * FROM shots WHERE episode_id = ? ORDER BY scene_number, shot_index`,
    [episodeId]
  );
  return new Map(rows.map(r => [`${r.scene_number}_${r.shot_index}`, r]));
}

/**
 * Save the final generated video URL to a draft without finalising it.
 * Used when the video is fully built but Facebook publishing failed —
 * the episode stays as a draft so Resume can retry only the FB step.
 */
async function saveDraftVideoUrl(episodeId, videoUrl, pausedReason) {
  await db.execute(
    `UPDATE episodes SET video_url = ?, paused_reason = ? WHERE id = ? AND status = 'draft'`,
    [videoUrl, pausedReason ?? null, episodeId]
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Pacing enforcement — validate / clamp scene durations after LLM generation
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Validate and enforce fast-paced editing rules on the generated episode script.
 *
 * - Fills clip_duration from shot_pacing_type defaults when missing
 * - Clamps raw generation duration to 4–5s (Magic Hour minimum/practical max)
 * - Scales down scene clip_duration totals that breach the hard cap (25s)
 * - Logs a warning (but does NOT override) for scenes that exceed the soft cap (20s)
 * - Ensures the opening scene has at least one hook shot (≤2s)
 *
 * Returns the modified script object.
 */
function _enforcePacingRules(script) {
  const PACING_DEFAULTS = {
    hook:           2.0,
    action:         2.5,
    reaction:       2.5,
    broll_cutaway:  2.5,
    dialogue_mid:   4.0,
    dialogue_full:  6.0,
    slow_dramatic:  6.0,
  };
  const scenes = script?.scenes || [];

  for (const scene of scenes) {
    const shots = scene.shots || [];

    for (const shot of shots) {
      // ── Fill missing clip_duration ────────────────────────────────────
      if (!shot.clip_duration || shot.clip_duration <= 0) {
        shot.clip_duration = PACING_DEFAULTS[shot.shot_pacing_type] || 4.0;
      }
      // Per-shot bounds: 1s minimum, 30s maximum (no hard scene cap — let the director decide)
      shot.clip_duration = Math.max(1.0, Math.min(parseFloat(shot.clip_duration), 30.0));

      // ── Raw generation duration: always 4 or 5 (MH practical range) ──
      if (!shot.duration || shot.duration < 4) shot.duration = 5;
      if (shot.duration > 5) shot.duration = 5;
    }

    // ── Scene total — informational log only, no cap enforced ────────────
    const sceneTotal = shots.reduce((s, sh) => s + (sh.clip_duration || 4), 0);
    if (sceneTotal > 20) {
      console.log(
        `[Pacing] Scene ${scene.scene_number}: ${sceneTotal.toFixed(1)}s — director's choice kept`
      );
    }
  }

  // ── Opening hook compliance ───────────────────────────────────────────────
  if (scenes.length > 0) {
    const firstShots = scenes[0].shots || [];
    const hasHook    = firstShots.slice(0, 3).some(s => s.clip_duration <= 2.0);
    if (!hasHook && firstShots.length > 0) {
      console.log(
        `[Pacing] Opening scene has no hook shot ≤2s (first shot is ${firstShots[0].clip_duration}s)` +
        ` — clamping first shot to 2.0s hook`
      );
      firstShots[0].clip_duration    = 2.0;
      firstShots[0].shot_pacing_type = firstShots[0].shot_pacing_type || 'hook';
    }
  }

  return script;
}

/** Convert a completed draft to posted status, clearing transient state columns. */
async function finalizeDraftEpisode(episodeId, data) {
  await db.execute(
    `UPDATE episodes SET
       status = 'posted', video_url = ?, facebook_video_id = ?, facebook_video_link = ?,
       shot_state = NULL, scene_state = NULL, paused_reason = NULL, posted_at = NOW()
     WHERE id = ?`,
    [data.video_url || null, data.facebook_video_id || null, data.facebook_video_link || null, episodeId]
  );
}

// ──────────────────────────────────────────────────────────────────────────────
// Shot generation with retry
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Sanitise a shot image_prompt that triggered a Google Gemini safety filter.
 * Strips known trigger terms and appends safety-friendly qualifiers so the
 * retry has a real chance of passing without losing the cinematic intent.
 */
function _sanitizeShotPrompt(imagePrompt, safetyCategories = []) {
  if (!imagePrompt) return 'cinematic portrait, neutral expression, professional studio lighting, 9:16 vertical';

  let cleaned = imagePrompt
    // Violence / harm
    .replace(/\b(blood|gore|wound|stab|shoot|shooting|gun|pistol|rifle|weapon|weapons|knife|knives|sword|dead|death|corpse|kill|killing|violent|violence|explosion|explode|fire|burning|fight|punch|attack|murder|war|combat)\b/gi, '')
    // Explicit / adult
    .replace(/\b(nude|naked|explicit|sexual|erotic|intimate|sensual|undress|lingerie)\b/gi, '')
    // Dangerous / drug
    .replace(/\b(drug|drugs|poison|toxic|illegal|narcotic)\b/gi, '')
    // Clean stray punctuation from removed words
    .replace(/,\s*,/g, ',')
    .replace(/\s{2,}/g, ' ')
    .trim();

  // Append qualifiers that steer the model away from filtered content
  cleaned += ', safe for all audiences, professional cinematic, tasteful, no graphic content';

  return cleaned || 'professional cinematic portrait, neutral mood, natural lighting, 9:16 vertical';
}

/**
 * Generate image → submit MH job → poll → upload to Cloudinary.
 * Retries up to config.shotMaxRetries times on any failure.
 * On a Google Gemini safety refusal the prompt is rewritten before each retry
 * instead of submitting the same blocked text again.
 *
 * onMhSubmitted: optional async callback(jobId, apiKey, imageTmpPublicId) called
 * immediately after the MH job is submitted and before polling begins.  Used by
 * the pipeline to persist the in-flight job so a poll interruption can be resumed
 * without regenerating the image.
 *
 * Returns { clipUrl, imageTmpPublicId } on success, or throws after all retries.
 */
/**
 * Detect MIME type from image buffer magic bytes.
 * CF Worker can return PNG, JPEG, or WebP.
 */
function _detectImageMime(buf) {
  if (!buf || buf.length < 12) return 'image/jpeg';
  if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF)                      return 'image/jpeg';
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
      buf[8] === 0x57 && buf[9] === 0x45 && buf[10]=== 0x42 && buf[11]=== 0x50)  return 'image/webp';
  return 'image/jpeg';
}

async function generateShot(shot, storyline, characterList, globalEpisodeNumber, onMhSubmitted, prevShot = null, sceneBgImageUrl = null, onImageGenerated = null) {
  const maxRetries  = config.shotMaxRetries;
  let   lastError;
  let   currentShot = shot; // may be replaced by a sanitised copy on safety refusal

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // Build prompt with character visual anchors + reference images
      const charsInShot    = _getCharsInShot(currentShot, characterList);
      const imagePrompt    = _buildShotImagePrompt(currentShot, storyline, charsInShot, prevShot, sceneBgImageUrl);
      const negativePrompt = _buildCharacterNegativePrompt(charsInShot);
      // Reference images: scene background first (highest weight), then character portraits.
      // The scene background is the first shot's static image for this scene — passing it
      // as a visual reference locks the environment/lighting across all shots in the scene.
      // Character portraits follow so identity anchoring still works.
      // CF Worker accepts up to 4 reference images total.
      const charRefs       = _collectReferenceUrls(charsInShot);
      const referenceUrls  = sceneBgImageUrl
        ? [sceneBgImageUrl, ...charRefs].slice(0, 4)
        : charRefs;
      // Primary character's seed locks their identity; secondary chars rely on text anchor
      const shotSeed = _combinedSeed(charsInShot);

      // 1. Generate image
      const imageBuffer = await imageGen.generateImage(imagePrompt, referenceUrls, shotSeed, negativePrompt);

      // 1a. Notify caller immediately after image generation — BEFORE Magic Hour submission.
      //     This is the earliest safe point to establish a scene background reference; doing
      //     it here ensures the reference persists even if MH submission or polling fails.
      if (onImageGenerated) {
        try { await onImageGenerated(imageBuffer); }
        catch (cbErr) { console.warn('[Pipeline] onImageGenerated callback failed (non-fatal):', cbErr.message); }
      }

      // 1b. Generate TTS audio for dialogue close-up shots (ai-talking-photo path)
      //     Falls back silently to image-to-video if TTS fails.
      //     The speaking character is identified first by parsing a "NAME: text"
      //     prefix in dialogue_or_action, then falls back to characters_in_shot[0].
      //     This ensures multi-character scenes assign the correct Deepgram voice.
      let talkingPhoto = null;
      if (ttsGen.shouldUseTalkingPhoto(currentShot)) {
        const dialogueText = ttsGen.extractDialogueText(currentShot.dialogue_or_action);
        if (dialogueText) {
          try {
            const audioPubId = `${config.shotsFolderRoot}/tmp/tts_${Date.now()}`;
            // Identify the speaking character for voice selection.
            // Prefer an explicit "NAME: text" speaker prefix parsed from the dialogue;
            // fall back to the first name listed in characters_in_shot.
            const parsedSpeakerName = ttsGen.extractSpeakerName(currentShot.dialogue_or_action);
            const speakerName = parsedSpeakerName || (currentShot.characters_in_shot || [])[0];
            if (parsedSpeakerName && parsedSpeakerName !== (currentShot.characters_in_shot || [])[0]) {
              console.log(`[Pipeline] Speaker override from dialogue prefix: "${parsedSpeakerName}" (was "${(currentShot.characters_in_shot || [])[0] || 'none'}")`);
            }
            const speakingChar = speakerName
              ? characterList.find(c =>
                  c.name === speakerName ||
                  c.name?.toLowerCase() === speakerName?.toLowerCase()
                ) || null
              : null;
            const { audioUrl, durationSeconds } = await ttsGen.generateAndUploadTTS(
              dialogueText, audioPubId, speakingChar
            );
            talkingPhoto = { audioUrl, durationSeconds };
          } catch (ttsErr) {
            console.warn(`[Pipeline] TTS failed for S${currentShot.scene_number}/idx${currentShot.shot_index} — using image-to-video+audio: ${ttsErr.message}`);
          }
        }
      }

      // 2. Submit Magic Hour job (talking-photo for dialogue close-ups, image-to-video for all others)
      // Pass imagePrompt so Magic Hour's prompted/expressive mode can animate correctly.
      const { jobId, apiKey, imageTmpPublicId } = await videoGen.submitVideoJob(imageBuffer, {
        motionLevel:  currentShot.motion_level || 'medium',
        duration:     currentShot.duration     || 5,
        talkingPhoto,   // null → image-to-video+audio; set → ai-talking-photo
        imagePrompt:  currentShot.image_prompt || '',
      });

      // Persist the in-flight MH job immediately so a poll interruption can be resumed
      if (onMhSubmitted) {
        try { await onMhSubmitted(jobId, apiKey, imageTmpPublicId); }
        catch (cbErr) { console.warn('[Pipeline] onMhSubmitted callback failed (non-fatal):', cbErr.message); }
      }

      // 3. Poll until video is ready
      const videoUrl = await videoGen.pollVideoJob(jobId, apiKey);

      // 4. Upload clip to Cloudinary
      const shotPubId = cloudinary.shotPublicId(
        storyline.id, globalEpisodeNumber, shot.scene_number, shot.shot_index
      );
      const clipUrl = await cloudinary.uploadVideoFromUrl(videoUrl, shotPubId);

      if (attempt > 1) {
        console.log(`[Pipeline] Shot S${shot.scene_number}/idx${shot.shot_index} succeeded on attempt ${attempt}/${maxRetries}`);
      }
      return { clipUrl, imageTmpPublicId };

    } catch (err) {
      lastError = err;

      // ── Magic Hour credit exhaustion — pause gracefully ──────────────────
      if (err.mhExhausted) break;

      // ── Google Gemini safety refusal — rewrite prompt instead of retrying ─
      if (err instanceof SafetyRefusalError) {
        const cats = err.safetyCategories.join(', ') || 'unspecified';
        console.warn(
          `[Pipeline] Safety refusal on S${shot.scene_number}/idx${shot.shot_index} ` +
          `(attempt ${attempt}/${maxRetries}): ${err.safetyReason} [${cats}] — rewriting prompt`
        );
        telegram.sendTelegram(
          `⚠️ <b>Safety refusal</b> — S${shot.scene_number}/idx${shot.shot_index}\n` +
          `Category: ${cats}\n` +
          `Rewriting prompt for retry ${attempt + 1}/${maxRetries}…`
        ).catch(() => {});
        // Sanitise only the LLM-generated part; anchors are injected by _buildShotImagePrompt
        const cleanedPrompt = _sanitizeShotPrompt(currentShot.image_prompt, err.safetyCategories);
        currentShot = { ...currentShot, image_prompt: cleanedPrompt };
        // No back-off needed — prompt is different now; hit the API immediately
        continue;
      }

      // ── CF Worker content flag — rewrite prompt instead of retrying ───────
      if (err instanceof CFSafetyRefusalError) {
        console.warn(
          `[Pipeline] CF Worker content flag on S${shot.scene_number}/idx${shot.shot_index} ` +
          `(attempt ${attempt}/${maxRetries}) — rewriting prompt`
        );
        telegram.sendTelegram(
          `⚠️ <b>CF Worker content flag</b> — S${shot.scene_number}/idx${shot.shot_index}\n` +
          `Rewriting prompt for retry ${attempt + 1}/${maxRetries}…`
        ).catch(() => {});
        const cleanedPrompt = _sanitizeShotPrompt(currentShot.image_prompt, []);
        currentShot = { ...currentShot, image_prompt: cleanedPrompt };
        continue;
      }

      console.warn(`[Pipeline] Shot S${shot.scene_number}/idx${shot.shot_index} attempt ${attempt}/${maxRetries} failed: ${err.message}`);
      if (attempt < maxRetries) await sleep(3000 * attempt); // back-off
    }
  }
  throw lastError;
}

// ──────────────────────────────────────────────────────────────────────────────
// Core pipeline
// ──────────────────────────────────────────────────────────────────────────────

let _pipelineRunning = false;

async function runStreamVersePipeline() {
  if (_pipelineRunning) {
    console.log('[Pipeline] Already running, skipping trigger.');
    return;
  }
  _pipelineRunning = true;
  state.resetForRun();
  state.updateDiskUsage(diskUsageMB());

  try {
    await _runPipeline();
  } catch (err) {
    console.error('[Pipeline] Fatal error:', err);
    state.setError(err.message);
    await telegram.sendTelegram(`❌ StreamVerse pipeline crashed:\n${err.message}`);
  } finally {
    _pipelineRunning = false;
    state.updateDiskUsage(diskUsageMB());
  }
}

async function _runPipeline() {
  // ── 1. Wake FFmpeg (anti cold-start) ──────────────────────────────────────
  console.log('[Pipeline] Waking FFmpeg service...');
  await compiler.wakeFFmpeg();
  await sleep(15000);

  // ── 2. Get / create storyline ──────────────────────────────────────────────
  state.setStatus(state.STATES.WRITING, 'Querying database...');

  // Always check for a paused draft first — across ALL active storylines.
  // Without this, getActiveStoryline() could return a different series and the
  // paused episode would be orphaned instead of resumed.
  const anyDraftInfo = await getDraftEpisodeAny();
  let storyline;
  if (anyDraftInfo) {
    storyline = anyDraftInfo.storyline;
    console.log(`[Pipeline] ↺ Draft found for "${storyline.title}" — resuming instead of starting new work`);
  } else {
    storyline = await getActiveStoryline();
  }

  if (!storyline && !anyDraftInfo) {
    const genre = _pickRandomGenre();
    console.log(`[Pipeline] No active storyline — premiering new ${genre} series`);
    state.setStatus(state.STATES.WRITING, `Creating new ${genre} series bible...`);

    const storyMap = await scriptWriter.writeNewStoryline(genre);

    // ── Create Facebook playlist for the new series ────────────────────────
    let playlistId = null;
    try { playlistId = await facebook.createPlaylist(storyMap.title, storyMap.logline || ''); }
    catch (e) { console.warn('[Pipeline] FB playlist creation failed:', e.message); }

    const storylineId = await insertStoryline({ ...storyMap, facebook_playlist_id: playlistId });

    // ── Character consistency: anchors + reference portraits ──────────────
    state.setStatus(state.STATES.WRITING, 'Generating character reference portraits...');
    await insertCharactersWithConsistency(storylineId, storyMap.character_bible);

    storyline = await db.queryOne(`SELECT * FROM storylines WHERE id = ?`, [storylineId]);

    // ── Series Premiere announcement post on Facebook ──────────────────────
    try {
      const premiereCopy = await scriptWriter.writePremiereAnnouncement(storyMap);
      await facebook.postTextAnnouncement(premiereCopy);
      console.log(`[Pipeline] Series Premiere announcement posted for "${storyMap.title}"`);
    } catch (e) {
      console.warn('[Pipeline] Premiere announcement failed:', e.message);
    }

    await telegram.sendTelegram(
      `🎬 <b>SERIES PREMIERE</b>\n"${storyMap.title}" (${genre})\n${storyMap.logline || ''}\n\n${storyMap.central_theme || ''}`
    );
  }

  // ── 3. Season / episode counters ──────────────────────────────────────────
  const episodesPerSeason = config.episodesPerSeason;
  const seasonsPerSeries  = config.seasonsPerSeries;

  let currentSeason  = storyline.current_season  || 1;
  let currentEpisode = (storyline.current_episode || 0) + 1;
  if (currentEpisode > episodesPerSeason) { currentSeason++; currentEpisode = 1; }

  const globalEpisodeNumber = (storyline.episode_count || 0) + 1;
  const isSeasonFinale      = currentEpisode === episodesPerSeason;
  const isSeriesMovie       = currentSeason > seasonsPerSeries ||
                              (currentSeason === seasonsPerSeries && currentEpisode === episodesPerSeason);
  const targetMinutes       = isSeriesMovie
    ? Math.round(config.movieMinSeconds / 60)
    : Math.round(config.targetEpisodeMinSeconds / 60);

  console.log(`[Pipeline] S${currentSeason}E${currentEpisode} (global #${globalEpisodeNumber}) finale=${isSeasonFinale} movie=${isSeriesMovie}`);
  state.setCurrentEpisode({ title: storyline.title, seasonNumber: currentSeason, episodeNumber: currentEpisode, globalEpisodeNumber, draftEpisodeId: null });

  // ── 3b. Check for an existing draft episode to resume ────────────────────
  const existingDraft   = await getDraftEpisode(storyline.id);
  let   draftEpisodeId  = existingDraft?.id || null;

  // Push the draft ID into the SSE state immediately if we're resuming,
  // so the dashboard live-counter can target the right card from the start.
  if (draftEpisodeId) {
    state.setCurrentEpisode({ title: storyline.title, seasonNumber: currentSeason, episodeNumber: currentEpisode, globalEpisodeNumber, draftEpisodeId });
  }
  const savedSceneState = {};
  let   isResuming      = false;

  if (existingDraft) {
    isResuming = true;

    // ── Fast-path: video was fully generated but Facebook failed ─────────────
    // The draft's video_url is set only after Cloudinary upload succeeds.
    // If it's present, skip ALL generation/compilation and go straight to FB.
    if (existingDraft.video_url) {
      console.log(`[Pipeline] ↺ Draft has final video — skipping generation, retrying Facebook only`);
      state.setStatus(state.STATES.UPLOADING_FB, 'Retrying Facebook upload...');
      const savedScript = (() => { try { return JSON.parse(existingDraft.script || '{}'); } catch { return {}; } })();
      const fbTitle = `${storyline.title} — S${currentSeason}E${String(currentEpisode).padStart(2,'0')} — ${savedScript.episode_title || ''}`;
      const fbDesc  = `${savedScript.caption || ''}\n\n#StreamVerseStudios #AIFilm #${storyline.genre.replace(/[^a-z0-9]/gi,'')}`;
      await telegram.sendTelegram(
        `▶️ <b>Retrying Facebook upload</b> for "<b>${storyline.title}</b>" S${currentSeason}E${currentEpisode}\n📹 Video already generated — only the upload step is running.`
      );
      try {
        const fbVideoId   = await facebook.uploadVideo(existingDraft.video_url, fbTitle, fbDesc);
        const fbPermalink = await facebook.pollVideoStatus(fbVideoId);
        if (storyline.facebook_playlist_id) await facebook.addToPlaylist(storyline.facebook_playlist_id, fbVideoId);
        await updateStorylineAfterEpisode(storyline.id, {
          plotSummary:  savedScript.updated_plot_summary || storyline.plot_summary,
          episodeCount: globalEpisodeNumber, currentSeason, currentEpisode, isCompleted: isSeriesMovie,
        });
        await finalizeDraftEpisode(existingDraft.id, {
          video_url:           existingDraft.video_url,
          facebook_video_id:   fbVideoId,
          facebook_video_link: fbPermalink,
        });
        state.addHistory({
          title:         `${storyline.title} S${currentSeason}E${currentEpisode}`,
          episodeTitle:  savedScript.episode_title,
          cloudinaryUrl: existingDraft.video_url,
          facebookLink:  fbPermalink,
          postedAt:      new Date().toISOString(),
        });
        state.setStatus(state.STATES.IDLE);
        state.setCurrentEpisode(null);
        state.updateDiskUsage(diskUsageMB());
        await telegram.sendTelegram(
          `✅ Posted S${currentSeason}E${String(currentEpisode).padStart(2,'0')} of "<b>${storyline.title}</b>"\n🔗 ${fbPermalink}`
        );
      } catch (fbErr) {
        console.error('[Pipeline] Facebook retry failed:', fbErr.message);
        await saveDraftVideoUrl(existingDraft.id, existingDraft.video_url, `Facebook publish failed: ${fbErr.message}`);
        state.setStatus(state.STATES.PAUSED, '⏸ Facebook upload failed — fix credentials and click Resume');
        await telegram.sendTelegram(
          `⏸ <b>Facebook publish still failing</b>\n\n` +
          `❌ <b>Error:</b> ${fbErr.message}\n\n` +
          `Fix the issue (token, page ID, permissions) then click <b>Resume</b> on the dashboard to retry.`
        );
      }
      return;
    }

    // Scene state (fewer rows, still stored as JSON on the episode)
    try { Object.assign(savedSceneState, JSON.parse(existingDraft.scene_state || '{}')); } catch {}
    // Shot count is loaded from the shots table after upsertShotRows below
    state.setStatus(state.STATES.GENERATING, 'Resuming — loading saved shots...');
  }

  // ── 4. Load characters with consistency guarantee ─────────────────────────
  if (!isResuming) state.setStatus(state.STATES.WRITING, 'Loading character consistency data...');
  const characterList  = await ensureCharacterConsistency(storyline.id);
  const recentEpisodes = await getRecentEpisodes(storyline.id);

  // ── 5. Write or restore episode script ───────────────────────────────────
  let episodeScript;
  if (isResuming) {
    try { episodeScript = JSON.parse(existingDraft.script || '{}'); }
    catch { episodeScript = {}; }
    // The draft's existence proves safety check already passed on the original run.
    // If the stored JSON is missing safety_check_passed (LLM sometimes omits it),
    // fall back to the dedicated DB column so we don't re-flag and abort the resume.
    if (!episodeScript.safety_check_passed) {
      episodeScript.safety_check_passed = !!existingDraft.safety_check_passed;
    }
    console.log(`[Pipeline] Restored script from draft: "${episodeScript.episode_title || 'untitled'}"`);
    if (!episodeScript.episode_title) {
      console.warn('[Pipeline] Restored script has no episode_title — continuing without it');
    }

    // ── Empty-script guard ────────────────────────────────────────────────────
    // If the stored script has no scenes, check whether any shots or compiled
    // scenes were already saved.  If there is zero progress, the draft script
    // is unresumable (corrupted / created before schema migration).
    // Regenerate the script in-place so the rest of the pipeline proceeds
    // normally instead of aborting with "No scenes compiled".
    if (!(episodeScript.scenes || []).length) {
      const doneShotCheck = await db.queryOne(
        `SELECT COUNT(*) AS cnt FROM shots WHERE episode_id = ? AND status = 'done'`,
        [existingDraft.id]
      );
      const hasDoneShots  = (doneShotCheck?.cnt || 0) > 0;
      const hasSavedScenes = Object.keys(savedSceneState).length > 0;

      if (!hasDoneShots && !hasSavedScenes) {
        console.warn(`[Pipeline] Draft ${existingDraft.id} has empty script and no saved progress — regenerating script`);
        state.setStatus(state.STATES.WRITING, 'Regenerating episode script (empty draft)...');
        episodeScript = await scriptWriter.writeEpisodeScript({
          storyline, characters: characterList, recentEpisodes,
          episodeNumber: currentEpisode, seasonNumber: currentSeason,
          isFinale: isSeasonFinale, isSeriesMovie, targetMinutes,
        });
        // Persist the fresh script + updated counts so a subsequent resume can
        // use it instead of hitting this path again.
        await db.execute(
          `UPDATE episodes SET script = ?, scene_count = ?, shot_count = ? WHERE id = ?`,
          [
            JSON.stringify(episodeScript),
            (episodeScript.scenes || []).length,
            (episodeScript.scenes || []).flatMap(s => s.shots || []).length,
            existingDraft.id,
          ]
        );
        await telegram.sendTelegram(
          `📝 <b>Script regenerated</b> for draft of "<b>${storyline.title}</b>" ` +
          `S${currentSeason}E${currentEpisode} (stored script had empty scenes)`
        );
      }
    }
  } else {
    state.setStatus(state.STATES.WRITING, 'Writing episode script...');
    episodeScript = await scriptWriter.writeEpisodeScript({
      storyline, characters: characterList, recentEpisodes,
      episodeNumber: currentEpisode, seasonNumber: currentSeason,
      isFinale: isSeasonFinale, isSeriesMovie, targetMinutes,
    });
  }

  // ── Enforce fast-paced editing rules (fill clip_duration, clamp scene totals) ──
  episodeScript = _enforcePacingRules(episodeScript);

  // ── Runtime validator: ensure ≥ 120 seconds total clip_duration ──────────────
  // Retry the script call (up to 2 times) before spending Magic Hour credits on
  // a clip that will be too short to publish. Each retry tells the LLM exactly
  // how short the previous attempt was so it knows to write more.
  {
    const _sumRuntime = (script) =>
      (script.scenes || [])
        .flatMap(s => s.shots || [])
        .reduce((sum, sh) => sum + (parseFloat(sh.clip_duration) || 0), 0);

    let _rtAttempt = 0;
    while (_rtAttempt < 2) {
      const totalSecs = _sumRuntime(episodeScript);
      if (totalSecs >= 120) break;

      _rtAttempt++;
      const msg = `Script runtime ${totalSecs.toFixed(1)}s is below the 120s minimum — retry ${_rtAttempt}/2`;
      console.warn(`[Pipeline] ${msg}`);
      await telegram.sendTelegram(
        `⏱ <b>Script too short (${totalSecs.toFixed(1)}s < 120s)</b> for "<b>${storyline.title}</b>" ` +
        `S${currentSeason}E${currentEpisode} — retrying script (attempt ${_rtAttempt}/2)…`
      ).catch(() => {});

      episodeScript = await scriptWriter.writeEpisodeScript({
        storyline, characters: characterList, recentEpisodes,
        episodeNumber: currentEpisode, seasonNumber: currentSeason,
        isFinale: isSeasonFinale, isSeriesMovie, targetMinutes,
        runtimeRetryNote:
          `The previous script had only ${totalSecs.toFixed(1)} seconds of total clip_duration. ` +
          `The minimum is 120 seconds. Add more scenes and/or increase individual clip_durations ` +
          `so the sum across ALL shots reaches at least 120 seconds.`,
      });
      episodeScript = _enforcePacingRules(episodeScript);
    }

    // After retries, warn but don't abort — a short episode is better than none.
    const finalSecs = _sumRuntime(episodeScript);
    if (finalSecs < 120) {
      console.warn(`[Pipeline] Script still short after retries (${finalSecs.toFixed(1)}s) — proceeding anyway`);
      await telegram.sendTelegram(
        `⚠️ <b>Script still short (${finalSecs.toFixed(1)}s)</b> after 2 retries for "<b>${storyline.title}</b>" ` +
        `S${currentSeason}E${currentEpisode} — proceeding with what we have.`
      ).catch(() => {});
    }
  }

  if (!episodeScript.safety_check_passed) {
    await telegram.sendTelegram(`⚠️ Content flag on ep ${globalEpisodeNumber} of "${storyline.title}". Skipping.`);
    state.setError(`Content flag: ${episodeScript.safety_notes}`);
    return;
  }

  const scenes   = episodeScript.scenes || [];
  const allShots = scenes.flatMap(s =>
    (s.shots || []).map(sh => ({
      ...sh,
      scene_number:        s.scene_number,
      composition:         s.composition,
      characters_in_shot:  sh.characters_in_shot || s.characters_present || [],
      // Scene-level context injected into the image prompt for narrative continuity
      _scene_description:  s.scene_description || '',
      _scene_location:     s.location          || '',
      _scene_emotion:      s.emotional_beat    || '',
      _lighting_design:    s.lighting_design   || '',
      _camera_language:    s.camera_language   || '',
      // Episode-level context — gives the image model the story thread each shot belongs to
      _episode_title:      episodeScript.episode_title   || '',
      _episode_logline:    episodeScript.logline          ||
                           storyline.logline              ||
                           storyline.plot_summary         || '',
    }))
  );

  // ── 5b. Create draft record (first run) or reuse existing (resume) ────────
  if (!draftEpisodeId) {
    draftEpisodeId = await createDraftEpisode({
      storyline_id:        storyline.id,
      episode_number:      globalEpisodeNumber,
      season_number:       currentSeason,
      script:              episodeScript,
      scene_count:         scenes.length,
      shot_count:          allShots.length,
      safety_check_passed: episodeScript.safety_check_passed,
      safety_notes:        episodeScript.safety_notes,
    });
    console.log(`[Pipeline] Draft episode created: ${draftEpisodeId}`);
    // Now that we have the draft ID, push it into the SSE state so the
    // dashboard live-counter targets the right card for new episodes too.
    state.setCurrentEpisode({ title: storyline.title, seasonNumber: currentSeason, episodeNumber: currentEpisode, globalEpisodeNumber, draftEpisodeId });
    state.setStatus(state.STATES.GENERATING, `Generating ${allShots.length} shots...`);
    await telegram.sendTelegram(
      `🎬 Ep ${globalEpisodeNumber} started: <b>${episodeScript.episode_title}</b> | ${allShots.length} shots | ${characterList.length} chars with identity lock`
    );
  }

  // ── 6. Generate shots — backed by the shots table for reliable persistence ──
  // Each shot gets its own DB row.  State transitions written atomically:
  //   pending → mh_submitted (after MH job is submitted, before polling)
  //   mh_submitted → done    (after clip is uploaded to Cloudinary)
  //   any → failed           (after all retries exhausted)
  //
  // On resume after a Replit restart the loop:
  //   • skips 'done' rows and restores their clip URLs
  //   • resumes 'mh_submitted' rows by polling the saved job ID
  //   • regenerates 'pending'/'failed' rows from scratch
  //
  // Backward compat: old drafts may have shot URLs in the shot_state JSON column
  // and no shots-table rows yet.  upsertShotRows creates any missing rows, then
  // the migration block below promotes old JSON entries to 'done' rows.

  // Ensure every shot has a row (idempotent INSERT IGNORE)
  await upsertShotRows(draftEpisodeId, allShots);

  // Migrate old shot_state JSON → shots table (one-time, for pre-shots-table drafts)
  const legacyShotState = {};
  try { Object.assign(legacyShotState, JSON.parse(existingDraft?.shot_state || '{}')); } catch {}
  for (const [key, val] of Object.entries(legacyShotState)) {
    if (key.endsWith('_mh')) continue; // skip old in-flight keys
    const parts = key.split('_');
    const sceneNum = parseInt(parts[0], 10);
    const shotIdx  = parseInt(parts[1], 10);
    if (isNaN(sceneNum) || isNaN(shotIdx)) continue;
    const clipData  = typeof val === 'string' ? { url: val, clipDuration: 4 } : val;
    if (!clipData.url) continue;
    // Only overwrite if the row is still pending (don't clobber newer data)
    await db.execute(
      `UPDATE shots SET status = 'done', clip_url = ?, clip_duration = ?
       WHERE episode_id = ? AND scene_number = ? AND shot_index = ? AND status = 'pending'`,
      [clipData.url, clipData.clipDuration || 4, draftEpisodeId, sceneNum, shotIdx]
    );
  }

  // Load current shot state from table
  let shotRowMap = await getShotRowMap(draftEpisodeId);

  const shotClipsByScene  = new Map();
  const tmpImagePublicIds = [];
  let shotSuccesses = [...shotRowMap.values()].filter(r => r.status === 'done').length;
  let shotFailures  = 0;
  const retryLog    = [];
  let   mhWasExhausted  = false;
  let   tooManyFailed   = false; // set when shotFailAbortPct is exceeded — pauses instead of crashing

  // ── Scene background reference tracking ───────────────────────────────────
  // Maps scene_number → Cloudinary image URL of the established background for
  // that scene.  Passed as a visual reference to all shots after the first so
  // the model reproduces the same environment, lighting, and spatial layout.
  //
  // Background images live at a PERMANENT Cloudinary path (sceneBgPublicId) that
  // is NOT in tmpImagePublicIds and therefore NOT deleted by the episode cleanup
  // loop.  The BG is uploaded via the onImageGenerated callback inside generateShot
  // — i.e. immediately after image generation, before Magic Hour submission — so
  // even a MH failure or restart cannot prevent the reference from being persisted.
  //
  // On resume, we pre-populate the map for any scene whose image was already
  // generated in a prior session.  We include both 'done' AND 'mh_submitted' rows
  // because mh_submitted means the static image was generated and the BG callback
  // already fired before MH was called — the persistent BG path exists for them.
  //
  // If a persistent BG path does not yet exist (older episode, first session
  // failure during BG upload), cfImageGen silently skips the 404 reference —
  // acceptable graceful degradation.
  const sceneFirstImageUrls = new Map();
  const scenesWithGeneratedImage = new Set(
    [...shotRowMap.values()]
      .filter(r => r.status === 'done' || r.status === 'mh_submitted')
      .map(r => r.scene_number)
  );
  for (const sceneNum of scenesWithGeneratedImage) {
    const bgPubId = cloudinary.sceneBgPublicId(storyline.id, globalEpisodeNumber, sceneNum);
    sceneFirstImageUrls.set(sceneNum, cloudinary.imageDeliveryUrl(bgPubId));
  }

  if (isResuming) {
    console.log(`[Pipeline] Resuming draft ${draftEpisodeId}: ${shotSuccesses}/${allShots.length} shots already done`);
    state.setStatus(state.STATES.GENERATING, `Resuming — ${shotSuccesses} shots saved, continuing...`);
    state.setShotProgress(shotSuccesses, allShots.length);
    await telegram.sendTelegram(
      `▶️ <b>Resuming paused episode</b> of "<b>${storyline.title}</b>"\n` +
      `${shotSuccesses}/${allShots.length} shots already saved — picking up where we left off...`
    );
  } else {
    state.setShotProgress(0, allShots.length);
  }

  for (let i = 0; i < allShots.length; i++) {
    const shot     = allShots[i];
    const prevShot = i > 0 ? allShots[i - 1] : null;
    const stateKey = `${shot.scene_number}_${shot.shot_index}`;
    const shotRow  = shotRowMap.get(stateKey);

    if (!shotClipsByScene.has(shot.scene_number)) shotClipsByScene.set(shot.scene_number, []);

    // ── Already done: restore clip URL and move on ───────────────────────
    if (shotRow?.status === 'done' && shotRow.clip_url) {
      const clipEntry = { url: shotRow.clip_url, clipDuration: parseFloat(shotRow.clip_duration) || shot.clip_duration || 4 };
      shotClipsByScene.get(shot.scene_number).push(clipEntry);
      state.setProgress(i + 1, allShots.length, `Shot ${i + 1}/${allShots.length} — resumed ✓`);
      continue; // sceneFirstImageUrls already populated from shotRowMap pre-scan above
    }

    // ── Resume an in-flight MH job interrupted mid-poll ──────────────────
    // The row was written to status='mh_submitted' before polling began, so
    // a Replit restart during the poll can continue from the saved job ID.
    if (shotRow?.status === 'mh_submitted' && shotRow.mh_job_id) {
      console.log(`[Pipeline] Shot S${shot.scene_number}/idx${shot.shot_index} — resuming saved MH job ${shotRow.mh_job_id}`);
      state.setProgress(i + 1, allShots.length, `Shot ${i + 1}/${allShots.length} — resuming MH poll`);
      try {
        const videoUrl = await videoGen.pollVideoJob(shotRow.mh_job_id, shotRow.mh_api_key);
        const shotPubId = cloudinary.shotPublicId(storyline.id, globalEpisodeNumber, shot.scene_number, shot.shot_index);
        const clipUrl   = await cloudinary.uploadVideoFromUrl(videoUrl, shotPubId);
        const clipDuration = shot.clip_duration || shot.duration || 4;
        await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
          status: 'done', clip_url: clipUrl, clip_duration: clipDuration,
          mh_job_id: null, mh_api_key: null,
        });
        const clipEntry = { url: clipUrl, clipDuration: clipDuration };
        shotClipsByScene.get(shot.scene_number).push(clipEntry);
        shotSuccesses++;
        state.setShotProgress(shotSuccesses, allShots.length);
        state.setProgress(i + 1, allShots.length, `Shot ${i + 1}/${allShots.length} — resumed MH ✓`);
        console.log(`[Pipeline] Shot S${shot.scene_number}/idx${shot.shot_index} completed via resumed MH poll`);
        continue;
      } catch (pollErr) {
        // Job expired / errored — reset to pending so we regenerate
        console.warn(`[Pipeline] Saved MH job ${shotRow.mh_job_id} failed (${pollErr.message}) — regenerating`);
        await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
          status: 'pending', mh_job_id: null, mh_api_key: null,
          error_count: (shotRow.error_count || 0) + 1, last_error: pollErr.message.slice(0, 500),
        });
        // fall through to normal generation
      }
    }

    state.setProgress(i + 1, allShots.length, `Shot ${i + 1}/${allShots.length} — Scene ${shot.scene_number}`);

    // Pass the established scene background to shots 2+ so the model reproduces the environment
    const sceneBgRef = sceneFirstImageUrls.get(shot.scene_number) || null;
    // onImageGenerated: fires immediately after image generation, BEFORE Magic Hour.
    // This is the correct moment to establish the scene BG — if MH or video-upload
    // later fails, the persistent reference is already in Cloudinary so any retry or
    // resumed shot in this scene will still use the correct background.
    const isFirstInScene = !sceneFirstImageUrls.has(shot.scene_number);
    const onImageGenerated = isFirstInScene
      ? async (imageBuffer) => {
          const bgPubId = cloudinary.sceneBgPublicId(storyline.id, globalEpisodeNumber, shot.scene_number);
          const mime    = _detectImageMime(imageBuffer);
          const dataUri = `data:${mime};base64,${imageBuffer.toString('base64')}`;
          await cloudinary.uploadImageFromUrl(dataUri, bgPubId);
          sceneFirstImageUrls.set(shot.scene_number, cloudinary.imageDeliveryUrl(bgPubId));
          console.log(`[Pipeline] Scene ${shot.scene_number} background locked → ${bgPubId}`);
        }
      : null;

    try {
      const { clipUrl, imageTmpPublicId } = await generateShot(
        shot, storyline, characterList, globalEpisodeNumber,
        // onMhSubmitted: write job ID to DB before polling so a restart can resume the poll
        async (jobId, apiKey, imgTmpPubId) => {
          await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
            status:     'mh_submitted',
            mh_job_id:  jobId,
            mh_api_key: apiKey,
            image_url:  imgTmpPubId || null,
          });
          console.log(`[Pipeline] Shot S${shot.scene_number}/idx${shot.shot_index} MH job ${jobId} written to DB — safe to restart`);
        },
        prevShot,          // scene continuity context for the image prompt
        sceneBgRef,        // scene background reference image (null for first shot in scene)
        onImageGenerated   // uploads persistent scene BG before MH submission
      );
      if (imageTmpPublicId) tmpImagePublicIds.push(imageTmpPublicId);

      const clipDuration = shot.clip_duration || shot.duration || 4;
      await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
        status: 'done', clip_url: clipUrl, clip_duration: clipDuration,
        mh_job_id: null, mh_api_key: null,
      });
      shotClipsByScene.get(shot.scene_number).push({ url: clipUrl, clipDuration: clipDuration });
      shotSuccesses++;
      state.setShotProgress(shotSuccesses, allShots.length);

    } catch (err) {
      // ── Magic Hour credit exhaustion — pause gracefully ─────────────────
      if (err.mhExhausted) {
        mhWasExhausted = true;
        const reason = `Magic Hour credits exhausted after ${shotSuccesses} of ${allShots.length} shots`;
        await saveDraftProgress(draftEpisodeId, savedSceneState, reason);
        state.setShotProgress(shotSuccesses, allShots.length);
        state.setStatus(state.STATES.PAUSED,
          `⏸ Paused — Magic Hour credits exhausted. ${shotSuccesses}/${allShots.length} shots saved.`);
        await telegram.sendTelegram(
          `⏸ <b>Episode paused — Magic Hour credits exhausted</b>\n` +
          `✅ ${shotSuccesses}/${allShots.length} shots saved to database.\n` +
          `Top up your credits and click <b>Resume</b> on the dashboard to continue from where we stopped.`
        );
        break;
      }

      // ── Regular shot failure ───────────────────────────────────────────
      shotFailures++;
      const msg = `Shot ${i + 1} (S${shot.scene_number}/idx${shot.shot_index}) failed after ${config.shotMaxRetries} retries: ${err.message}`;
      console.error(`[Pipeline] ${msg}`);
      retryLog.push(msg);
      await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
        status: 'failed',
        error_count: (shotRow?.error_count || 0) + config.shotMaxRetries,
        last_error: err.message.slice(0, 500),
      }).catch(() => {});
      await telegram.sendTelegram(`⚠️ ${msg}`);

      const totalSoFar = shotSuccesses + shotFailures;
      if (totalSoFar >= Math.ceil(allShots.length / 2)) {
        const failPct = shotFailures / allShots.length;
        if (failPct > config.shotFailAbortPct) {
          // Pause gracefully instead of crashing — preserves all saved shots so Resume can continue
          tooManyFailed = true;
          const reason = `Too many shots failed: ${Math.round(failPct * 100)}% (threshold ${Math.round(config.shotFailAbortPct * 100)}%). Fix API keys and click Resume.`;
          console.error(`[Pipeline] ${reason}`);
          await saveDraftProgress(draftEpisodeId, savedSceneState, reason);
          state.setShotProgress(shotSuccesses, allShots.length);
          state.setStatus(state.STATES.PAUSED, `⏸ Paused — ${reason}`);
          await telegram.sendTelegram(
            `⏸ <b>Episode paused — too many shot failures</b>\n` +
            `✅ ${shotSuccesses}/${allShots.length} shots saved to database.\n` +
            `❌ ${shotFailures} shots failed (${Math.round(failPct * 100)}% failure rate).\n\n` +
            `Fix your API keys (Google, Magic Hour) and click <b>Resume</b> on the dashboard to continue.`
          );
          break;
        }
      }
    }
  }

  // Episode paused — exit cleanly; all shot rows persisted; state is PAUSED
  // Both Magic Hour credit exhaustion and high-failure-rate abort pause gracefully here.
  if (mhWasExhausted || tooManyFailed) return;

  // ── Second-pass: retry any shots that failed in the main pass ───────────────
  // A transient API error mid-run may leave some shots marked 'failed' while
  // others succeeded.  Before proceeding to compilation we make one additional
  // attempt at every failed shot so no clip is silently skipped.
  {
    const failedRows = await db.query(
      `SELECT scene_number, shot_index FROM shots WHERE episode_id = ? AND status = 'failed'
       ORDER BY scene_number, shot_index`,
      [draftEpisodeId]
    );
    if (failedRows.length > 0) {
      console.log(`[Pipeline] Second-pass retry: ${failedRows.length} failed shot(s)`);
      state.setStatus(state.STATES.GENERATING, `Retrying ${failedRows.length} failed shot(s)...`);
      await telegram.sendTelegram(
        `🔄 <b>Second-pass retry</b> — ${failedRows.length} shot(s) failed in first pass, retrying now…`
      );

      for (const row of failedRows) {
        const shot    = allShots.find(s => s.scene_number === row.scene_number && s.shot_index === row.shot_index);
        if (!shot) continue;
        const shotIdx = allShots.indexOf(shot);
        const prevShot = shotIdx > 0 ? allShots[shotIdx - 1] : null;

        // Reset to pending so generateShot can overwrite it on success
        await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, { status: 'pending' });

        const retrySceneBgRef = sceneFirstImageUrls.get(shot.scene_number) || null;
        const retryIsFirstInScene = !sceneFirstImageUrls.has(shot.scene_number);
        const retryOnImageGenerated = retryIsFirstInScene
          ? async (imageBuffer) => {
              const bgPubId = cloudinary.sceneBgPublicId(storyline.id, globalEpisodeNumber, shot.scene_number);
              const mime    = _detectImageMime(imageBuffer);
              const dataUri = `data:${mime};base64,${imageBuffer.toString('base64')}`;
              await cloudinary.uploadImageFromUrl(dataUri, bgPubId);
              sceneFirstImageUrls.set(shot.scene_number, cloudinary.imageDeliveryUrl(bgPubId));
              console.log(`[Pipeline] Scene ${shot.scene_number} background locked (retry) → ${bgPubId}`);
            }
          : null;
        try {
          const { clipUrl, imageTmpPublicId } = await generateShot(
            shot, storyline, characterList, globalEpisodeNumber,
            async (jobId, apiKey, imgTmpPubId) => {
              await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
                status: 'mh_submitted', mh_job_id: jobId, mh_api_key: apiKey, image_url: imgTmpPubId || null,
              });
            },
            prevShot,
            retrySceneBgRef,
            retryOnImageGenerated
          );
          if (imageTmpPublicId) tmpImagePublicIds.push(imageTmpPublicId);
          const clipDuration = shot.clip_duration || shot.duration || 4;
          await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
            status: 'done', clip_url: clipUrl, clip_duration: clipDuration, mh_job_id: null, mh_api_key: null,
          });
          if (!shotClipsByScene.has(shot.scene_number)) shotClipsByScene.set(shot.scene_number, []);
          shotClipsByScene.get(shot.scene_number).push({ url: clipUrl, clipDuration: clipDuration });
          shotSuccesses++;
          shotFailures = Math.max(0, shotFailures - 1);
          state.setShotProgress(shotSuccesses, allShots.length);
          console.log(`[Pipeline] Second-pass retry succeeded: S${shot.scene_number}/idx${shot.shot_index}`);
        } catch (retryErr) {
          if (retryErr.mhExhausted) {
            mhWasExhausted = true;
            const reason = `Magic Hour credits exhausted during second-pass retry after ${shotSuccesses} shots`;
            await saveDraftProgress(draftEpisodeId, savedSceneState, reason);
            state.setStatus(state.STATES.PAUSED,
              `⏸ Paused — Magic Hour credits exhausted. ${shotSuccesses}/${allShots.length} shots saved.`);
            await telegram.sendTelegram(
              `⏸ <b>Episode paused — Magic Hour credits exhausted</b>\n` +
              `✅ ${shotSuccesses}/${allShots.length} shots saved. Top up and click <b>Resume</b>.`
            );
            break;
          }
          await updateShotRow(draftEpisodeId, shot.scene_number, shot.shot_index, {
            status: 'failed', last_error: retryErr.message.slice(0, 500),
          }).catch(() => {});
          console.warn(`[Pipeline] Second-pass retry failed: S${shot.scene_number}/idx${shot.shot_index} — ${retryErr.message}`);
        }
      }
    }
  }

  if (mhWasExhausted) return;

  if (retryLog.length > 0) {
    await telegram.sendTelegram(
      `📊 Shot summary for ep ${globalEpisodeNumber}:\n✅ ${shotSuccesses} succeeded\n❌ ${shotFailures} failed\n\n${retryLog.slice(0, 5).join('\n')}`
    );
  }

  // ── DB fallback: rebuild shotClipsByScene when allShots was empty ──────────
  // On resume the script is loaded from the draft row. If that JSON has empty /
  // malformed scenes (e.g. stored as "untitled" with no scene data), allShots
  // will be length 0, the shot loop never runs, and shotClipsByScene stays empty.
  // Fix: when the map is empty, query the shots table directly so compilation
  // can still proceed with the clips that were already generated.
  if (shotClipsByScene.size === 0 && draftEpisodeId) {
    const doneRows = await db.query(
      `SELECT scene_number, clip_url, clip_duration
       FROM shots WHERE episode_id = ? AND status = 'done'
       ORDER BY scene_number, shot_index`,
      [draftEpisodeId]
    );
    for (const row of doneRows) {
      if (!shotClipsByScene.has(row.scene_number)) shotClipsByScene.set(row.scene_number, []);
      shotClipsByScene.get(row.scene_number).push({
        url:          row.clip_url,
        clipDuration: parseFloat(row.clip_duration) || 4,
      });
    }
    if (shotClipsByScene.size > 0) {
      console.log(`[Pipeline] Rebuilt shotClipsByScene from DB: ${doneRows.length} done shots across ${shotClipsByScene.size} scenes`);
    }
  }

  // ── 7. Compose scenes (skip already compiled; persist each result) ─────────
  state.setStatus(state.STATES.COMPILING, 'Composing scenes...');
  // Union of scenes that need compilation (in shotClipsByScene) and scenes that
  // were already compiled in a prior run (in savedSceneState). This ensures that
  // scenes compiled before a crash are still included in the final merge even if
  // shotClipsByScene was rebuilt from the DB and doesn't cover every scene.
  const allSceneNums = new Set([
    ...shotClipsByScene.keys(),
    ...Object.keys(savedSceneState).map(Number),
  ]);
  const sceneNums = [...allSceneNums].sort((a, b) => a - b);
  const sceneMeta = Object.fromEntries(scenes.map(s => [s.scene_number, s.composition || 'cut']));
  const sceneUrls = [];

  for (let si = 0; si < sceneNums.length; si++) {
    const sceneNum = sceneNums[si];
    const clips    = shotClipsByScene.get(sceneNum) || [];
    state.setProgress(si + 1, sceneNums.length, `Composing scene ${si + 1}/${sceneNums.length}`);

    if (!clips.length) { console.warn(`[Pipeline] Scene ${sceneNum} has no clips, skipping`); continue; }

    // Reuse previously compiled URL on resume
    if (savedSceneState[sceneNum]) {
      console.log(`[Pipeline] Scene ${sceneNum} already compiled — reusing`);
      sceneUrls.push(savedSceneState[sceneNum]);
      continue;
    }

    try {
      const jobId    = await compiler.composeScene(clips, sceneMeta[sceneNum] || 'cut');
      const sceneUrl = await compiler.pollFFmpegJob(jobId);
      sceneUrls.push(sceneUrl);
      savedSceneState[sceneNum] = sceneUrl;
      await saveDraftProgress(draftEpisodeId, savedSceneState, null);
    } catch (err) {
      console.error(`[Pipeline] Scene ${sceneNum} compose failed:`, err.message);
      await telegram.sendTelegram(`⚠️ Scene ${sceneNum} compose failed: ${err.message}`);
    }
  }

  if (!sceneUrls.length) {
    // Gracefully pause instead of crashing — preserves all shots so Resume can retry compilation.
    const reason = 'No scenes compiled — all scene composition jobs failed. Fix the FFmpeg service and click Resume.';
    console.error(`[Pipeline] ${reason}`);
    await saveDraftProgress(draftEpisodeId, savedSceneState, reason);
    state.setStatus(state.STATES.PAUSED, `⏸ No scenes compiled — FFmpeg compose failed`);
    await telegram.sendTelegram(
      `⏸ <b>Episode paused — no scenes compiled</b>\n\n` +
      `All scene composition jobs failed.\n` +
      `Check FFmpeg service logs, then click <b>Resume</b> on the dashboard to retry.`
    );
    return;
  }

  // ── 8. Merge all scenes → final video ────────────────────────────────────
  state.setStatus(state.STATES.COMPILING, 'Merging final episode...');
  const mergeJobId    = await compiler.mergeScenes(sceneUrls, {
    introBumperUrl: process.env.INTRO_BUMPER_URL || null,
    outroBumperUrl: process.env.OUTRO_BUMPER_URL || null,
  });
  const finalVideoUrl = await compiler.pollFFmpegJob(mergeJobId);

  // ── 9. Upload final video to Cloudinary (permanent) ───────────────────────
  const epPubId            = cloudinary.episodePublicId(storyline.id, globalEpisodeNumber);
  const cloudinaryEpUrlRaw = await cloudinary.uploadVideoFromUrl(finalVideoUrl, epPubId);

  // Apply logo overlay to cover Magic Hour watermark (bottom-right corner).
  // Cloudinary applies this as a delivery-time transformation — no re-encoding needed.
  const cloudinaryEpUrl = cloudinary.buildLogoOverlayUrl(cloudinaryEpUrlRaw) || cloudinaryEpUrlRaw;
  console.log(`[Pipeline] Final episode URL (with logo overlay): ${cloudinaryEpUrl}`);

  // ── 10. Publish to Facebook ───────────────────────────────────────────────
  state.setStatus(state.STATES.UPLOADING_FB, 'Uploading to Facebook...');
  const fbTitle = `${storyline.title} — S${currentSeason}E${String(currentEpisode).padStart(2,'0')} — ${episodeScript.episode_title}`;
  const fbDesc  = `${episodeScript.caption || ''}\n\n#StreamVerseStudios #AIFilm #${storyline.genre.replace(/[^a-z0-9]/gi,'')}`;

  let fbVideoId   = null;
  let fbPermalink = null;
  try {
    fbVideoId   = await facebook.uploadVideo(cloudinaryEpUrl, fbTitle, fbDesc);
    fbPermalink = await facebook.pollVideoStatus(fbVideoId);
    if (storyline.facebook_playlist_id) await facebook.addToPlaylist(storyline.facebook_playlist_id, fbVideoId);
    await telegram.sendTelegram(
      `✅ Posted S${currentSeason}E${String(currentEpisode).padStart(2,'0')} of "<b>${storyline.title}</b>"\n🔗 ${fbPermalink}`
    );
  } catch (err) {
    console.error('[Pipeline] Facebook publish failed:', err.message);
    // Video is fully generated — save its URL in the draft so Resume retries only this step
    await saveDraftVideoUrl(draftEpisodeId, cloudinaryEpUrl, `Facebook publish failed: ${err.message}`);
    state.setStatus(state.STATES.PAUSED, '⏸ Episode ready — Facebook upload failed, fix credentials and click Resume');
    await telegram.sendTelegram(
      `⏸ <b>Episode fully generated — Facebook publish failed</b>\n\n` +
      `📹 Video is ready on Cloudinary:\n${cloudinaryEpUrl}\n\n` +
      `❌ <b>Error:</b> ${err.message}\n\n` +
      `Fix the issue (token, page ID, permissions) then click <b>Resume</b> on the dashboard to retry the upload.`
    );
    return; // Leave as draft — Resume will skip generation and retry Facebook only
  }

  // ── 11. DB updates — finalize draft → posted ──────────────────────────────
  await updateStorylineAfterEpisode(storyline.id, {
    plotSummary:    episodeScript.updated_plot_summary || storyline.plot_summary,
    episodeCount:   globalEpisodeNumber,
    currentSeason,
    currentEpisode,
    isCompleted:    isSeriesMovie,
  });

  await finalizeDraftEpisode(draftEpisodeId, {
    video_url:           cloudinaryEpUrl,
    facebook_video_id:   fbVideoId,
    facebook_video_link: fbPermalink,
  });

  // ── 12. Dashboard history + cleanup ──────────────────────────────────────
  state.addHistory({
    title:         `${storyline.title} S${currentSeason}E${currentEpisode}`,
    episodeTitle:  episodeScript.episode_title,
    cloudinaryUrl: cloudinaryEpUrl,
    facebookLink:  fbPermalink,
    postedAt:      new Date().toISOString(),
  });
  state.setStatus(state.STATES.IDLE);
  state.setCurrentEpisode(null);
  state.updateDiskUsage(diskUsageMB());

  for (const pubId of tmpImagePublicIds) {
    try { await cloudinary.deleteResource(pubId, 'image'); } catch {}
  }

  console.log(`[Pipeline] Episode ${globalEpisodeNumber} complete.`);

  // ── 13. Series finale → announce + immediately chain next premiere ─────────
  if (isSeriesMovie) {
    console.log(`[Pipeline] "${storyline.title}" series complete after ${globalEpisodeNumber} episodes. Scheduling next premiere...`);

    try {
      const finalePost = await scriptWriter.writeFinaleAnnouncement({
        ...storyline,
        episode_count: globalEpisodeNumber,
      });
      await facebook.postTextAnnouncement(finalePost);
    } catch (e) {
      console.warn('[Pipeline] Finale announcement failed:', e.message);
    }

    await telegram.sendTelegram(
      `🏁 "<b>${storyline.title}</b>" series complete!\n${globalEpisodeNumber} total episodes across 4 seasons.\n\nA new series premiere is starting now...`
    );

    const PREMIERE_DELAY_MS = parseInt(process.env.PREMIERE_DELAY_MS || '300000', 10);
    console.log(`[Pipeline] Next premiere fires in ${PREMIERE_DELAY_MS / 1000}s...`);
    setTimeout(() => {
      runStreamVersePipeline().catch(err =>
        console.error('[Pipeline] Auto-premiere failed:', err.message)
      );
    }, PREMIERE_DELAY_MS);
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Reels pipeline
// ──────────────────────────────────────────────────────────────────────────────

async function runReelsPipeline() {
  if (_pipelineRunning) { console.log('[Reels] Main pipeline running, skipping.'); return; }
  try {
    const latest = await db.queryOne(
      `SELECT e.*, s.title AS show_title, s.genre, s.id AS storyline_id
       FROM episodes e JOIN storylines s ON e.storyline_id = s.id
       WHERE e.status = 'posted' ORDER BY e.posted_at DESC LIMIT 1`
    );
    if (!latest) { console.log('[Reels] No episodes to promote.'); return; }

    const folderPrefix = `${config.shotsFolderRoot}/${latest.storyline_id}/ep${latest.episode_number}/`;
    const shots = await cloudinary.listFolder(folderPrefix);
    if (!shots.length) { console.log('[Reels] No shot clips found.'); return; }

    const seenScenes = new Set();
    const reelShots  = [];
    for (const s of shots) {
      const m = s.public_id.match(/scene_(\d+)\/shot_/);
      if (m && !seenScenes.has(m[1])) { seenScenes.add(m[1]); reelShots.push(s.secure_url); }
      if (reelShots.length >= 3) break;
    }

    const caption = await scriptWriter.writeShotCaption(
      latest.show_title, latest.genre, `Episode ${latest.episode_number} highlight`
    );
    for (const shotUrl of reelShots) { await facebook.postReel(shotUrl, caption); await sleep(5000); }
    console.log(`[Reels] Posted ${reelShots.length} Reels`);
  } catch (err) {
    console.error('[Reels] Error:', err.message);
    await telegram.sendTelegram(`⚠️ Reels post failed: ${err.message}`);
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Comment reminder
// ──────────────────────────────────────────────────────────────────────────────

async function runCommentReminder() {
  try {
    const eps = await db.query(
      `SELECT episode_number, script, facebook_video_link, posted_at
       FROM episodes WHERE status = 'posted' AND posted_at > DATE_SUB(NOW(), INTERVAL 3 DAY)
       ORDER BY posted_at DESC`
    );
    if (!eps.length) return;
    const lines = eps.map(e => {
      const sc = JSON.parse(e.script || '{}');
      return `• Ep ${e.episode_number} "${sc.episode_title || ''}" → ${e.facebook_video_link || 'N/A'}`;
    });
    await telegram.sendTelegram(`💬 Engagement reminder:\n${lines.join('\n')}`);
  } catch (err) { console.error('[CommentReminder] Error:', err.message); }
}

// ──────────────────────────────────────────────────────────────────────────────
// Auto comment reply pipeline
// Fetches recent unanswered comments on the last few videos and replies with AI
// ──────────────────────────────────────────────────────────────────────────────

async function runAutoCommentReplies() {
  if (_pipelineRunning) { console.log('[Comments] Main pipeline running, skipping.'); return; }
  console.log('[Comments] Running auto-reply pipeline...');

  try {
    // Get recent videos from the Facebook Page
    const videos = await facebook.fetchRecentVideos(4);
    if (!videos.length) { console.log('[Comments] No videos found.'); return; }

    // Also load active storyline for context
    const storyline = await getActiveStoryline();
    const storyTitle = storyline?.title || 'StreamVerse Studios';
    const genre      = storyline?.genre  || 'drama';

    let totalReplied = 0;

    for (const video of videos) {
      const comments = await facebook.fetchVideoComments(video.id, 20);
      if (!comments.length) continue;

      // Reply to up to 5 comments per video (avoid spam)
      const toReply = comments.slice(0, 5);
      for (const comment of toReply) {
        const commentText = comment.message || '';
        if (!commentText.trim() || commentText.length < 5) continue;

        // Like the comment first (signals engagement to the algorithm)
        await facebook.likeComment(comment.id);

        // Generate AI reply
        const latestEp = await db.queryOne(
          `SELECT script FROM episodes WHERE status = 'posted' ORDER BY posted_at DESC LIMIT 1`
        );
        const sc = JSON.parse(latestEp?.script || '{}');
        const episodeTitle = sc.episode_title || 'Latest Episode';

        const reply = await scriptWriter.writeAutoCommentReply({
          storylineTitle: storyTitle,
          genre,
          episodeTitle,
          commentText,
        });

        if (reply) {
          await facebook.replyToComment(comment.id, reply);
          totalReplied++;
          await sleep(3000); // rate-limit guard
        }
      }
    }

    if (totalReplied > 0) {
      console.log(`[Comments] Auto-replied to ${totalReplied} comments`);
      await telegram.sendTelegram(`💬 Auto-replied to <b>${totalReplied}</b> Facebook comments`);
    }
  } catch (err) {
    console.error('[Comments] Auto-reply error:', err.message);
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Engagement post pipeline
// Posts a standalone conversation-starter between episode drops
// ──────────────────────────────────────────────────────────────────────────────

async function runEngagementPost() {
  if (_pipelineRunning) { console.log('[Engagement] Main pipeline running, skipping.'); return; }
  console.log('[Engagement] Running engagement post pipeline...');

  try {
    const storyline = await getActiveStoryline();
    if (!storyline) { console.log('[Engagement] No active show.'); return; }

    const postText = await scriptWriter.writeEngagementPost({
      storylineTitle: storyline.title,
      genre:          storyline.genre,
      centralTheme:   storyline.central_theme  || storyline.plot_summary || '',
      engagementHook: storyline.engagement_hook || '',
      episodeCount:   storyline.episode_count   || 0,
    });

    if (!postText) { console.log('[Engagement] No post generated.'); return; }

    await facebook.postTextAnnouncement(postText);
    console.log('[Engagement] Engagement post published to Facebook');
    await telegram.sendTelegram(`🗣️ Engagement post published for "<b>${storyline.title}</b>"`);
  } catch (err) {
    console.error('[Engagement] Post error:', err.message);
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// Prompt builders
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Build a portrait prompt for a specific angle.
 * Uses tag-list format to maximise per-trait token weight in diffusion models.
 * Explicit resolution (1080×1920, 9:16) prevents the model from generating horizontal output.
 * @param {object} char
 * @param {string} visualAnchor - comma-separated tag-lock from generateCharacterVisualAnchor
 * @param {'front'|'three_quarter'|'profile'|'full_body'} angle
 */
function _buildCharacterPortraitPrompt(char, visualAnchor, angle = 'front') {
  const angleTag = {
    front:         'front-facing portrait, ONE person centered in frame, looking directly into camera, neutral expression',
    three_quarter: 'three-quarter angle from left, ONE person, 45-degree turn, looking slightly off-camera',
    profile:       'strict side profile from left, ONE person, head and shoulders',
    full_body:     'full body standing shot, ONE person, centered in frame, neutral pose, both hands visible',
  }[angle] || 'front-facing portrait, ONE person centered in frame';

  // Identity tags FIRST — highest token priority in diffusion models
  const anchor = visualAnchor || char.description || char.name;

  return [
    `OUTPUT FORMAT: Single photorealistic image, 1080x1920 pixels, 9:16 vertical portrait orientation, no horizontal layout, no landscape, no film strips, no multiple panels`,
    `SUBJECT: ONE PERSON ONLY — ${char.name}. Do NOT add any other person, face, or figure.`,
    anchor,
    angleTag,
    'plain dark neutral background',
    'mouth closed, natural resting expression',
    'eyes open and clearly visible',
    'hair styled exactly as described in anchor',
    'soft cinematic key light from upper-left, subtle fill from right',
    'sharp focus on eyes and face, crisp detail on hair and skin texture',
    '4K photorealistic, hyper-detailed skin, no filters',
    'no motion blur, no text, no watermarks, no background elements',
    'character identity reference sheet, casting portrait',
  ].join(', ');
}

/**
 * Normalise a character name for fuzzy matching:
 *   "Elena Vasquez"  →  "elena vasquez"
 *   "Dr. Marcus Cole" →  "marcus cole"  (strip honorifics)
 * Also returns the first-name-only variant so "Elena" matches "Elena Vasquez".
 */
function _nameTokens(raw) {
  const cleaned = (raw || '')
    .toLowerCase()
    .replace(/\b(dr|mr|mrs|ms|prof|sir|lady)\b\.?\s*/gi, '')
    .replace(/[^a-z0-9 ]/g, '')
    .trim();
  const parts = cleaned.split(/\s+/).filter(Boolean);
  // tokens: full name + each individual word so partial name matches work
  return new Set([cleaned, ...parts]);
}

/**
 * Find character DB rows whose names appear in shot.characters_in_shot.
 *
 * Rules:
 *  - If characters_in_shot is empty/absent → return all characters (shot has no restriction).
 *  - If characters_in_shot is explicitly set but nothing matches → return [] and log a warning.
 *    Never silently apply every character's identity anchor to a shot that named specific people.
 */
function _getCharsInShot(shot, characterList) {
  const scriptNames = (shot.characters_in_shot || []);
  if (!scriptNames.length) return characterList; // unspecified → include all

  const matched = [];
  const unmatched = [];

  for (const scriptName of scriptNames) {
    const scriptTokens = _nameTokens(scriptName);
    const found = characterList.find(c => {
      const dbTokens = _nameTokens(c.name);
      // Match if any token from script appears in db tokens OR vice-versa
      for (const t of scriptTokens) if (dbTokens.has(t)) return true;
      for (const t of dbTokens)    if (scriptTokens.has(t)) return true;
      return false;
    });
    if (found) {
      if (!matched.includes(found)) matched.push(found);
    } else {
      unmatched.push(scriptName);
    }
  }

  if (unmatched.length) {
    const known = characterList.map(c => c.name).join(', ');
    console.warn(
      `[CharMatch] ⚠ Shot "${shot.description?.slice(0, 60) || '?'}" lists characters not found in DB: ` +
      `[${unmatched.join(', ')}]. Known cast: [${known}]. ` +
      `Shot will use only matched characters; check LLM character name spelling.`
    );
  }

  return matched; // may be empty — caller handles gracefully via _buildShotImagePrompt
}

/**
 * Assign explicit spatial positions to characters in a shot.
 * This is CRITICAL for preventing the model from merging two characters into one hybrid person.
 * The position label is embedded directly in the anchor block so the model gets spatial separation.
 */
function _assignCharacterPositions(chars) {
  if (!chars || chars.length <= 1) return chars.map(() => null);
  if (chars.length === 2) return ['on the LEFT side of frame', 'on the RIGHT side of frame'];
  if (chars.length === 3) return ['on the FAR LEFT of frame', 'in the CENTER of frame', 'on the FAR RIGHT of frame'];
  // 4+ characters
  return chars.map((_, i) => {
    const pct = i / (chars.length - 1);
    if (pct < 0.25)  return 'on the FAR LEFT of frame';
    if (pct < 0.5)   return 'LEFT OF CENTER in frame';
    if (pct < 0.75)  return 'RIGHT OF CENTER in frame';
    return 'on the FAR RIGHT of frame';
  });
}

/**
 * Strip any embedded identity-lock blocks the LLM may have written into image_prompt.
 * The LLM sometimes embeds "[NAME IDENTITY LOCK: ...]" or similar despite instructions.
 * We inject anchors ourselves — duplicates cause conflicting signals and token dilution.
 */
function _stripEmbeddedAnchors(imagePrompt) {
  if (!imagePrompt) return '';
  return imagePrompt
    // "[Name IDENTITY LOCK: ...]" style blocks
    .replace(/\[[^\]]{0,60}IDENTITY LOCK[^\]]*\]/gi, '')
    // "Character: <long physical description>," patterns
    .replace(/character\s*:\s*[^,\n]{20,}/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

/**
 * Build the full image prompt for a shot.
 *
 * Resolution + orientation directives come first so they receive maximum token weight.
 * Character visual anchors are next, each tagged with an explicit spatial position
 * (left / right / center) to prevent the model from merging two characters into one.
 * Scene-level context (location, lighting, emotional beat) and the previous shot's
 * description are injected so consecutive shots read as part of the same story and
 * environment instead of disconnected abstract images.
 * The LLM-generated image_prompt covers only cinematographic elements.
 *
 * @param {object}      shot            Current shot from the script
 * @param {object}      storyline       Active storyline (genre, visual language, etc.)
 * @param {object[]}    charsInShot     Matched character DB rows
 * @param {object|null} prevShot        Previous shot in allShots (null for first shot)
 * @param {string|null} sceneBgImageUrl Cloudinary URL of the first shot in this scene,
 *                                      used as a visual background reference (non-null for
 *                                      shots 2+ in a scene)
 */
function _buildShotImagePrompt(shot, storyline, charsInShot, prevShot = null, sceneBgImageUrl = null) {
  const genreAesthetic = {
    romcom:   'warm golden-hour romantic cinematography, soft foreground bokeh',
    thriller: 'dark noir, high-contrast, hard shadows, desaturated palette',
    'sci-fi': 'futuristic cinematic, volumetric neon light, atmospheric fog',
    drama:    'prestige drama, naturalistic window light, shallow depth of field',
  };
  const aesthetic = genreAesthetic[storyline.genre] || 'cinematic, photorealistic';

  // Assign spatial positions BEFORE building anchor block
  const positions = _assignCharacterPositions(charsInShot);

  // Identity anchors FIRST — gives each character's traits maximum token weight.
  // Positions are embedded to prevent character merging.
  const anchored = charsInShot.filter(c => c.visual_anchor);
  const anchorBlock = anchored.length > 0
    ? anchored
        .map((c, i) => {
          const pos = positions[i] ? `, ${positions[i]}` : '';
          return `[CHARACTER ${c.name.toUpperCase()}${pos}: ${c.visual_anchor}]`;
        })
        .join('\n')
    : '';

  // For multi-character shots add an explicit spatial separation directive
  const separationDirective = anchored.length >= 2
    ? `CRITICAL SPATIAL RULE: Each character listed above MUST appear as a COMPLETELY SEPARATE and DISTINCT person. ` +
      `They are positioned at different locations in the frame as noted. ` +
      `Do NOT merge, blend, or morph their faces or bodies. ` +
      `Each character has a different face, hairstyle, skin tone, and build — keep them entirely separate.`
    : '';

  // ── Scene-level context ────────────────────────────────────────────────────
  // Grounding the image model in the scene's location, lighting design, and
  // emotional beat prevents it from inventing a random background that looks
  // nothing like the adjacent shots.
  const sceneContextParts = [
    shot._scene_location    ? `SET/LOCATION: ${shot._scene_location}`       : '',
    shot._scene_description ? `SCENE ACTION: ${shot._scene_description}`    : '',
    shot._lighting_design   ? `LIGHTING: ${shot._lighting_design}`          : '',
    shot._scene_emotion     ? `EMOTIONAL TONE: ${shot._scene_emotion}`      : '',
    shot._camera_language   ? `CAMERA LANGUAGE: ${shot._camera_language}`   : '',
  ].filter(Boolean);
  const sceneContextBlock = sceneContextParts.length
    ? `SCENE CONTEXT (match this environment exactly):\n${sceneContextParts.join('\n')}`
    : '';

  // ── Episode-level narrative thread ────────────────────────────────────────
  // Giving the image model the episode title and one-line logline grounds every
  // shot in the same story and prevents stylistic drift across a 30-shot episode.
  const episodeNarrative = [
    shot._episode_title   ? `EPISODE: "${shot._episode_title}"`          : '',
    shot._episode_logline ? `STORY THREAD: ${shot._episode_logline}`     : '',
  ].filter(Boolean).join('\n');
  const episodeBlock = episodeNarrative
    ? `NARRATIVE CONTEXT (apply to every artistic choice):\n${episodeNarrative}`
    : '';

  // ── Previous-shot continuity ───────────────────────────────────────────────
  // The model gets a plain-language description of what was just shown so it
  // knows the spatial environment it is "cutting" from, producing coherent
  // scene geography instead of abstract disconnected frames.
  let continuityBlock = '';
  if (prevShot) {
    const prevDesc    = (prevShot.shot_description || '').slice(0, 220);
    const prevType    = prevShot.shot_type ? `${prevShot.shot_type} shot` : '';
    const prevLoc     = prevShot._scene_location || '';
    const sameScene   = prevShot.scene_number === shot.scene_number;

    const continuityParts = [prevType, prevDesc].filter(Boolean).join(' — ');
    const locationNote = sameScene
      ? `SAME SCENE — maintain identical environment, lighting conditions, and spatial layout.`
      : prevLoc
        ? `Scene change from: ${prevLoc}. New environment is described above.`
        : `Scene change — new environment described above.`;

    continuityBlock =
      `NARRATIVE CONTINUITY — previous shot was: ${continuityParts}\n${locationNote}`;
  }

  // ── Scene background reference lock ──────────────────────────────────────
  // When a background reference image is provided (the first shot's static frame
  // for this scene), emit a directive telling the model to reproduce that
  // environment exactly.  The reference image is passed as input_image_0 in the
  // CF Worker call, so this block anchors what to do with it.
  const sceneBgBlock = sceneBgImageUrl
    ? `SCENE BACKGROUND REFERENCE (first reference image provided):\n` +
      `The first reference image is the ESTABLISHED BACKGROUND for this scene — ` +
      `its location, architecture, props, furniture, and lighting are LOCKED for every shot in this scene.\n` +
      `REPRODUCE that environment exactly: same walls/floors/outdoor space, same practical light sources, ` +
      `same colour temperature, same depth and spatial layout.\n` +
      `DO NOT invent a new background. DO NOT copy characters or people from the reference — ` +
      `only the environment and lighting conditions should be matched.`
    : '';

  // Strip any identity descriptions the LLM may have embedded in the shot prompt
  const cleanedShotPrompt = _stripEmbeddedAnchors(shot.image_prompt);

  return [
    'IMAGE FORMAT: 1080x1920 pixels, 9:16 vertical portrait orientation. Single frame, no panels, no film strips, no horizontal layout.',
    episodeBlock,
    sceneBgBlock,
    anchorBlock,
    separationDirective,
    sceneContextBlock,
    continuityBlock,
    cleanedShotPrompt,
    aesthetic,
    '9:16 vertical, 4K photorealistic, cinematic colour grade, no text overlays',
  ].filter(Boolean).join('\n');
}

/**
 * Build a negative prompt to suppress the most common character consistency failures.
 * Includes anti-merge/anti-blend terms for multi-character shots.
 * Works with CF Workers that support `negative_prompt`; silently ignored by others.
 */
function _buildCharacterNegativePrompt(charsInShot) {
  const base = [
    'different hair color, different hair style, different eye color, different skin tone',
    'changed facial structure, different person, inconsistent character appearance',
    'character redesign, different race, different ethnicity, aging, different age',
    'plastic smooth AI skin, overly soft features, generic face, stock photo face',
    'flat lighting, blown highlights, text, watermark, logo, signature',
    'horizontal image, landscape orientation, wide aspect ratio, film strip, multiple panels',
  ];

  // Extra anti-blend terms for multi-character shots
  if (charsInShot.length >= 2) {
    base.push(
      'merged faces, blended features, hybrid face, morphed characters',
      'characters bleeding into each other, shared body parts, fused bodies',
      'two faces in one head, chimera, composite face, overlapping characters',
      'wrong character on wrong side, characters in wrong positions'
    );
  }

  return base.join(', ');
}

/**
 * Collect all reference portrait URLs for a list of characters.
 * Prefers the multi-angle JSON array (reference_image_urls) and falls back to the
 * single reference_image_url for backwards compatibility.
 */
function _collectReferenceUrls(charsInShot) {
  return charsInShot.flatMap(c => {
    try {
      const multi = JSON.parse(c.reference_image_urls || '[]');
      if (Array.isArray(multi) && multi.length) return multi;
    } catch {}
    return c.reference_image_url ? [c.reference_image_url] : [];
  }).filter(Boolean);
}

function _pickRandomGenre() {
  const pool = config.genrePool;
  return pool[Math.floor(Math.random() * pool.length)];
}

/**
 * Derive a deterministic 32-bit integer seed from a character's UUID.
 * The same character always gets the same seed, so CF Worker produces
 * visually consistent outputs across every shot they appear in.
 */
function _charSeed(charId) {
  const hex = (charId || '').replace(/-/g, '').slice(0, 8);
  return (parseInt(hex, 16) || 0x00ABCDEF) >>> 0; // unsigned 32-bit
}

/**
 * Return the seed for a shot based on the primary (first) character.
 *
 * XOR-combining all character seeds was the old approach — it produced a seed
 * that represented neither character, destroying identity consistency for everyone
 * in a multi-character shot.  Using the primary character's seed means at least
 * the protagonist is anchor-consistent; secondary characters rely on their text
 * anchor tags for identity, which is the strongest lever CF Worker AI provides.
 */
function _combinedSeed(chars) {
  if (!chars || !chars.length) return null;
  return _charSeed(chars[0].id) || null;
}

module.exports = { runStreamVersePipeline, runReelsPipeline, runCommentReminder, runAutoCommentReplies, runEngagementPost, getDraftEpisodeAny };
