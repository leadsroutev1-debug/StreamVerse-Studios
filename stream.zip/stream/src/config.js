'use strict';
require('dotenv').config();

function parseKeyPool(envVar) {
  const val = process.env[envVar] || '';
  return val.split(',').map(k => k.trim()).filter(Boolean);
}

function requireEnv(key) {
  const v = process.env[key];
  if (!v) console.warn(`[Config] WARNING: env var ${key} is not set`);
  return v || '';
}

// ──────────────────────────────────────────────────────────────────────────────
// MySQL — accept either DATABASE_URL or individual credentials
// mysql://user:pass@host:3306/dbname[?ssl-params]
// ──────────────────────────────────────────────────────────────────────────────

/** Returns true for any of the common TLS flag forms used by cloud MySQL providers */
function _needsSsl(params) {
  return (
    params.get('ssl')      === 'true'    ||
    params.get('tls')      === 'true'    ||
    // ?ssl-mode=REQUIRED  (Aiven, PlanetScale style)
    (params.get('ssl-mode')  || '').toUpperCase() === 'REQUIRED' ||
    // ?sslmode=require    (libpq / Heroku style)
    (params.get('sslmode')   || '').toLowerCase().startsWith('req')
  );
}

function buildDbConfig() {
  const url = process.env.DATABASE_URL || process.env.MYSQL_URL || '';
  if (url) {
    try {
      const u = new URL(url);
      return {
        host:     u.hostname,
        port:     parseInt(u.port || '3306', 10),
        user:     decodeURIComponent(u.username),
        password: decodeURIComponent(u.password),
        database: u.pathname.replace(/^\//, ''),
        waitForConnections: true,
        connectionLimit:    5,
        queueLimit:         0,
        // Honor TLS params in any of the common forms:
        //   ?ssl=true  ?ssl-mode=REQUIRED  ?sslmode=require  ?tls=true
        ...(_needsSsl(u.searchParams) ? { ssl: { rejectUnauthorized: false } } : {}),
      };
    } catch (e) {
      console.warn('[Config] DATABASE_URL parse failed, falling back to individual vars:', e.message);
    }
  }
  // Individual credential fallback
  return {
    host:     requireEnv('MYSQL_HOST'),
    port:     parseInt(process.env.MYSQL_PORT || '3306', 10),
    user:     requireEnv('MYSQL_USER'),
    password: requireEnv('MYSQL_PASSWORD'),
    database: requireEnv('MYSQL_DATABASE'),
    waitForConnections: true,
    connectionLimit:    5,
    queueLimit:         0,
  };
}

const config = {
  db: buildDbConfig(),

  // ── LLM key pools ──────────────────────────────────────────────────────────
  mistralKeys:  parseKeyPool('MISTRAL_KEYS'),
  groqKeys:     parseKeyPool('GROQ_KEYS'),

  // ── Deepgram TTS — comma-separated keys, rotated on quota exhaustion ──────
  // Note: env var is DEEPGRAK_KEYS (intentional spelling from project setup)
  deepgramKeys: parseKeyPool('DEEPGRAK_KEYS'),

  // ── Google Generative AI (Gemini image generation) — primary image backend
  googleKeys: parseKeyPool('GOOGLE_KEYS'),

  // ── ScrapingBee — rotating residential proxy for Google AI when Replit's IP is blocked
  scrapingBeeKeys: parseKeyPool('SCRAPINGBEE_KEYS'),

  // ── Cloudflare Worker AI ──────────────────────────────────────────────────
  // CF_WORKER_URL is comma-separated; each entry is a separate worker deployment.
  // Rotated on quota exhaustion (4006) so a fresh worker continues work.
  cfWorkerUrls: parseKeyPool('CF_WORKER_URL'),
  cfWorkerKeys: parseKeyPool('CF_WORKER_KEYS'),

  // ── Magic Hour ────────────────────────────────────────────────────────────
  magicHourKeys:            parseKeyPool('MAGIC_HOUR_KEYS'),
  magicHourPollIntervalMs:  parseInt(process.env.MH_POLL_INTERVAL_MS  || '15000', 10),
  magicHourMaxPollAttempts: parseInt(process.env.MH_MAX_POLL_ATTEMPTS || '60',    10),

  // ── FFmpeg microservice ───────────────────────────────────────────────────
  ffmpegServiceUrl:       requireEnv('FFMPEG_SERVICE_URL'),
  ffmpegApiKey:           requireEnv('FFMPEG_API_KEY'),
  ffmpegPollIntervalMs:   parseInt(process.env.FFMPEG_POLL_INTERVAL_MS  || '10000', 10),
  ffmpegMaxPollAttempts:  parseInt(process.env.FFMPEG_MAX_POLL_ATTEMPTS || '120',   10),

  // ── Cloudinary ────────────────────────────────────────────────────────────
  cloudinaryCloudName:    requireEnv('CLOUDINARY_CLOUD_NAME'),
  cloudinaryApiKey:       requireEnv('CLOUDINARY_API_KEY'),
  cloudinaryApiSecret:    requireEnv('CLOUDINARY_API_SECRET'),
  cloudinaryUploadPreset: requireEnv('CLOUDINARY_UPLOAD_PRESET'),
  shotsFolderRoot:        process.env.CLOUDINARY_SHOTS_ROOT    || 'streamverse/shots',
  episodeFolderRoot:      process.env.CLOUDINARY_EPISODES_ROOT || 'streamverse/episodes',
  charRefFolderRoot:      process.env.CLOUDINARY_CHARS_ROOT    || 'streamverse/characters',

  // ── Telegram ──────────────────────────────────────────────────────────────
  telegramBotToken: requireEnv('TELEGRAM_BOT_TOKEN'),
  telegramChatId:   requireEnv('TELEGRAM_CHAT_ID'),

  // ── Facebook ──────────────────────────────────────────────────────────────
  facebookPageId:           requireEnv('FACEBOOK_PAGE_ID'),
  facebookPageAccessToken:  requireEnv('FACEBOOK_PAGE_ACCESS_TOKEN'),
  facebookAppId:            process.env.FACEBOOK_APP_ID     || '',
  facebookAppSecret:        process.env.FACEBOOK_APP_SECRET || '',
  facebookGraphVersion:     process.env.FACEBOOK_GRAPH_VERSION || 'v20.0',

  // ── Content pipeline ──────────────────────────────────────────────────────
  genrePool:               (process.env.GENRE_POOL || 'romcom,thriller,sci-fi,drama').split(',').map(g => g.trim()),
  shotsPerScene:           parseInt(process.env.SHOTS_PER_SCENE    || '3', 10),
  scenesPerEpisode:        parseInt(process.env.SCENES_PER_EPISODE || '5', 10),
  targetEpisodeMinSeconds: parseInt(process.env.TARGET_MIN_SECONDS || '300', 10),
  movieMinSeconds:         parseInt(process.env.MOVIE_MIN_SECONDS  || '1200', 10),

  // ── Season/episode logic ──────────────────────────────────────────────────
  episodesPerSeason: parseInt(process.env.EPISODES_PER_SEASON || '20', 10),
  seasonsPerSeries:  parseInt(process.env.SEASONS_PER_SERIES  || '4',  10),

  // ── Shot retry & abort guard ──────────────────────────────────────────────
  shotMaxRetries:    parseInt(process.env.SHOT_MAX_RETRIES    || '3',  10),
  shotFailAbortPct:  parseFloat(process.env.SHOT_FAIL_ABORT_PCT || '0.5'), // abort if >50% fail

  // ── Character consistency ─────────────────────────────────────────────────
  // Number of reference portrait images to generate per character (1 = one canonical look)
  charRefImageCount: parseInt(process.env.CHAR_REF_IMAGE_COUNT || '1', 10),

  // ── App ───────────────────────────────────────────────────────────────────
  port:          parseInt(process.env.PORT || '5000', 10),
  sessionSecret: process.env.SESSION_SECRET || 'sv-secret',
};

// ── Key rotation ──────────────────────────────────────────────────────────────
const _keyIndexes = {};
function getNextKey(pool, poolName) {
  if (!pool || pool.length === 0) throw new Error(`No keys configured for pool: ${poolName}`);
  const idx = (_keyIndexes[poolName] || 0) % pool.length;
  _keyIndexes[poolName] = idx + 1;
  return pool[idx];
}

config.getNextMistralKey      = () => getNextKey(config.mistralKeys,     'mistral');
config.getNextGroqKey         = () => getNextKey(config.groqKeys,        'groq');
config.getNextDeepgramKey     = () => getNextKey(config.deepgramKeys,    'deepgram');
config.getNextCfKey           = () => getNextKey(config.cfWorkerKeys,    'cf');
config.getNextCfUrl           = () => getNextKey(config.cfWorkerUrls,    'cfurl');
config.getNextGoogleKey       = () => getNextKey(config.googleKeys,      'google');
config.getNextScrapingBeeKey  = () => getNextKey(config.scrapingBeeKeys, 'scrapingbee');
config.getNextMagicHourKey = (offset = 0) => {
  const pool = config.magicHourKeys;
  if (!pool || pool.length === 0) throw new Error('No Magic Hour keys configured');
  const idx = ((_keyIndexes['magichour'] || 0) + offset) % pool.length;
  _keyIndexes['magichour'] = idx + 1;
  return pool[idx];
};

// Live token accessor (allows runtime refresh without restart)
let _fbToken = config.facebookPageAccessToken;
config.getFbToken    = ()    => _fbToken;
config.setFbToken    = (tok) => { _fbToken = tok; };

// ── Key health tracking for dashboard ────────────────────────────────────────
function maskKey(k) {
  if (!k || k.length < 8) return '***';
  return k.slice(0, 4) + '...' + k.slice(-4);
}

/** Shorten a CF Worker URL to just its hostname for display. */
function maskUrl(url) {
  try {
    const hostname = new URL(url).hostname;
    return hostname.length > 22 ? hostname.slice(0, 19) + '…' : hostname;
  } catch { return String(url).slice(0, 22); }
}

config.keyHealth = {
  google:      config.googleKeys.map(k       => ({ label: maskKey(k), status: 'active' })),
  mistral:     config.mistralKeys.map(k      => ({ label: maskKey(k), status: 'active' })),
  groq:        config.groqKeys.map(k         => ({ label: maskKey(k), status: 'active' })),
  deepgram:    config.deepgramKeys.map(k     => ({ label: maskKey(k), status: 'active' })),
  magicHour:   config.magicHourKeys.map(k    => ({ label: maskKey(k), status: 'active' })),
  scrapingBee: config.scrapingBeeKeys.map(k  => ({ label: maskKey(k), status: 'active' })),
  cfurl:       config.cfWorkerUrls.map(u     => ({ label: maskUrl(u),  status: 'active' })),
  facebook:    [{ label: 'Page Token', status: _fbToken ? 'active' : 'missing' }],
};

config.markKeyStatus = (pool, key, status) => {
  const label = pool === 'cfurl' ? maskUrl(key) : maskKey(key);
  const entry = config.keyHealth[pool]?.find(e => e.label === label);
  if (entry) entry.status = status;
};

config.setFbTokenStatus = (status) => {
  if (config.keyHealth.facebook?.[0]) config.keyHealth.facebook[0].status = status;
};

module.exports = config;
