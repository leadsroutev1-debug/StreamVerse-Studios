'use strict';
const axios = require('axios');
const config = require('./config');

function _ffmpegHeaders() {
  return {
    'x-api-key':    config.ffmpegApiKey,
    'Content-Type': 'application/json',
  };
}

/**
 * Wake up the Render FFmpeg service (anti-cold-start ping).
 */
async function wakeFFmpeg() {
  try {
    await axios.get(config.ffmpegServiceUrl + '/health', {
      headers: _ffmpegHeaders(),
      timeout: 30000,
    });
    console.log('[Compiler] FFmpeg service awake.');
  } catch (err) {
    console.warn('[Compiler] Wake ping failed (service may still be starting):', err.message);
  }
}

// Valid layout values accepted by the FFmpeg /compose service.
// The script writer may emit legacy transition names (dissolve, fade) that are
// not recognised by the service.  Map them to the nearest supported layout so
// scene composition never fails due to an unknown layout string.
const VALID_LAYOUTS = new Set(['cut', 'overlay', 'split', 'zoom']);
const LAYOUT_FALLBACK_MAP = {
  dissolve: 'cut',
  fade:     'cut',
  crossfade:'cut',
  wipe:     'cut',
};

function resolveLayout(raw) {
  if (!raw) return 'cut';
  const lower = String(raw).toLowerCase();
  if (VALID_LAYOUTS.has(lower)) return lower;
  const mapped = LAYOUT_FALLBACK_MAP[lower];
  if (mapped) {
    console.log(`[Compiler] Layout "${raw}" mapped to "${mapped}" (unsupported by FFmpeg service)`);
    return mapped;
  }
  console.warn(`[Compiler] Unknown layout "${raw}" — defaulting to "cut"`);
  return 'cut';
}

/**
 * Submit a scene composition job to the FFmpeg microservice.
 * clips: ordered array of clip entries — either plain URL strings (legacy)
 *        or { url, clipDuration } objects (pacing-aware).
 *        The FFmpeg service /compose route expects plain URL strings, so we
 *        extract .url from objects here.
 * Returns jobId.
 */
async function composeScene(clips, composition = 'cut') {
  // FFmpeg service /compose expects plain URL strings, not objects.
  const clipUrls = (clips || []).map(c => {
    if (typeof c === 'string') return c;
    return c.url;
  }).filter(Boolean);

  // Normalise composition to a layout value the FFmpeg service understands.
  const layout = resolveLayout(composition);

  const resp = await axios.post(
    config.ffmpegServiceUrl + '/compose',
    { clips: clipUrls, layout },   // ← layout (not transition), plain URLs
    { headers: _ffmpegHeaders(), timeout: 30000 }
  );
  if (!resp.data?.jobId) {
    throw new Error(`[Compiler] /compose bad response: ${JSON.stringify(resp.data)}`);
  }
  return resp.data.jobId;
}

/**
 * Submit a final episode merge job to the FFmpeg microservice.
 * sceneUrls: ordered array of scene video URLs.
 * introBumperUrl / outroBumperUrl: optional StreamVerse Studio bumpers.
 * Returns jobId.
 */
async function mergeScenes(sceneUrls, { introBumperUrl, outroBumperUrl } = {}) {
  const clips = [
    ...(introBumperUrl ? [introBumperUrl] : []),
    ...sceneUrls,
    ...(outroBumperUrl ? [outroBumperUrl] : []),
  ];
  const resp = await axios.post(
    config.ffmpegServiceUrl + '/merge',
    { clips },
    { headers: _ffmpegHeaders(), timeout: 30000 }
  );
  if (!resp.data?.jobId) {
    throw new Error(`[Compiler] /merge bad response: ${JSON.stringify(resp.data)}`);
  }
  return resp.data.jobId;
}

/**
 * Poll an FFmpeg job until it returns a download URL.
 * Uses /status/:id — the single-job status endpoint on the FFmpeg service.
 * Returns the final video URL on success.
 */
async function pollFFmpegJob(jobId) {
  const maxAttempts = config.ffmpegMaxPollAttempts;
  const intervalMs  = config.ffmpegPollIntervalMs;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    await sleep(intervalMs);
    const resp = await axios.get(
      `${config.ffmpegServiceUrl}/status/${jobId}`,   // ← /status/:id (not /jobs/:id)
      { headers: _ffmpegHeaders(), timeout: 20000 }
    );
    const job = resp.data;
    if (job.status === 'complete' || job.status === 'done') {
      const url = job.url || job.output_url || job.download_url;
      if (!url) throw new Error(`[Compiler] FFmpeg job complete but no URL: ${JSON.stringify(job)}`);
      return url;
    }
    if (['error', 'failed'].includes(job.status)) {
      throw new Error(`[Compiler] FFmpeg job ${jobId} failed: ${job.error || JSON.stringify(job)}`);
    }
    console.log(`[Compiler] FFmpeg job ${jobId} status=${job.status} (${attempt}/${maxAttempts})`);
  }
  throw new Error(`[Compiler] FFmpeg job ${jobId} timed out after ${maxAttempts} attempts`);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { wakeFFmpeg, composeScene, mergeScenes, pollFFmpegJob };
