#!/bin/bash
# Production startup — runs both the backend engine (port 3001) and
# the compiled Next.js frontend (port 5000) together.
set -e

echo "[start.sh] Starting StreamVerse backend (port 3001)..."
PORT=3001 node index.js &
BACKEND_PID=$!

echo "[start.sh] Building Next.js frontend..."
cd frontend
npm run build

echo "[start.sh] Starting Next.js frontend (port 5000)..."
npm start &
FRONTEND_PID=$!

# Propagate the first exit
wait -n $BACKEND_PID $FRONTEND_PID
EXIT_CODE=$?
echo "[start.sh] A process exited (code $EXIT_CODE). Shutting down..."
kill $BACKEND_PID $FRONTEND_PID 2>/dev/null || true
exit $EXIT_CODE
