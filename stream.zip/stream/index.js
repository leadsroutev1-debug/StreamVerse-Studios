'use strict';
require('dotenv').config();

const express  = require('express');
const cron     = require('node-cron');
const path     = require('path');
const axios    = require('axios');

const config          = require('./src/config');
const db              = require('./src/db');
const state           = require('./src/state');
const pipeline        = require('./src/pipeline');
const imageGen        = require('./src/imageGen');
const googleImageGen  = require('./src/googleImageGen');
const cloudinaryLib   = require('./src/cloudinary');
const scriptWriter    = require('./src/scriptWriter');
const telegramLib     = require('./src/telegram');
const streamGateway   = require('./src/streamGateway');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Global CORS — all /api/ routes are accessible from any external frontend ──
app.use('/api/', (req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Internal-Pipeline, Range');
  res.setHeader('Access-Control-Expose-Headers','Content-Range, Content-Length, Accept-Ranges');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// ──────────────────────────────────────────────────────────────────────────────
// Dashboard
// ──────────────────────────────────────────────────────────────────────────────

app.get('/',          (req, res) => res.redirect('/dashboard'));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'views', 'dashboard.html')));

// ──────────────────────────────────────────────────────────────────────────────
// REST status snapshot
// ──────────────────────────────────────────────────────────────────────────────

app.get('/api/status', (req, res) => {
  const s = state.getState();
  s.keyHealth = config.keyHealth;
  res.json(s);
});

// ──────────────────────────────────────────────────────────────────────────────
// History — always reads from DB, not memory
// ──────────────────────────────────────────────────────────────────────────────

app.get('/api/history', async (req, res) => {
  try {
    const rows = await db.query(
      `SELECT e.id, e.episode_number, e.season_number, e.script, e.video_url,
              e.facebook_video_link, e.posted_at,
              s.title AS show_title, s.genre, s.current_season,
              s.episode_count, s.status AS show_status
       FROM episodes e
       JOIN storylines s ON e.storyline_id = s.id
       WHERE e.status = 'posted'
       ORDER BY e.posted_at DESC
       LIMIT 10`
    );
    const history = rows.map(r => {
      const sc = JSON.parse(r.script || '{}');
      return {
        id:            r.id,
        title:         `${r.show_title} S${r.season_number}E${r.episode_number}`,
        episodeTitle:  sc.episode_title || '',
        showTitle:     r.show_title     || '',
        cloudinaryUrl: r.video_url      || '',
        facebookLink:  r.facebook_video_link || '',
        postedAt:      r.posted_at ? (r.posted_at.toISOString?.() || String(r.posted_at)) : '',
        genre:         r.genre,
        synopsis:      sc.synopsis      || sc.logline || '',
        scenes:        Array.isArray(sc.scenes) ? sc.scenes.length : 0,
      };
    });

    // Active storylines summary
    const activeShows = await db.query(
      `SELECT id, title, genre, current_season, current_episode, episode_count, status
       FROM storylines ORDER BY updated_at DESC LIMIT 5`
    );

    res.json({ ok: true, history, activeShows });
  } catch (err) {
    console.error('[API /history]', err.message);
    res.json({ ok: false, error: err.message, history: [], activeShows: [] });
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// SSE — real-time push to dashboard
// ──────────────────────────────────────────────────────────────────────────────

const sseClients = new Set();

app.get('/api/sse', (req, res) => {
  res.setHeader('Content-Type',      'text/event-stream');
  res.setHeader('Cache-Control',     'no-cache');
  res.setHeader('Connection',        'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const snap = state.getState();
  snap.keyHealth = config.keyHealth;
  res.write(`event: state\ndata: ${JSON.stringify(snap)}\n\n`);

  sseClients.add(res);
  req.on('close', () => sseClients.delete(res));
});

state.emitter.on('update', (s) => {
  s.keyHealth = config.keyHealth;
  const msg = `event: state\ndata: ${JSON.stringify(s)}\n\n`;
  for (const c of sseClients) { try { c.write(msg); } catch {} }
});

setInterval(() => {
  for (const c of sseClients) { try { c.write(': heartbeat\n\n'); } catch {} }
}, 25000);

// ──────────────────────────────────────────────────────────────────────────────
// Trigger endpoints
// ──────────────────────────────────────────────────────────────────────────────

app.post('/api/trigger', (req, res) => {
  const s = state.getState();
  if (s.status !== state.STATES.IDLE && s.status !== state.STATES.ERROR && s.status !== state.STATES.PAUSED) {
    return res.json({ ok: false, error: 'Pipeline already running' });
  }
  pipeline.runStreamVersePipeline().catch(err =>
    console.error('[API] Manual trigger error:', err.message)
  );
  res.json({ ok: true, message: 'Pipeline started' });
});

// ──────────────────────────────────────────────────────────────────────────────
// Resume — explicit alias; trigger already handles PAUSED but this is clearer
// ──────────────────────────────────────────────────────────────────────────────

app.post('/api/resume', (req, res) => {
  const s = state.getState();
  if (s.status !== state.STATES.IDLE && s.status !== state.STATES.ERROR && s.status !== state.STATES.PAUSED) {
    return res.json({ ok: false, error: 'Pipeline already running' });
  }
  pipeline.runStreamVersePipeline().catch(err =>
    console.error('[API] Resume error:', err.message)
  );
  res.json({ ok: true, message: 'Resume triggered' });
});

// ──────────────────────────────────────────────────────────────────────────────
// Drafts — list paused/partial episodes from DB
// ──────────────────────────────────────────────────────────────────────────────

app.get('/api/drafts', async (req, res) => {
  try {
    const rows = await db.query(
      `SELECT e.id, e.episode_number, e.season_number, e.paused_reason, e.created_at,
              e.scene_state, e.scene_count, e.shot_count,
              s.title AS show_title, s.genre
       FROM episodes e
       JOIN storylines s ON e.storyline_id = s.id
       WHERE e.status = 'draft'
       ORDER BY e.created_at DESC`
    );

    // Count done shots per draft from the shots table (the new system)
    // in one query, then join in JS.
    const draftIds = rows.map(r => r.id);
    let shotCountMap = {};
    if (draftIds.length) {
      const placeholders = draftIds.map(() => '?').join(',');
      const shotCounts = await db.query(
        `SELECT episode_id, COUNT(*) AS done_count
         FROM shots WHERE episode_id IN (${placeholders}) AND status = 'done'
         GROUP BY episode_id`,
        draftIds
      );
      for (const sc of shotCounts) shotCountMap[sc.episode_id] = sc.done_count;
    }

    const drafts = rows.map(r => {
      let sceneState = {};
      try { sceneState = JSON.parse(r.scene_state || '{}'); } catch {}
      return {
        id:             r.id,
        title:          `${r.show_title} S${r.season_number}E${r.episode_number}`,
        showTitle:      r.show_title,
        genre:          r.genre,
        pausedReason:   r.paused_reason || null,
        shotsGenerated: shotCountMap[r.id] || 0,
        shotsTotal:     r.shot_count || 0,
        scenesCompiled: Object.keys(sceneState).length,
        scenesTotal:    r.scene_count || 0,
        createdAt:      r.created_at ? (r.created_at.toISOString?.() || String(r.created_at)) : '',
      };
    });
    res.json({ ok: true, drafts });
  } catch (err) {
    console.error('[API /drafts]', err.message);
    res.json({ ok: false, error: err.message, drafts: [] });
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// Rendered shots — completed shot clips for the current draft, grouped by scene
// ──────────────────────────────────────────────────────────────────────────────

app.get('/api/drafts/shots', async (req, res) => {
  try {
    const draft = await db.queryOne(
      `SELECT e.id, e.episode_number, e.season_number, e.scene_state,
              s.title AS show_title, s.genre
       FROM episodes e
       JOIN storylines s ON e.storyline_id = s.id
       WHERE e.status = 'draft'
       ORDER BY e.created_at DESC LIMIT 1`
    );
    if (!draft) return res.json({ ok: true, scenes: [], episode: null });

    const shots = await db.query(
      `SELECT scene_number, shot_index, clip_url, clip_duration
       FROM shots
       WHERE episode_id = ? AND status = 'done'
       ORDER BY scene_number, shot_index`,
      [draft.id]
    );

    // Group shots by scene
    const sceneMap = new Map();
    for (const shot of shots) {
      if (!sceneMap.has(shot.scene_number)) sceneMap.set(shot.scene_number, []);
      sceneMap.get(shot.scene_number).push({
        shotIndex:    shot.shot_index,
        clipUrl:      shot.clip_url,
        clipDuration: shot.clip_duration,
      });
    }

    // Include compiled scene URLs from scene_state JSON if available
    let compiledScenes = {};
    try { compiledScenes = JSON.parse(draft.scene_state || '{}'); } catch {}

    const scenes = [...sceneMap.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([sceneNumber, sceneShots]) => ({
        sceneNumber,
        shots:       sceneShots,
        compiledUrl: compiledScenes[sceneNumber] || null,
      }));

    res.json({
      ok: true,
      scenes,
      episode: {
        id:    draft.id,
        title: `${draft.show_title} S${draft.season_number}E${draft.episode_number}`,
        genre: draft.genre,
      },
    });
  } catch (err) {
    console.error('[API /drafts/shots]', err.message);
    res.json({ ok: false, error: err.message, scenes: [] });
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// Test APIs — run all external service checks; streams results via SSE apiTest
// ──────────────────────────────────────────────────────────────────────────────

app.post('/api/test-apis', (req, res) => {
  const s = state.getState();
  if (s.apiTest?.running) return res.json({ ok: false, error: 'Tests already running' });
  _runApiTests().catch(err => console.error('[TestAPIs]', err.message));
  res.json({ ok: true, message: 'API tests started — watch SSE stream for results' });
});

async function _runApiTests() {
  const startedAt = new Date().toISOString();
  const results   = [];
  state.setApiTest({ running: true, results: [], startedAt });

  function push(name, status, message, latencyMs, extra = {}) {
    results.push({ name, status, message, latencyMs, ...extra });
    state.setApiTest({ running: true, results: [...results], startedAt });
    console.log(`[TestAPIs] ${name}: ${status} — ${message} (${latencyMs}ms)`);
  }

  // ── Helper: timed test wrapper ────────────────────────────────────────────
  async function timed(name, fn) {
    const t = Date.now();
    try {
      const extra = await fn();
      push(name, 'ok', 'OK', Date.now() - t, extra || {});
    } catch (err) {
      push(name, 'fail', err.message.slice(0, 200), Date.now() - t);
    }
  }

  // ── Run parallel tests ────────────────────────────────────────────────────
  let cfImageUrl         = null; // used by Magic Hour test if Google upload fails
  let _googleTestImageUrl = null; // 1080×1920 Google image uploaded to Cloudinary for MH test
  let _testImageUrl      = null; // source image shown in dashboard media section

  await Promise.all([

    // Google Image Gen — calls googleImageGen directly (bypasses the router so a CF fallback
    // failure doesn't mask the real Google error).  Generates a cinematic 1080×1920 shot that
    // is then used as the Magic Hour video test source (ensures the test is vertical + high-res).
    timed('Google Image Gen', async () => {
      if (!config.googleKeys.length) throw new Error('No Google keys configured (GOOGLE_KEYS)');
      const buf = await googleImageGen.generateImage(
        'Cinematic aerial shot of a glowing futuristic city skyline at night, neon-lit streets ' +
        'reflecting on rain-soaked roads, dramatic atmospheric lighting, ultra-detailed, ' +
        'photorealistic, sharp focus, 8K quality, 9:16 vertical portrait orientation',
        [],   // no reference images
        null, // no seed
        null  // no negative prompt
      );
      // Upload immediately to Cloudinary so MH video test can use the proper 1080×1920 image
      try {
        const mime = (buf[0] === 0xFF && buf[1] === 0xD8) ? 'image/jpeg' : 'image/png';
        _googleTestImageUrl = await cloudinaryLib.uploadImageFromUrl(
          `data:${mime};base64,${buf.toString('base64')}`,
          `streamverse/shots/tmp/api_test_google_${Date.now()}`
        );
      } catch (e) {
        console.warn('[TestAPIs] Google image Cloudinary upload failed:', e.message);
      }
      const sbCount = config.scrapingBeeKeys.length;
      const sbNote  = sbCount ? ` · ${sbCount} ScrapingBee proxy key${sbCount > 1 ? 's' : ''} available` : ' · no ScrapingBee keys (add SCRAPINGBEE_KEYS for proxy fallback)';
      return { detail: `${buf.length} bytes · direct Google${sbNote}` };
    }),

    // CF Worker — img2img test (send a reference image via multipart FormData)
    timed('CF Worker', async () => {
      const FormData = require('form-data');
      const cfKey    = config.getNextCfKey();
      const cfUrl    = config.cfWorkerUrls[0];
      if (!cfUrl) throw new Error('CF_WORKER_URL not configured');

      // Fetch a reference image to send as input_image_0
      const refResp = await axios.get(
        'https://res.cloudinary.com/fokksydp/image/upload/v1785321577/streamverse/logo/watermark_block.png',
        { responseType: 'arraybuffer', timeout: 20000 }
      );
      const refBuf = Buffer.from(refResp.data);

      const form = new FormData();
      form.append('prompt', 'a glowing test sphere, professional, photorealistic');
      form.append('input_image_0', refBuf, { filename: 'ref.png', contentType: 'image/png' });

      const resp = await axios.post(cfUrl, form, {
        headers: { ...form.getHeaders(), 'Authorization': `Bearer ${cfKey}` },
        responseType: 'arraybuffer',
        timeout: 90000,
      });

      const raw = Buffer.from(resp.data);
      // Detect JSON error response (worker returns { error: "…" } on failure)
      if (raw[0] === 0x7B) {
        let errMsg = raw.toString('utf8').slice(0, 400);
        try { errMsg = JSON.parse(errMsg).error || errMsg; } catch {}
        throw new Error(`❌ Not an image — ${errMsg}`);
      }
      if (raw.length < 100) throw new Error('CF Worker returned empty image');

      // Resize to 1080×1920 (9:16 vertical) before uploading for MH test.
      try {
        const sharp   = require('sharp');
        const resized = await sharp(raw)
          .resize(1080, 1920, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 1 } })
          .png()
          .toBuffer();
        cfImageUrl = await cloudinaryLib.uploadImageFromUrl(
          `data:image/png;base64,${resized.toString('base64')}`,
          `streamverse/shots/tmp/api_test_${Date.now()}`
        );
      } catch (e) {
        console.warn('[TestAPIs] CF image resize/upload failed:', e.message);
      }
      return { detail: `${raw.length} bytes → resized to 1080×1920` };
    }),

    // Cloudinary — ping Admin API with Basic Auth (api_key:api_secret)
    timed('Cloudinary', async () => {
      const resp = await axios.get(
        `https://api.cloudinary.com/v1_1/${config.cloudinaryCloudName}/resources/image`,
        {
          auth:    { username: config.cloudinaryApiKey, password: config.cloudinaryApiSecret },
          params:  { max_results: 1 },
          timeout: 15000,
        }
      );
      const count = resp.data?.resources?.length ?? 0;
      return { detail: `cloud: ${config.cloudinaryCloudName} (${count} items)` };
    }),

    // Mistral — minimal LLM call
    timed('Mistral', async () => {
      const key = config.getNextMistralKey();
      const resp = await axios.post('https://api.mistral.ai/v1/chat/completions',
        { model: 'mistral-small-latest', messages: [{ role: 'user', content: 'Reply with one word: ready' }], max_tokens: 5 },
        { headers: { Authorization: `Bearer ${key}` }, timeout: 20000 }
      );
      const reply = resp.data?.choices?.[0]?.message?.content || '';
      return { detail: reply.slice(0, 50) };
    }),

    // Groq — minimal LLM call
    timed('Groq', async () => {
      const key = config.getNextGroqKey();
      const resp = await axios.post('https://api.groq.com/openai/v1/chat/completions',
        { model: 'llama-3.1-8b-instant', messages: [{ role: 'user', content: 'Reply with one word: ready' }], max_tokens: 5 },
        { headers: { Authorization: `Bearer ${key}` }, timeout: 20000 }
      );
      const reply = resp.data?.choices?.[0]?.message?.content || '';
      return { detail: reply.slice(0, 50) };
    }),

    // FFmpeg service — health check
    timed('FFmpeg Service', async () => {
      const resp = await axios.get(`${config.ffmpegServiceUrl}/health`, { timeout: 30000 });
      return { detail: resp.data?.status || 'ok' };
    }),

    // Telegram — send test message
    timed('Telegram', async () => {
      await telegramLib.sendTelegram('🔬 StreamVerse API test — Telegram ✅');
      return {};
    }),

    // Facebook — validate token by querying page info
    timed('Facebook', async () => {
      const token = config.getFbToken();
      if (!token) throw new Error('No Facebook token configured');
      const resp = await axios.get(
        `https://graph.facebook.com/v20.0/${config.facebookPageId}`,
        { params: { fields: 'id,name', access_token: token }, timeout: 15000 }
      );
      return { detail: resp.data?.name || resp.data?.id };
    }),

    // Magic Hour — fetch credit info for each key
    timed('Magic Hour Credits', async () => {
      const keys    = config.magicHourKeys;
      if (!keys.length) throw new Error('No Magic Hour keys configured');
      const credits = [];
      await Promise.all(keys.map(async (key) => {
        try {
          const resp = await axios.get('https://api.magichour.ai/v1/me',
            { headers: { Authorization: `Bearer ${key}` }, timeout: 15000 }
          );
          const data   = resp.data || {};
          const email  = data.email || data.user?.email || '—';
          const bal    = data.credits?.remaining ?? data.frame_credits ?? data.credits ?? '?';
          // Store per-key credit info in keyHealth
          const masked = config.magicHourKeys.indexOf(key);
          if (config.keyHealth.magicHour[masked]) {
            config.keyHealth.magicHour[masked].credits = bal;
            config.keyHealth.magicHour[masked].email   = email;
          }
          credits.push({ email, remaining: bal });
        } catch (e) {
          credits.push({ error: e.message.slice(0, 80) });
        }
      }));
      return { detail: credits.map(c => c.email ? `${c.email}: ${c.remaining}` : c.error).join(' | ') };
    }),

  ]);

  // ── Magic Hour video test ──────────────────────────────────────────────────
  // Source priority: 1) Google-generated 1080×1920 image (best quality, correct aspect ratio)
  //                  2) CF Worker image  3) static Cloudinary fallback
  await timed('Magic Hour Video', async () => {
    const imageUrl = _googleTestImageUrl
      || cfImageUrl
      || 'https://res.cloudinary.com/fokksydp/image/upload/v1785321577/streamverse/logo/watermark_block.png';
    _testImageUrl = imageUrl; // capture for dashboard display

    // Try all MH keys — rotate on 402 (no credits) or 429 (rate-limit)
    let key, jobId;
    const keyCount = config.magicHourKeys.length;
    let lastMhErr;
    for (let attempt = 0; attempt < keyCount; attempt++) {
      key = config.getNextMagicHourKey(attempt);
      try {
        const resp = await axios.post(
          'https://api.magichour.ai/v1/image-to-video',
          { end_seconds: 5, assets: { image_file_path: imageUrl } },
          { headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, timeout: 30000 }
        );
        if (!resp.data?.id) throw new Error(`Unexpected response: ${JSON.stringify(resp.data)}`);
        jobId = resp.data.id;
        break;
      } catch (err) {
        lastMhErr = err;
        const status = err.response?.status;
        if ((status === 402 || status === 429) && attempt < keyCount - 1) {
          console.warn(`[TestAPIs] MH key ${attempt + 1}/${keyCount} failed (${status}), rotating...`);
          continue;
        }
        throw err;
      }
    }
    if (!jobId) throw new Error(`All ${keyCount} Magic Hour keys failed. Last: ${lastMhErr?.message}`);

    // Poll up to 5 minutes (5s × 60)
    for (let i = 0; i < 60; i++) {
      await new Promise(r => setTimeout(r, 5000));
      const poll = await axios.get(
        `https://api.magichour.ai/v1/video-projects/${jobId}`,
        { headers: { Authorization: `Bearer ${key}` }, timeout: 20000 }
      );
      if (poll.data?.status === 'complete') {
        const rawVideoUrl = poll.data?.downloads?.[0]?.url || null;
        if (!rawVideoUrl) return { detail: `Job ${jobId} complete (no download URL)`, videoUrl: null };

        // ── Upload to Cloudinary + apply logo overlay + quality ──────────────
        // Mirrors exactly what the real pipeline does, so you can verify
        // logo position/size/quality/audio before the first real episode runs.
        let videoUrl = rawVideoUrl;
        let logoNote = 'logo overlay: skipped (Cloudinary upload failed)';
        try {
          const cloudinaryVideoUrl = await cloudinaryLib.uploadVideoFromUrl(
            rawVideoUrl,
            `streamverse/shots/tmp/api_test_video_${Date.now()}`
          );
          const overlayUrl = cloudinaryLib.buildLogoOverlayUrl(cloudinaryVideoUrl);
          videoUrl = overlayUrl || cloudinaryVideoUrl;
          const hasAudio = !!process.env.CLOUDINARY_BACKGROUND_MUSIC_ID;
          logoNote = overlayUrl
            ? `logo overlay: ✅ south-east, w=460, covers MH watermark${hasAudio ? ' · 🎵 audio' : ''}`
            : 'logo overlay: ⚠️ buildLogoOverlayUrl returned null';
          console.log(`[TestAPIs] MH test video with logo overlay: ${videoUrl}`);
        } catch (uploadErr) {
          console.warn('[TestAPIs] MH video Cloudinary upload failed:', uploadErr.message);
        }

        return { detail: `Job ${jobId} complete · ${logoNote}`, videoUrl };
      }
      if (['error','canceled'].includes(poll.data?.status)) {
        throw new Error(`Job ${jobId} failed: ${poll.data?.error?.message || poll.data.status}`);
      }
    }
    throw new Error(`Job ${jobId} timed out after 5 minutes`);
  });

  const _mhResult = results.find(r => r.name === 'Magic Hour Video');
  state.setApiTest({
    running:      false,
    results:      [...results],
    startedAt,
    finishedAt:   new Date().toISOString(),
    testVideoUrl: _mhResult?.videoUrl || null,
    testImageUrl: _testImageUrl || null,
  });
  console.log('[TestAPIs] All done.');
}

// Detect MIME type from buffer magic bytes (used in test + pipeline)
function _detectMime(buf) {
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF)                      return 'image/jpeg';
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&
      buf[8] === 0x57 && buf[9] === 0x45 && buf[10]=== 0x42 && buf[11]=== 0x50)  return 'image/webp';
  return 'image/png'; // safe fallback
}

// n8n migration webhook compatibility
app.post('/streamverse-run-episode', (req, res) => {
  const s = state.getState();
  if (s.status !== state.STATES.IDLE && s.status !== state.STATES.ERROR) {
    return res.json({ ok: false, error: 'Pipeline already running' });
  }
  pipeline.runStreamVersePipeline().catch(() => {});
  res.json({ ok: true, message: 'Pipeline triggered via webhook' });
});

app.post('/api/trigger-comments', async (req, res) => {
  pipeline.runAutoCommentReplies().catch(err => console.error('[API] Auto-replies error:', err.message));
  res.json({ ok: true, message: 'Auto-comment reply pipeline started' });
});

app.post('/api/trigger-engagement', async (req, res) => {
  pipeline.runEngagementPost().catch(err => console.error('[API] Engagement post error:', err.message));
  res.json({ ok: true, message: 'Engagement post pipeline started' });
});

// Clear test media (video + source image) from dashboard
app.delete('/api/test-video', (req, res) => {
  const s = state.getState();
  if (s.apiTest) {
    state.setApiTest({ ...s.apiTest, testVideoUrl: null, testImageUrl: null });
  }
  res.json({ ok: true });
});

app.get('/health', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.json({ ok: true, status: state.getState().status, ts: new Date().toISOString() });
});

// ──────────────────────────────────────────────────────────────────────────────
// Ad-as-Auth Streaming Gateway
// External traffic → Adsterra VAST ad → token → signed Cloudinary URL
// Internal pipeline → bypass header → direct video URL
// ──────────────────────────────────────────────────────────────────────────────

app.options('/api/episodes/:id/stream',    streamGateway.handleOptions);
app.get('/api/episodes/:id/stream',        streamGateway.handleStream);
app.options('/api/episodes/:id/ad-complete', streamGateway.handleOptions);
app.post('/api/episodes/:id/ad-complete',  streamGateway.handleAdComplete);
app.options('/api/episodes/:id/video',     streamGateway.handleOptions);
app.get('/api/episodes/:id/video',         streamGateway.handleVideoStream);

// ──────────────────────────────────────────────────────────────────────────────
// Prune DB — wipe all content tables
//
// Authorization: the caller must supply the server's SESSION_SECRET (or a
// dedicated PRUNE_SECRET if set) in the request body.  The server validates it
// with crypto.timingSafeEqual so the secret never leaks via timing side-channels.
//
// The secret is never embedded in the dashboard JS — the user types it into
// a password field in the confirmation dialog.  Anyone who can reach the endpoint
// still needs to know the secret, which only the operator has.
// ──────────────────────────────────────────────────────────────────────────────

const crypto = require('crypto');

app.delete('/api/prune-db', async (req, res) => {
  const provided = req.body?.secret;
  if (!provided || typeof provided !== 'string') {
    return res.status(401).json({ ok: false, error: 'Unauthorized — admin secret required' });
  }

  // Accept either a dedicated PRUNE_SECRET or fall back to SESSION_SECRET.
  // Both must be set to a non-default value; reject the placeholder.
  const adminSecret = process.env.PRUNE_SECRET || process.env.SESSION_SECRET || '';
  if (!adminSecret || adminSecret === 'change-me-to-a-random-string') {
    console.error('[PruneDB] SESSION_SECRET is not configured — refusing prune');
    return res.status(503).json({ ok: false, error: 'Admin secret not configured on server' });
  }

  // Timing-safe comparison prevents secret enumeration via response-time differences
  let authorized = false;
  try {
    const a = Buffer.from(provided,    'utf8');
    const b = Buffer.from(adminSecret, 'utf8');
    authorized = a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { authorized = false; }

  if (!authorized) {
    console.warn('[PruneDB] Unauthorized prune attempt — wrong secret');
    return res.status(403).json({ ok: false, error: 'Forbidden — incorrect admin secret' });
  }

  try {
    // Delete in FK dependency order (shots → episodes → characters → storylines)
    const shotsDel      = await db.execute('DELETE FROM shots');
    const episodesDel   = await db.execute('DELETE FROM episodes');
    const charactersDel = await db.execute('DELETE FROM characters');
    const storylinesDel = await db.execute('DELETE FROM storylines');
    console.log(
      `[PruneDB] Wiped: ${shotsDel.affectedRows} shots, ` +
      `${episodesDel.affectedRows} episodes, ` +
      `${charactersDel.affectedRows} characters, ` +
      `${storylinesDel.affectedRows} storylines`
    );
    res.json({
      ok: true,
      message: 'Database wiped',
      deleted: {
        shots:      shotsDel.affectedRows,
        episodes:   episodesDel.affectedRows,
        characters: charactersDel.affectedRows,
        storylines: storylinesDel.affectedRows,
      },
    });
  } catch (err) {
    console.error('[PruneDB] Error:', err.message);
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ──────────────────────────────────────────────────────────────────────────────
// Cron schedules (UTC)
// ──────────────────────────────────────────────────────────────────────────────

cron.schedule('0 5 * * *', () => {
  console.log('[Cron] 05:00 UTC — episode pipeline');
  pipeline.runStreamVersePipeline().catch(err => console.error('[Cron 05:00]', err.message));
}, { timezone: 'UTC' });

cron.schedule('0 17 * * *', () => {
  console.log('[Cron] 17:00 UTC — episode pipeline');
  pipeline.runStreamVersePipeline().catch(err => console.error('[Cron 17:00]', err.message));
}, { timezone: 'UTC' });

cron.schedule('0 12 * * *', () => {
  console.log('[Cron] 12:00 UTC — Reels pipeline');
  pipeline.runReelsPipeline().catch(err => console.error('[Cron 12:00]', err.message));
}, { timezone: 'UTC' });

cron.schedule('0 9,14,19 * * *', () => {
  console.log('[Cron] Comment reminder');
  pipeline.runCommentReminder().catch(err => console.error('[Cron reminders]', err.message));
}, { timezone: 'UTC' });

cron.schedule('0 7,13,18,22 * * *', () => {
  console.log('[Cron] Auto comment replies');
  pipeline.runAutoCommentReplies().catch(err => console.error('[Cron auto-replies]', err.message));
}, { timezone: 'UTC' });

cron.schedule('0 10,15 * * *', () => {
  console.log('[Cron] Engagement post');
  pipeline.runEngagementPost().catch(err => console.error('[Cron engagement]', err.message));
}, { timezone: 'UTC' });

// ──────────────────────────────────────────────────────────────────────────────
// Bootstrap
// ──────────────────────────────────────────────────────────────────────────────

// ──────────────────────────────────────────────────────────────────────────────
// Magic Hour credit refresh — runs on boot and every 30 minutes.
// Magic Hour does not currently expose a public credits endpoint; this function
// probes the known candidates once, logs the outcome once, then stops retrying
// on 404 so the log stays clean.
// ──────────────────────────────────────────────────────────────────────────────

const MH_CREDIT_ENDPOINTS = [
  'https://api.magichour.ai/v1/me',
  'https://api.magichour.ai/v1/account',
  'https://api.magichour.ai/v1/user',
];
let _mhCreditEndpoint      = null;   // discovered working URL, null = unknown, false = none exist
let _mhCreditEndpointLogged = false; // only log "unavailable" once

async function _probeMhCreditEndpoint(key) {
  for (const url of MH_CREDIT_ENDPOINTS) {
    try {
      const resp = await axios.get(url, { headers: { Authorization: `Bearer ${key}` }, timeout: 10000 });
      if (resp.data && typeof resp.data === 'object') {
        _mhCreditEndpoint = url;
        console.log(`[MH Credits] Discovered credit endpoint: ${url}`);
        return { url, data: resp.data };
      }
    } catch (err) {
      if (err.response?.status !== 404) throw err; // unexpected error — propagate
      // 404 → try next candidate
    }
  }
  _mhCreditEndpoint = false; // definitively unavailable
  if (!_mhCreditEndpointLogged) {
    console.log('[MH Credits] No credit balance endpoint found on Magic Hour API — balance display unavailable.');
    _mhCreditEndpointLogged = true;
  }
  return null;
}

async function refreshMhCredits() {
  const keys = config.magicHourKeys;
  if (!keys.length) return;

  // If we already know the endpoint doesn't exist, skip silently
  if (_mhCreditEndpoint === false) return;

  await Promise.all(keys.map(async (key, i) => {
    try {
      let result = null;
      if (_mhCreditEndpoint) {
        const resp = await axios.get(_mhCreditEndpoint,
          { headers: { Authorization: `Bearer ${key}` }, timeout: 10000 });
        result = { url: _mhCreditEndpoint, data: resp.data };
      } else {
        result = await _probeMhCreditEndpoint(key);
      }
      if (!result) return; // endpoint unavailable

      const data    = result.data || {};
      const email   = data.email || data.user?.email || null;
      const credits = data.credits?.remaining ?? data.frame_credits ?? data.credits ?? null;
      if (config.keyHealth.magicHour[i]) {
        if (credits !== null) config.keyHealth.magicHour[i].credits = credits;
        if (email)            config.keyHealth.magicHour[i].email   = email;
        config.keyHealth.magicHour[i].creditsRefreshedAt = new Date().toISOString();
      }
      console.log(`[MH Credits] Key ${i + 1}: ${credits !== null ? credits + ' credits' : '?'} (${email || 'no email'})`);
    } catch (err) {
      if (!_mhCreditEndpointLogged) {
        console.warn(`[MH Credits] Key ${i + 1}: ${err.message}`);
      }
    }
  }));

  // Push updated keyHealth to all SSE clients so the dashboard refreshes live
  state.emitter.emit('update', state.getState());
}

// ──────────────────────────────────────────────────────────────────────────────
// Bootstrap
// ──────────────────────────────────────────────────────────────────────────────

async function bootstrap() {
  try {
    await db.initSchema();
  } catch (err) {
    console.error('[Bootstrap] DB schema init failed:', err.message);
    console.error('[Bootstrap] App will start but DB features will fail until DB is reachable.');
  }

  // Upload logo to Cloudinary once so video overlay transformations can reference it
  cloudinaryLib.uploadLogo().catch(err =>
    console.warn('[Bootstrap] Logo upload failed (video watermark coverage disabled):', err.message)
  );

  // Upload background music to Cloudinary once so all video URLs get an audio layer.
  // Default: a royalty-free SoundHelix ambient track (explicit free-use license).
  // Override by setting BACKGROUND_MUSIC_SOURCE_URL or CLOUDINARY_BACKGROUND_MUSIC_ID.
  if (!process.env.CLOUDINARY_BACKGROUND_MUSIC_ID) {
    const musicSrc = process.env.BACKGROUND_MUSIC_SOURCE_URL
      || 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
    cloudinaryLib.uploadBackgroundMusic(musicSrc).catch(err =>
      console.warn('[Bootstrap] Background music upload failed (videos will be silent):', err.message)
    );
  }

  app.listen(config.port, '0.0.0.0', () => {
    console.log(`[StreamVerse] Server running on port ${config.port}`);
    console.log(`[StreamVerse] Dashboard: http://0.0.0.0:${config.port}/dashboard`);
    console.log('[StreamVerse] Cron: 05:00, 12:00, 17:00 UTC episodes/reels + 09/14/19 reminders');
  });

  // Fetch Magic Hour credit balances on startup (non-blocking) then every 30 min
  refreshMhCredits().catch(err => console.warn('[MH Credits] Startup fetch failed:', err.message));
  setInterval(() => {
    refreshMhCredits().catch(err => console.warn('[MH Credits] Refresh failed:', err.message));
  }, 30 * 60 * 1000);

  // ── Auto-resume any in-progress draft episode on startup ─────────────────
  // Episode generation takes 30-60 min. Replit can restart at any time.
  // Without this, a paused draft would wait until the next scheduled cron window
  // (up to 12 hours away) before resuming. We check immediately after boot.
  setTimeout(async () => {
    try {
      const draftInfo = await pipeline.getDraftEpisodeAny();
      if (draftInfo) {
        const { storyline } = draftInfo;
        console.log(`[Bootstrap] Found in-progress draft for "${storyline.title}" — auto-resuming`);
        await telegramLib.sendTelegram(
          `🔄 <b>StreamVerse restarted</b> — found paused episode of "<b>${storyline.title}</b>". Auto-resuming now...`
        ).catch(() => {});
        pipeline.runStreamVersePipeline().catch(err =>
          console.error('[Bootstrap] Auto-resume pipeline failed:', err.message)
        );
      }
    } catch (err) {
      console.warn('[Bootstrap] Draft check failed (non-fatal):', err.message);
    }
  }, 8000); // 8s delay — let DB connections and Cloudinary init settle first
}

bootstrap();
